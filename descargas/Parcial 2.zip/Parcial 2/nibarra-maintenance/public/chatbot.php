<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    // Opcional: permitir chat público comentando la línea siguiente
    // header("Location: login.php"); exit;
}
include 'header.php';
?>

<link rel="stylesheet" href="css/styles.css">

<div class="chatbot-page container">
  <h2>ChatBot — Asistente NIBARRA</h2>
  <p>Escribe tu consulta. Respuestas automáticas basadas en las reglas del sistema.</p>

  <div id="chatWindow" class="chat-window">
    <div id="messages" class="messages"></div>
  </div>

  <form id="chatForm" class="chat-form" onsubmit="return false;">
    <input id="chatInput" type="text" placeholder="Escribe tu mensaje..." autocomplete="off" required />
    <button id="sendBtn" class="btn">Enviar</button>
  </form>

  <div class="help-box">
    <small>Prueba con: "horario", "mantenimiento", "agendar", "precio", "hola".</small>
  </div>
</div>

<style>
/* estilo mínimo para el chat (puedes mover a styles.css) */
.chat-window {
  background: #fff;
  border-radius: 8px;
  height: 360px;
  overflow-y: auto;
  padding: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}
.messages { display:flex; flex-direction:column; gap:10px; }
.msg { max-width: 80%; padding:8px 10px; border-radius:10px; }
.msg.user { margin-left:auto; background:#007bff; color:white; }
.msg.bot { margin-right:auto; background:#f1f1f1; color:#222; }
.chat-form { display:flex; gap:8px; margin-top:10px; }
.chat-form input { flex:1; padding:8px; border-radius:6px; border:1px solid #ddd; }
.chat-form button { padding:8px 14px; border-radius:6px; background:#004aad; color:#fff; border:none; }
.help-box { margin-top:8px; color:#666; }
</style>

<script>
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');
const messages = document.getElementById('messages');
const sendBtn = document.getElementById('sendBtn');

function appendMsg(text, who='bot') {
  const div = document.createElement('div');
  div.classList.add('msg', who === 'user' ? 'user' : 'bot');
  div.textContent = text;
  messages.appendChild(div);
  messages.parentElement.scrollTop = messages.parentElement.scrollHeight;
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const texto = chatInput.value.trim();
  if (!texto) return;
  appendMsg(texto, 'user');
  chatInput.value = '';
  sendBtn.disabled = true;

  try {
    const res = await fetch('api/chatbot.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ mensaje: texto })
    });
    const data = await res.json();
    if (data.ok) {
      appendMsg(data.respuesta, 'bot');
    } else {
      appendMsg('Error: ' + (data.error || 'sin respuesta'), 'bot');
    }
  } catch (err) {
    appendMsg('Error de conexión', 'bot');
  } finally {
    sendBtn.disabled = false;
  }
});

// 👇 Mensaje inicial del chatbot al cargar la página
window.addEventListener('DOMContentLoaded', () => {
  appendMsg('👋 ¡Hola! Soy el asistente virtual de NIBARRA. Escribe "comandos" para ver lo que puedo hacer.', 'bot');
});
</script>


<?php include 'footer.php'; ?>
