<?php
// public/api/chatbot.php
session_start();
header('Content-Type: application/json; charset=utf-8');
include '../../config/conexion.php';

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'error' => 'Método no permitido']);
    exit;
}

// Comprobar sesión (si quieres permitir chat anónimo, adapta)
$usuario_id = $_SESSION['usuario_id'] ?? null;
$usuario_nombre = $_SESSION['nombre'] ?? 'Invitado';

// Recibir JSON
$input = json_decode(file_get_contents('php://input'), true);
$mensaje = trim($input['mensaje'] ?? '');

if ($mensaje === '') {
    echo json_encode(['ok' => false, 'error' => 'Mensaje vacío']);
    exit;
}

// Normalizar texto
$mensaje_lc = mb_strtolower($mensaje, 'UTF-8');

// === Comprobar si el usuario pregunta por "estado del equipo [ID]" ===
$matchRespuesta = null;

if (preg_match('/estado del equipo\s+(\d+)/i', $mensaje, $m)) {
    $id_equipo = intval($m[1]);

    // Si tienes una tabla 'equipos', puedes reemplazar esto con una consulta real
    // Ejemplo:
    // $stmt_eq = $conn->prepare("SELECT estado FROM equipos WHERE id = ?");
    // $stmt_eq->bind_param("i", $id_equipo);
    // $stmt_eq->execute();
    // $stmt_eq->bind_result($estado);
    // if ($stmt_eq->fetch()) {
    //     $matchRespuesta = "📋 El equipo con ID $id_equipo está actualmente en estado: *$estado*.";
    // } else {
    //     $matchRespuesta = "No se encontró ningún equipo con el ID $id_equipo.";
    // }
    // $stmt_eq->close();

    // Respuesta simulada (por ahora)
    $matchRespuesta = "📋 El equipo con ID $id_equipo está actualmente en proceso de mantenimiento preventivo.";
}

// Si no hubo respuesta dinámica, buscar en la base de datos de patrones
if ($matchRespuesta === null) {
    $res = $conn->query("SELECT id, patrones, respuesta FROM chatbot_responses ORDER BY id ASC");

    if ($res && $res->num_rows > 0) {
        while ($r = $res->fetch_assoc()) {
            $patrones = array_map('trim', explode(',', mb_strtolower($r['patrones'], 'UTF-8')));
            foreach ($patrones as $p) {
                if ($p === '') continue;
                if (mb_strpos($mensaje_lc, $p) !== false) {
                    $matchRespuesta = $r['respuesta'];
                    break 2;
                }
            }
        }
    }
}

// Fallback: si no hay coincidencia, usar patrón vacío o mensaje genérico
if ($matchRespuesta === null) {
    $res2 = $conn->query("SELECT respuesta FROM chatbot_responses WHERE TRIM(patrones) = '' LIMIT 1");
    if ($res2 && $res2->num_rows > 0) {
        $row = $res2->fetch_assoc();
        $matchRespuesta = $row['respuesta'];
    } else {
        $matchRespuesta = "Lo siento, no entendí. Por favor escribe con otras palabras o contacta soporte.";
    }
}

// Guardar conversación en la base de datos
$stmt = $conn->prepare("
    INSERT INTO chatbot_conversations (usuario_id, usuario_nombre, mensaje_usuario, respuesta_chatbot)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param('isss', $usuario_id, $usuario_nombre, $mensaje, $matchRespuesta);
$stmt->execute();
$stmt->close();

// Cerrar conexión
$conn->close();

// Responder JSON
echo json_encode([
    'ok' => true,
    'respuesta' => $matchRespuesta,
    'usuario' => $usuario_nombre,
    'timestamp' => date('c')
]);
