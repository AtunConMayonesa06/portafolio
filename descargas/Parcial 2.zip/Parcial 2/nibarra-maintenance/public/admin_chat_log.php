<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

// Incluir archivos con rutas correctas
$base_dir = __DIR__;
include $base_dir . '/header.php';
include $base_dir . '/../config/conexion.php';

if ($_SESSION['rol'] !== 'Administrador') {
    echo "<div class='alert alert-danger text-center mt-4'>Acceso denegado. Solo los administradores pueden ver el registro del chatbot.</div>";
    include $base_dir . '/footer.php';
    exit;
}

// Filtros
$busqueda = $_GET['buscar'] ?? '';
$usuarioFiltro = $_GET['usuario'] ?? '';

$sql = "SELECT * FROM chatbot_conversations WHERE 1";

if ($busqueda !== '') {
    $busqueda = $conn->real_escape_string($busqueda);
    $sql .= " AND (mensaje_usuario LIKE '%$busqueda%' OR respuesta_chatbot LIKE '%$busqueda%')";
}
if ($usuarioFiltro !== '') {
    $usuarioFiltro = $conn->real_escape_string($usuarioFiltro);
    $sql .= " AND usuario_nombre LIKE '%$usuarioFiltro%'";
}

$sql .= " ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<div class="container mt-4">
  <h2 class="text-center mb-4">📜 Registro de Conversaciones del ChatBot</h2>

  <form method="GET" class="row g-3 mb-4">
    <div class="col-md-4">
      <input type="text" name="buscar" class="form-control" placeholder="Buscar palabra clave..." value="<?= htmlspecialchars($busqueda) ?>">
    </div>
    <div class="col-md-4">
      <input type="text" name="usuario" class="form-control" placeholder="Filtrar por usuario..." value="<?= htmlspecialchars($usuarioFiltro) ?>">
    </div>
    <div class="col-md-4">
      <button type="submit" class="btn btn-primary">Filtrar</button>
      <a href="admin_chat_log.php" class="btn btn-secondary">Limpiar</a>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-striped table-hover align-middle">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Usuario</th>
          <th>Mensaje del Usuario</th>
          <th>Respuesta del Bot</th>
          <th>Fecha</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= htmlspecialchars($row['usuario_nombre'] ?? 'Invitado') ?></td>
              <td><?= htmlspecialchars($row['mensaje_usuario']) ?></td>
              <td><?= htmlspecialchars($row['respuesta_chatbot']) ?></td>
              <td><?= date('d/m/Y H:i:s', strtotime($row['created_at'])) ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" class="text-center text-muted">No hay registros de conversaciones.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php 
include $base_dir . '/footer.php'; 
?>