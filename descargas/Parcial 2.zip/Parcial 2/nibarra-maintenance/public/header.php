<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIBARRA</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Tu hoja de estilos -->
    <link rel="stylesheet" href="css/styles.css?v=<?php echo time(); ?>">
    <!-- Protección global del sitio -->
    <script>
    // 🚫 Bloquear clic derecho
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 🚫 Bloquear teclas de inspección, copia y guardado
    document.addEventListener('keydown', e => {
    if (
        (e.ctrlKey && ['c','u','s','p'].includes(e.key.toLowerCase())) ||  // Ctrl+C/U/S/P
        (e.ctrlKey && e.shiftKey && ['i','j','c'].includes(e.key.toLowerCase())) || // Ctrl+Shift+I/J/C
        e.key === 'F12'
    ) {
        e.preventDefault();
        e.stopPropagation();
        alert('⚠️ Acción bloqueada por seguridad del sistema.');
    }
    });

    // 🚫 Bloquear selección de texto
    document.addEventListener('selectstart', e => e.preventDefault());
    document.addEventListener('copy', e => {
    e.preventDefault();
    alert('🚫 Copiar contenido no está permitido.');
    });
    </script>

    <style>
    /* 🔒 Bloquear selección y arrastre */
    body, html {
    user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -webkit-touch-callout: none;
    -webkit-tap-highlight-color: transparent;
    }
    img, svg {
    pointer-events: none;
    }
    </style>
</head>
<body>

<header class="site-header py-3 shadow">
    <div class="container d-flex justify-content-between align-items-center">
        <h2 class="m-0">NIBARRA</h2>
        <nav>
            <a href="index.php" class="text-white mx-2 text-decoration-none">Inicio</a>
            <a href="equipos.php" class="text-white mx-2 text-decoration-none">Equipos</a>
            <a href="mantenimiento.php" class="text-white mx-2 text-decoration-none">Mantenimiento</a>
            <a href="calendar.php" class="text-white mx-2 text-decoration-none">Calendario</a>
            <a href="chatbot.php" class="text-white mx-2 text-decoration-none">ChatBot</a>

            <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'Administrador'): ?>
                <a href="admin_chat_log.php" class="text-info mx-2 text-decoration-none">ChatBot Log</a>
            <?php endif; ?>

            <?php if (isset($_SESSION['usuario'])): ?>
                <a href="dashboard.php" class="text-warning mx-2 text-decoration-none">
                    👤 <?= htmlspecialchars($_SESSION['nombre']); ?>
                </a>
            <?php else: ?>
                <a href="login.php" class="text-white mx-2 text-decoration-none">Acceso</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
