<?php
session_start();

// Verifica que haya sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

include '../config/conexion.php';
include 'header.php';

// Variables de sesión
$usuario_id = $_SESSION['usuario_id'];
$rol = strtolower(trim($_SESSION['rol'])); // 🔹 Minúsculas y sin espacios

?>

<h2>Gestión de Mantenimientos</h2>

<!-- Formulario para registrar mantenimiento -->
<?php if ($rol === 'administrador' || $rol === 'usuario'): ?>
<section class="form-section">
  <h3>Registrar nuevo mantenimiento</h3>
  <form method="POST">
    <label>Equipo:</label>
    <select name="equipo_id" required>
      <option value="">Seleccione un equipo</option>
      <?php
      // 🔹 Admin ve todos los equipos, usuario solo los suyos
      if ($rol === 'administrador') {
          $equipos = $conn->query("SELECT id, nombre_equipo FROM equipos ORDER BY nombre_equipo ASC");
      } else {
          $equipos = $conn->query("SELECT id, nombre_equipo FROM equipos WHERE usuario_id = $usuario_id ORDER BY nombre_equipo ASC");
      }

      if ($equipos && $equipos->num_rows > 0) {
          while ($eq = $equipos->fetch_assoc()) {
              echo "<option value='{$eq['id']}'>{$eq['nombre_equipo']}</option>";
          }
      } else {
          echo "<option disabled>No hay equipos registrados</option>";
      }
      ?>
    </select>

    <label>Tipo de mantenimiento:</label>
    <select name="tipo_mantenimiento" required>
      <option value="Predictivo">Predictivo</option>
      <option value="Preventivo">Preventivo</option>
      <option value="Correctivo">Correctivo</option>
    </select>

    <label>Estado:</label>
    <select name="estado" required>
      <option value="Por hacer">Por hacer</option>
      <option value="En espera de material">En espera de material</option>
      <option value="En revisión">En revisión</option>
      <option value="Terminado">Terminado</option>
    </select>

    <label>Porcentaje de avance:</label>
    <input type="number" name="porcentaje" min="0" max="100" value="0" required>

    <label>Fecha programada:</label>
    <input type="date" name="fecha_programada" required>

    <label>Observaciones:</label>
    <textarea name="observaciones" placeholder="Observaciones..."></textarea>

    <button type="submit" name="guardar">Guardar</button>
  </form>
</section>
<?php endif; ?>

<?php
// Guardar mantenimiento
if (isset($_POST['guardar'])) {
    $equipo_id = $_POST['equipo_id'];
    $tipo = $_POST['tipo_mantenimiento'];
    $estado = $_POST['estado'];
    $porcentaje = $_POST['porcentaje'];
    $fecha = $_POST['fecha_programada'];
    $obs = $conn->real_escape_string($_POST['observaciones']);

    $sql = "INSERT INTO mantenimientos (equipo_id, tipo_mantenimiento, estado, porcentaje, fecha_programada, observaciones)
            VALUES ('$equipo_id', '$tipo', '$estado', '$porcentaje', '$fecha', '$obs')";

    if ($conn->query($sql)) {
        echo "<p class='success'>✅ Mantenimiento registrado correctamente.</p>";
    } else {
        echo "<p class='error'>❌ Error al registrar mantenimiento: {$conn->error}</p>";
    }
}
?>

<!-- Tabla -->
<section class="table-section">
  <h3>Lista de mantenimientos</h3>
  <table border="1" cellpadding="8">
    <tr>
      <th>ID</th>
      <th>Equipo</th>
      <th>Usuario</th>
      <th>Tipo</th>
      <th>Estado</th>
      <th>Porcentaje</th>
      <th>Fecha Programada</th>
      <th>Observaciones</th>
      <th>Acciones</th>
    </tr>

    <?php
    // 🔹 Admin ve todo, usuarios solo los suyos
    if ($rol === 'administrador') {
        $result = $conn->query("
            SELECT m.*, e.nombre_equipo, u.usuario 
            FROM mantenimientos m
            LEFT JOIN equipos e ON m.equipo_id = e.id
            LEFT JOIN usuarios u ON e.usuario_id = u.id
            ORDER BY m.id DESC
        ");
    } else {
        $result = $conn->query("
            SELECT m.*, e.nombre_equipo 
            FROM mantenimientos m
            LEFT JOIN equipos e ON m.equipo_id = e.id
            WHERE e.usuario_id = $usuario_id
            ORDER BY m.id DESC
        ");
    }

    if ($result && $result->num_rows > 0):
        while ($row = $result->fetch_assoc()):
    ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['nombre_equipo']) ?></td>
        <td><?= htmlspecialchars($row['usuario'] ?? '-') ?></td>
        <td><?= htmlspecialchars($row['tipo_mantenimiento']) ?></td>
        <td><?= htmlspecialchars($row['estado']) ?></td>
        <td>
          <div class='progress-bar'>
            <div style='width:<?= $row['porcentaje'] ?>%'><?= $row['porcentaje'] ?>%</div>
          </div>
        </td>
        <td><?= htmlspecialchars($row['fecha_programada']) ?></td>
        <td><?= htmlspecialchars($row['observaciones']) ?></td>
        <td>
          <?php if ($rol === 'administrador'): ?>
            <a href="mantenimiento.php?editar=<?= $row['id'] ?>">✏️ Editar</a> |
            <a href="mantenimiento.php?eliminar=<?= $row['id'] ?>" onclick="return confirm('¿Eliminar este mantenimiento?')">🗑️ Eliminar</a>
          <?php else: ?>
            <em>Solo lectura</em>
          <?php endif; ?>
        </td>
      </tr>
    <?php
        endwhile;
    else:
        echo "<tr><td colspan='9'>No hay mantenimientos registrados.</td></tr>";
    endif;
    ?>
  </table>
</section>

<?php include 'footer.php'; ?>
