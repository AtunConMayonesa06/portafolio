<?php include 'header.php'; ?>

<section class="hero">
  <h2>Bienvenido al Sistema de Mantenimiento NIBARRA</h2>
  <p>Gestione los mantenimientos, equipos y servicios de forma eficiente y segura.</p>
  <div class="hero-buttons">
    <a href="equipos.php" class="btn">Ver Equipos</a>
    <a href="mantenimiento.php" class="btn secondary">Ver Mantenimientos</a>
  </div>
</section>

<section class="features">
  <h3>Funciones principales</h3>
  <div class="feature-grid">
    <div class="feature-box">
      <h4>🛠️ Gestión de Equipos</h4>
      <p>Registre, actualice y realice seguimiento de todos los equipos.</p>
    </div>
    <div class="feature-box">
      <h4>📅 Calendario</h4>
      <p>Visualice los mantenimientos programados por mes o semana.</p>
    </div>
    <div class="feature-box">
      <h4>💬 ChatBot</h4>
      <p>Reciba asistencia inmediata con el asistente virtual del sistema.</p>
    </div>
  </div>
</section>

<?php include 'footer.php'; ?>
