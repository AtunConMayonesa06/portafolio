<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

include '../config/conexion.php';
include 'header.php';

$usuario_id = $_SESSION['usuario_id'];
$rol = strtolower(trim($_SESSION['rol'])); // Normaliza el rol
?>

<h2>Gestión de Equipos</h2>

<!-- Formulario para agregar nuevo equipo -->
<section class="form-section">
  <h3>Agregar nuevo equipo</h3>
  <form method="POST" action="">
    <label>Nombre del equipo:</label>
    <input type="text" name="nombre_equipo" required>

    <label>Tipo:</label>
    <input type="text" name="tipo" placeholder="PC, Impresora, etc." required>

    <label>Fecha de ingreso:</label>
    <input type="date" name="fecha_ingreso" required>

    <label>Descripción:</label>
    <textarea name="descripcion" placeholder="Descripción breve..."></textarea>

    <?php if ($rol === 'administrador'): ?>
      <label>Estado:</label>
      <select name="estado" required>
        <option value="En espera">En espera</option>
        <option value="En mantenimiento">En mantenimiento</option>
        <option value="Reparado">Reparado</option>
      </select>
    <?php else: ?>
      <input type="hidden" name="estado" value="En espera">
    <?php endif; ?>

    <button type="submit" name="guardar" class="btn btn-primary mt-2">Guardar</button>
  </form>
</section>

<?php
// Insertar equipo
if (isset($_POST['guardar'])) {
    $nombre = $_POST['nombre_equipo'];
    $tipo = $_POST['tipo'];
    $fecha = $_POST['fecha_ingreso'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO equipos (usuario_id, nombre_equipo, tipo, fecha_ingreso, descripcion, estado)
            VALUES ('$usuario_id', '$nombre', '$tipo', '$fecha', '$descripcion', '$estado')";
    if ($conn->query($sql)) {
        echo "<p class='text-success mt-2'>✅ Equipo agregado exitosamente.</p>";
    } else {
        echo "<p class='text-danger mt-2'>❌ Error al agregar: {$conn->error}</p>";
    }
}

// Consultar equipos
if ($rol === 'administrador') {
    $result = $conn->query("SELECT e.*, u.usuario 
                            FROM equipos e 
                            LEFT JOIN usuarios u ON e.usuario_id = u.id 
                            ORDER BY e.id DESC");
} else {
    $result = $conn->query("SELECT * FROM equipos WHERE usuario_id = $usuario_id ORDER BY id DESC");
}
?>

<!-- Tabla -->
<section class="table-section mt-4">
  <h3>Lista de equipos</h3>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Tipo</th>
        <th>Fecha de ingreso</th>
        <th>Estado</th>
        <th>Descripción</th>
        <?php if ($rol === 'administrador'): ?><th>Usuario</th><?php endif; ?>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= htmlspecialchars($row['nombre_equipo']) ?></td>
          <td><?= htmlspecialchars($row['tipo']) ?></td>
          <td><?= htmlspecialchars($row['fecha_ingreso']) ?></td>
          <td><?= htmlspecialchars($row['estado']) ?></td>
          <td><?= htmlspecialchars($row['descripcion']) ?></td>
          <?php if ($rol === 'administrador'): ?><td><?= htmlspecialchars($row['usuario'] ?? '-') ?></td><?php endif; ?>
          <td>
            <?php if ($rol === 'administrador'): ?>
              <a href="equipos.php?editar=<?= $row['id'] ?>" class="btn btn-sm btn-warning">✏️ Editar</a>
              <a href="equipos.php?eliminar=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
                 onclick="return confirm('¿Eliminar este equipo?')">🗑️ Eliminar</a>
              <button class="btn btn-sm btn-success btn-factura"
                data-equipo="<?= htmlspecialchars($row['nombre_equipo']) ?>"
                data-cliente="<?= htmlspecialchars($row['usuario'] ?? '-') ?>"
                data-equipo-id="<?= $row['id'] ?>">
                🧾 Factura
              </button>
            <?php else: ?>
              <em>Sin permisos</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</section>

<h3>Facturas Generadas</h3>
<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <th>Cliente</th>
        <th>Equipo</th>
        <th>Subtotal</th>
        <th>ITBMS</th>
        <th>Total</th>
        <th>Fecha</th>
        <th>PDF</th>
    </tr>
    <?php
    if ($rol === 'administrador') {
        $facturas_sql = "SELECT f.*, u.usuario AS nombre_cliente 
                          FROM facturas f
                          LEFT JOIN usuarios u ON f.usuario_id = u.id
                          ORDER BY f.id DESC";
    } else {
        // Cliente: solo sus facturas
        $facturas_sql = "SELECT f.*, u.usuario AS nombre_cliente 
                          FROM facturas f
                          LEFT JOIN equipos e ON f.equipo_id = e.id
                          LEFT JOIN usuarios u ON e.usuario_id = u.id
                          WHERE e.usuario_id = $usuario_id
                          ORDER BY f.id DESC";
    }

    $facturas_result = $conn->query($facturas_sql);

    while ($f = $facturas_result->fetch_assoc()):
    ?>
    <tr>
        <td><?= $f['id'] ?></td>
        <td><?= htmlspecialchars($f['cliente'] ?: $f['nombre_cliente']) ?></td>
        <td><?= htmlspecialchars($f['equipo']) ?></td>
        <td>$<?= number_format($f['subtotal'], 2) ?></td>
        <td>$<?= number_format($f['itbms'], 2) ?></td>
        <td>$<?= number_format($f['total'], 2) ?></td>
        <td><?= $f['fecha'] ?></td>
        <td><a href="factura_pdf.php?id=<?= $f['id'] ?>" target="_blank" class="btn btn-sm btn-primary">Ver PDF</a></td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Modal Generar Factura -->
<div class="modal fade" id="modalFactura" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="formFactura">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Generar Factura</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="equipo_id" id="equipo_id">
          <div class="mb-3">
            <label>Cliente</label>
            <input type="text" name="cliente" id="cliente" class="form-control" readonly>
          </div>
          <div class="mb-3">
            <label>Equipo</label>
            <input type="text" name="equipo" id="equipo" class="form-control" readonly>
          </div>
          <div id="servicios">
            <div class="mb-2 servicio-item">
              <input type="text" name="servicio[]" placeholder="Descripción del servicio" class="form-control mb-1">
              <input type="number" name="precio[]" placeholder="Precio" class="form-control">
            </div>
          </div>
          <button type="button" id="addServicio" class="btn btn-link">+ Añadir otro servicio</button>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Generar PDF</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const modalFactura = new bootstrap.Modal(document.getElementById('modalFactura'));

  // Abrir modal y llenar datos
  document.querySelectorAll('.btn-factura').forEach(btn => {
    btn.addEventListener('click', () => {
      console.log('Botón factura clickeado:', btn.dataset.equipoId); // Para depuración
      document.getElementById('equipo_id').value = btn.dataset.equipoId;
      document.getElementById('equipo').value = btn.dataset.equipo;
      document.getElementById('cliente').value = btn.dataset.cliente;
      modalFactura.show();
    });
  });

  // Añadir más servicios
  document.getElementById('addServicio').addEventListener('click', () => {
    const container = document.getElementById('servicios');
    const div = document.createElement('div');
    div.classList.add('mb-2', 'servicio-item');
    div.innerHTML = `
      <input type="text" name="servicio[]" placeholder="Descripción del servicio" class="form-control mb-1">
      <input type="number" name="precio[]" placeholder="Precio" class="form-control">
    `;
    container.appendChild(div);
  });

  // Enviar formulario y generar PDF
  document.getElementById('formFactura').addEventListener('submit', async e => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const res = await fetch('factura_pdf.php', {
      method: 'POST',
      body: formData
    });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank'); // Abrir PDF en nueva pestaña
    modalFactura.hide();
  });
});
</script>

<?php include 'footer.php'; ?>
