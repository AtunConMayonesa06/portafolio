<?php
include '../config/conexion.php';
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $usuario = $_POST['usuario'];
    $password = md5($_POST['password']);
    $rol = 'Cliente'; // Los nuevos usuarios siempre serán clientes

    // Validar si el usuario ya existe
    $check = $conn->query("SELECT * FROM usuarios WHERE usuario='$usuario'");
    if ($check->num_rows > 0) {
        $mensaje = "❌ Este usuario ya existe.";
    } else {
        $sql = "INSERT INTO usuarios (nombre, usuario, password, rol)
                VALUES ('$nombre', '$usuario', '$password', '$rol')";
        if ($conn->query($sql)) {
            header("Location: login.php?registro=ok");
            exit;
        } else {
            $mensaje = "Error al registrar el usuario.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro - NIBARRA</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: linear-gradient(135deg, #007bff, #00d4ff);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.card {
    border-radius: 20px;
    box-shadow: 0px 5px 20px rgba(0,0,0,0.3);
}
</style>
</head>
<body>
<div class="card p-4" style="width:400px;">
    <h3 class="text-center text-primary mb-3">Crear cuenta nueva</h3>

    <?php if ($mensaje): ?>
        <div class="alert alert-danger"><?= $mensaje ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Nombre completo</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Usuario</label>
            <input type="text" name="usuario" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-success w-100" type="submit">Registrarme</button>
        <div class="text-center mt-3">
            <a href="login.php">¿Ya tienes cuenta? Inicia sesión</a>
        </div>
    </form>
</div>
</body>
</html>
