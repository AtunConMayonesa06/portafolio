<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
include 'header.php';
include '../config/conexion.php';

$usuario_id = $_SESSION['usuario_id'];
$rol = $_SESSION['rol'];
?>

<h2>Calendario de Equipos y Mantenimientos</h2>
<p>
  Visualiza las fechas de ingreso (<span style="color:#007bff;">azul</span>) 
  y mantenimientos programados (<span style="color:#28a745;">verde</span>).
  <?php if ($rol === 'admin'): ?>
    Los administradores pueden ver todos los equipos y mantenimientos.
  <?php else: ?>
    Solo se muestran tus equipos y mantenimientos.
  <?php endif; ?>
</p>

<!-- Controles -->
<div class="calendar-controls" style="text-align:center; margin:20px;">
  <label for="yearSelect">Año:</label>
  <select id="yearSelect" class="form-select d-inline-block w-auto mx-2"></select>

  <label for="monthSelect">Mes:</label>
  <select id="monthSelect" class="form-select d-inline-block w-auto mx-2">
    <option value="0">Enero</option><option value="1">Febrero</option><option value="2">Marzo</option>
    <option value="3">Abril</option><option value="4">Mayo</option><option value="5">Junio</option>
    <option value="6">Julio</option><option value="7">Agosto</option><option value="8">Septiembre</option>
    <option value="9">Octubre</option><option value="10">Noviembre</option><option value="11">Diciembre</option>
  </select>

  <button id="goToDate" class="btn btn-primary btn-sm">Ir</button>
</div>

<div id="calendar"></div>

<link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const calendarEl = document.getElementById('calendar');
  const yearSelect = document.getElementById('yearSelect');
  const monthSelect = document.getElementById('monthSelect');
  const goToDateBtn = document.getElementById('goToDate');

  // Cargar años dinámicamente
  for (let y = 2010; y <= 2035; y++) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === new Date().getFullYear()) opt.selected = true;
    yearSelect.appendChild(opt);
  }

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    locale: 'es',
    height: 'auto',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,listMonth'
    },
    events: [
      <?php
      // 🟦 EVENTOS DE INGRESO DE EQUIPOS
      $rol = strtolower($_SESSION['rol']); // estandarizamos en minúsculas

      if ($rol === 'administrador') {
          $equipos_sql = "
            SELECT e.id, e.nombre_equipo, e.tipo, e.estado, e.fecha_ingreso, e.descripcion,
                   u.nombre AS propietario
            FROM equipos e
            LEFT JOIN usuarios u ON e.usuario_id = u.id
          ";
      } else {
          $equipos_sql = "
            SELECT e.id, e.nombre_equipo, e.tipo, e.estado, e.fecha_ingreso, e.descripcion,
                   'Tú' AS propietario
            FROM equipos e
            WHERE e.usuario_id = $usuario_id
          ";
      }

      $equipos_result = $conn->query($equipos_sql);
      if ($equipos_result && $equipos_result->num_rows > 0):
        while ($row = $equipos_result->fetch_assoc()):
      ?>
      {
        title: "💠 Ingreso: <?= addslashes($row['nombre_equipo']) ?>",
        start: "<?= $row['fecha_ingreso'] ?>",
        color: "#007bff",
        description: "Propietario: <?= addslashes($row['propietario']) ?>\nTipo: <?= addslashes($row['tipo']) ?>\nEstado: <?= addslashes($row['estado']) ?>\nDescripción: <?= addslashes($row['descripcion']) ?>",
      },
      <?php 
        endwhile;
      endif; 
      ?>

      <?php
      // 🟩 EVENTOS DE MANTENIMIENTOS
      if ($rol === 'administrador') {
          $mant_sql = "
            SELECT m.id, m.fecha_programada, m.tipo_mantenimiento, m.estado, m.porcentaje, m.observaciones,
                   e.nombre_equipo, e.tipo, u.nombre AS propietario
            FROM mantenimientos m
            INNER JOIN equipos e ON m.equipo_id = e.id
            LEFT JOIN usuarios u ON e.usuario_id = u.id
          ";
      } else {
          $mant_sql = "
            SELECT m.id, m.fecha_programada, m.tipo_mantenimiento, m.estado, m.porcentaje, m.observaciones,
                   e.nombre_equipo, e.tipo, 'Tú' AS propietario
            FROM mantenimientos m
            INNER JOIN equipos e ON m.equipo_id = e.id
            WHERE e.usuario_id = $usuario_id
          ";
      }

      $mant_result = $conn->query($mant_sql);
      if ($mant_result && $mant_result->num_rows > 0):
        while ($row = $mant_result->fetch_assoc()):
      ?>
      {
        title: "🛠 Mantenimiento: <?= addslashes($row['nombre_equipo']) ?>",
        start: "<?= $row['fecha_programada'] ?>",
        color: "#28a745",
        description: "Propietario: <?= addslashes($row['propietario']) ?>\nTipo mantenimiento: <?= addslashes($row['tipo_mantenimiento']) ?>\nEstado: <?= addslashes($row['estado']) ?>\nAvance: <?= $row['porcentaje'] ?>%\nObservaciones: <?= addslashes($row['observaciones']) ?>",
      },
      <?php 
        endwhile;
      endif; 
      ?>
    ],
    eventClick: function(info) {
      alert("📅 " + info.event.title + "\n" + info.event.extendedProps.description + "\nFecha: " + info.event.start.toLocaleDateString());
    }
  });

  calendar.render();

  // Botón de salto a mes/año
  goToDateBtn.addEventListener('click', function() {
    const year = parseInt(yearSelect.value);
    const month = parseInt(monthSelect.value);
    calendar.gotoDate(new Date(year, month, 1));
  });
});
</script>


<style>
#calendar {
  max-width: 900px;
  margin: 40px auto;
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.fc-toolbar-title { color: #004aad; }
.fc-daygrid-day-number { color: #333; font-weight: bold; }
.fc-event { border-radius: 6px !important; }
</style>

<?php include 'footer.php'; ?>
