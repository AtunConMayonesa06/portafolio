<?php
session_start();
include '../config/conexion.php';

$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM usuarios WHERE usuario='$usuario' AND password='$password'";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows > 0) {
        $usuario_data = $resultado->fetch_assoc();

        // Guardamos los datos importantes en la sesión
        $_SESSION['usuario'] = $usuario_data['usuario'];
        $_SESSION['usuario_id'] = $usuario_data['id']; 
        $_SESSION['nombre'] = $usuario_data['nombre'];
        $_SESSION['rol'] = $usuario_data['rol']; // admin o usuario

        // Redirigir al dashboard
        header("Location: dashboard.php");
        exit;
    } else {
        $mensaje = "❌ Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Iniciar sesión - NIBARRA</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.card {
    border-radius: 20px;
    box-shadow: 0px 5px 25px rgba(0,0,0,0.4);
}
.btn-primary {
    background-color: #007bff;
    border: none;
    transition: all 0.3s;
}
.btn-primary:hover {
    background-color: #0056b3;
}
</style>
</head>
<body>
<div class="card p-4 text-center" style="width:400px;">
    <h3 class="text-primary mb-3">Sistema NIBARRA</h3>
    <h5 class="mb-3">Acceso al Sistema</h5>

    <?php if ($mensaje): ?>
        <div class="alert alert-danger"><?= $mensaje ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['registro']) && $_GET['registro'] == 'ok'): ?>
        <div class="alert alert-success">✅ Registro exitoso, ahora puedes iniciar sesión.</div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <input type="text" name="usuario" class="form-control" placeholder="Usuario" required>
        </div>
        <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Contraseña" required>
        </div>
        <button class="btn btn-primary w-100 mb-2">Ingresar</button>
    </form>

    <a href="registro.php" class="text-decoration-none">🔹 Crear cuenta nueva</a>
</div>
</body>
</html>
