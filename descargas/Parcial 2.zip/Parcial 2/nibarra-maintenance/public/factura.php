<?php
require_once '../config/conexion.php';
require_once '../vendor/autoload.php'; // solo si usas composer con dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

// Obtener ID del equipo desde la URL
$id_equipo = $_GET['id'] ?? null;

if (!$id_equipo) {
    die("ID de equipo no especificado.");
}

// Obtener datos del equipo (ajusta los nombres de las columnas a tu tabla)
$sql = "SELECT e.id, e.nombre_equipo, e.descripcion, e.costo, e.fecha_ingreso, u.nombre AS usuario 
        FROM equipos e
        LEFT JOIN usuarios u ON e.usuario_id = u.id
        WHERE e.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_equipo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Equipo no encontrado.");
}

$equipo = $result->fetch_assoc();

// Calcular ITBMS y total
$subtotal = $equipo['costo'];
$itbms = $subtotal * 0.07;
$total = $subtotal + $itbms;

// Configurar Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);

// Contenido HTML de la factura
$html = "
<style>
body { font-family: DejaVu Sans, sans-serif; }
h1, h2, h3 { margin: 0; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
th, td { border: 1px solid #000; padding: 8px; text-align: left; }
tfoot td { font-weight: bold; }
.header { text-align: center; margin-bottom: 20px; }
.footer { margin-top: 30px; text-align: center; font-size: 12px; color: #555; }
</style>

<div class='header'>
  <h1>NIBARRA</h1>
  <h3>Factura de Servicio</h3>
  <p><strong>Fecha:</strong> " . date('d/m/Y') . "</p>
</div>

<table>
  <tr>
    <th>ID del Equipo</th>
    <td>{$equipo['id']}</td>
  </tr>
  <tr>
    <th>Nombre del Equipo</th>
    <td>{$equipo['nombre_equipo']}</td>
  </tr>
  <tr>
    <th>Descripción</th>
    <td>{$equipo['descripcion']}</td>
  </tr>
  <tr>
    <th>Usuario Asociado</th>
    <td>{$equipo['usuario']}</td>
  </tr>
  <tr>
    <th>Fecha de Ingreso</th>
    <td>{$equipo['fecha_ingreso']}</td>
  </tr>
</table>

<h3>Detalles de Facturación</h3>
<table>
  <thead>
    <tr>
      <th>Concepto</th>
      <th>Subtotal (USD)</th>
      <th>ITBMS (7%)</th>
      <th>Total (USD)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mantenimiento y servicio técnico</td>
      <td>" . number_format($subtotal, 2) . "</td>
      <td>" . number_format($itbms, 2) . "</td>
      <td>" . number_format($total, 2) . "</td>
    </tr>
  </tbody>
</table>

<div class='footer'>
  <p>Gracias por confiar en NIBARRA. Este documento es una factura digital.</p>
</div>
";

// Generar PDF
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Mostrar directamente en el navegador
$dompdf->stream("Factura_Equipo_{$equipo['id']}.pdf", ["Attachment" => false]);
exit;
?>
