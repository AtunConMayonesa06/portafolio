<?php
// Asegurar rutas absolutas correctas
require __DIR__ . '/../vendor/autoload.php';
use Dompdf\Dompdf;

include __DIR__ . '/../config/conexion.php';
session_start();

$usuario_id = $_SESSION['usuario_id'] ?? 0;

$html = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nueva factura
    $equipo_id = $_POST['equipo_id'] ?? 0;
    $cliente = $_POST['cliente'] ?? '';
    $equipo = $_POST['equipo'] ?? '';
    $servicios = $_POST['servicio'] ?? [];
    $precios = $_POST['precio'] ?? [];

    $subtotal = 0;
    $html .= '<h2>Factura NIBARRA</h2>';
    $html .= '<p><strong>Cliente:</strong> ' . htmlspecialchars($cliente) . '</p>';
    $html .= '<p><strong>Equipo:</strong> ' . htmlspecialchars($equipo) . '</p>';
    $html .= '<table border="1" cellpadding="5" cellspacing="0" width="100%">';
    $html .= '<tr><th>Servicio</th><th>Precio</th></tr>';

    $servicios_completos = [];
    foreach ($servicios as $i => $serv) {
        $precio = floatval($precios[$i] ?? 0);
        $subtotal += $precio;
        $servicios_completos[] = ['nombre' => $serv, 'precio' => $precio];
        $html .= '<tr><td>' . htmlspecialchars($serv) . '</td><td>$' . number_format($precio, 2) . '</td></tr>';
    }

    $itbms = $subtotal * 0.07;
    $total = $subtotal + $itbms;

    $html .= '<tr><td><strong>Subtotal</strong></td><td>$' . number_format($subtotal, 2) . '</td></tr>';
    $html .= '<tr><td><strong>ITBMS 7%</strong></td><td>$' . number_format($itbms, 2) . '</td></tr>';
    $html .= '<tr><td><strong>Total</strong></td><td>$' . number_format($total, 2) . '</td></tr>';
    $html .= '</table>';

    // Guardar en la base de datos
    $servicios_json = json_encode($servicios_completos, JSON_UNESCAPED_UNICODE);
    $stmt = $conn->prepare("INSERT INTO facturas (usuario_id, equipo_id, cliente, equipo, servicios, subtotal, itbms, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisssddd", $usuario_id, $equipo_id, $cliente, $equipo, $servicios_json, $subtotal, $itbms, $total);
    $stmt->execute();
    $stmt->close();

    // Mostrar PDF directamente al crear
    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream("factura_{$equipo}.pdf", ["Attachment" => false]);
    exit;

} elseif (isset($_GET['id'])) {
    // Ver factura existente
    $factura_id = intval($_GET['id']);
    $res = $conn->query("SELECT * FROM facturas WHERE id = $factura_id LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $f = $res->fetch_assoc();
        $cliente = $f['cliente'];
        $equipo = $f['equipo'];
        $servicios = json_decode($f['servicios'], true);
        $subtotal = $f['subtotal'];
        $itbms = $f['itbms'];
        $total = $f['total'];

        $html .= '<h2>Factura NIBARRA</h2>';
        $html .= '<p><strong>Cliente:</strong> ' . htmlspecialchars($cliente) . '</p>';
        $html .= '<p><strong>Equipo:</strong> ' . htmlspecialchars($equipo) . '</p>';
        $html .= '<table border="1" cellpadding="5" cellspacing="0" width="100%">';
        $html .= '<tr><th>Servicio</th><th>Precio</th></tr>';

        foreach ($servicios as $serv) {
            $nombre = htmlspecialchars($serv['nombre'] ?? '');
            $precio = number_format($serv['precio'] ?? 0, 2);
            $html .= "<tr><td>$nombre</td><td>\$$precio</td></tr>";
        }

        $html .= '<tr><td><strong>Subtotal</strong></td><td>$' . number_format($subtotal, 2) . '</td></tr>';
        $html .= '<tr><td><strong>ITBMS 7%</strong></td><td>$' . number_format($itbms, 2) . '</td></tr>';
        $html .= '<tr><td><strong>Total</strong></td><td>$' . number_format($total, 2) . '</td></tr>';
        $html .= '</table>';

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("factura_{$equipo}.pdf", ["Attachment" => false]);
        exit;
    } else {
        die("Factura no encontrada.");
    }
} else {
    die("No se especificó factura ni datos para generar.");
}
