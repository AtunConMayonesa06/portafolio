  </main>

  <footer class="site-footer bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
      <p class="m-0">&copy; <?= date('Y') ?> NIBARRA - Sistema de Mantenimiento</p>
    </div>
  </footer>

  <!-- Bootstrap JS (opcional, pero útil para componentes dinámicos) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
