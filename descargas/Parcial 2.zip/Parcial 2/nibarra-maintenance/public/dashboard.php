<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
?>

<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2>Bienvenido, <?= $_SESSION['nombre']; ?> 👋</h2>
    <p>Has ingresado como <strong><?= $_SESSION['rol']; ?></strong>.</p>

    <?php if ($_SESSION['rol'] == 'Administrador'): ?>
        <div class="alert alert-info">Tienes acceso total al sistema, incluyendo la gestión de equipos y mantenimientos.</div>
        <ul>
            <li><a href="equipos.php">Gestionar Equipos</a></li>
            <li><a href="mantenimiento.php">Ver Mantenimientos</a></li>
            <li><a href="calendar.php">Calendario</a></li>
        </ul>
    <?php else: ?>
        <div class="alert alert-warning">Como cliente, solo puedes ver los mantenimientos asignados a tus equipos.</div>
        <ul>
            <li><a href="calendar.php">Ver calendario</a></li>
        </ul>
    <?php endif; ?>

    <a href="logout.php" class="btn btn-danger mt-4">Cerrar sesión</a>
</div>

<?php include 'footer.php'; ?>
