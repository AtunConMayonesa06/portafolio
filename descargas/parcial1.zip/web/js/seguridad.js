// Bloquear clic derecho
document.addEventListener('contextmenu', event => event.preventDefault());

// Bloquear combinaciones de teclado para copiar
document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey && (e.key === 'c' || e.key === 'x' || e.key === 's')) || e.key === 'F12') {
        e.preventDefault();
    }
});
