<?php
session_start();
include(__DIR__ . '/conexion.php');
define('ITBMS', 0.07);

$carrito = $_SESSION['carrito'] ?? [];

// Eliminar producto
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    $_SESSION['carrito'] = array_filter($carrito, fn($p) => $p['id_producto'] != $id);
    header("Location: ver_carrito.php");
    exit;
}

// Vaciar carrito
if (isset($_POST['vaciar'])) {
    $_SESSION['carrito'] = [];
    header("Location: ver_carrito.php");
    exit;
}

// Total general
$total = 0;
foreach ($carrito as $item) {
    $total += $item['precio'] * $item['cantidad'];
}
$total_con_itbms = $total + ($total * ITBMS);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Carrito | Chinos Café</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #2e2b28, #1a120c);
      color: #fdfdfd;
      font-family: 'Poppins', sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
    }

    h1 {
      text-align: center;
      margin: 50px 0 40px;
      color: #f5c07a;
      font-weight: 700;
      text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
    }

    /* === TABLA DEL CARRITO === */
    .table-container {
      max-height: 420px;
      overflow-y: auto;
      overflow-x: hidden;
      scrollbar-width: thin;
      scrollbar-color: #f5c07a #3b2a1f;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0,0,0,0.5);
      background-color: #2b1f15;
      padding: 10px;
    }

    /* Scrollbar WebKit */
    .table-container::-webkit-scrollbar {
      width: 10px;
    }
    .table-container::-webkit-scrollbar-track {
      background: #3b2a1f;
      border-radius: 10px;
    }
    .table-container::-webkit-scrollbar-thumb {
      background-color: #f5c07a;
      border-radius: 10px;
      border: 2px solid #3b2a1f;
    }

    /* === CORRECCIÓN ZONA BLANCA === */
    table.table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 8px;
      color: #f5f5f5 !important;
      background-color: #2b1f15 !important;
    }

    thead {
      background-color: #4b3323 !important;
    }

    thead th {
      color: #ffd897 !important;
      text-transform: uppercase;
      font-weight: 600;
      border: none !important;
      background-color: #4b3323 !important;
    }

    tbody {
      background-color: #2b1f15 !important;
    }

    tbody tr {
      background-color: #3b2a1f !important;
      color: #f5f5f5 !important;
      transition: all 0.25s ease;
    }

    tbody tr:hover {
      background-color: #4c3423 !important;
      transform: scale(1.005);
    }

    td, th {
      vertical-align: middle !important;
      padding: 14px;
    }

    td img {
      border-radius: 8px;
      box-shadow: 0 0 6px rgba(0,0,0,0.5);
    }

    /* === BOTONES === */
    .btn-cafe {
      background-color: #f5c07a;
      color: #2a1f18;
      border: none;
      font-weight: 600;
      transition: all 0.3s ease;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    }

    .btn-cafe:hover {
      background-color: #ffcf87;
      color: #1a120c;
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0,0,0,0.4);
    }

    .btn-secondary {
      background-color: #7a7a7a;
      color: #fff;
      border: none;
      border-radius: 10px;
    }

    .btn-secondary:hover {
      background-color: #909090;
    }

    .btn-danger {
      border: none;
      font-weight: 600;
      background-color: #c04848;
      color: #fff;
      border-radius: 10px;
      transition: 0.3s;
    }

    .btn-danger:hover {
      background-color: #e05656;
      transform: translateY(-2px);
    }

    /* ✅ Botón verde elegante para Finalizar compra */
    .btn-finalizar {
      background: linear-gradient(135deg, #4CAF50, #5ed25e);
      color: #fff;
      border: none;
      font-weight: 700;
      border-radius: 10px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 6px rgba(0,0,0,0.4);
    }

    .btn-finalizar:hover {
      background: linear-gradient(135deg, #6fe86f, #4bd84b);
      color: #1a1a1a;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    }

    /* === TARJETA DE RESUMEN === */
    .card-resumen {
      background: #3b2a1f;
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 0 12px rgba(0,0,0,0.4);
      color: #f5f5f5;
    }

    .card-resumen p {
      margin: 0;
      font-size: 1rem;
      color: #f5f5f5;
    }

    .card-resumen hr {
      border-color: #f5c07a;
      opacity: 0.6;
    }

    .card-resumen strong {
      color: #f5c07a;
    }

    footer {
      background: #1a120c;
      color: #cfcfcf;
      margin-top: auto;
      box-shadow: 0 -3px 8px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>

<?php include(__DIR__ . '/includes/header.php'); ?>

<div class="container mb-5">
  <h1>🛍️ Tu Carrito</h1>

  <?php if (empty($carrito)): ?>
    <div class="alert alert-warning text-center shadow-lg rounded-3 mt-5">
      <strong>Tu carrito está vacío ☕</strong>
      <p class="mb-0 mt-2">Agrega tus productos favoritos desde la tienda.</p>
    </div>
    <div class="text-center mt-4">
      <a href="productos.php" class="btn btn-cafe btn-lg px-4 py-2 shadow">Volver a productos</a>
    </div>
  <?php else: ?>
    <form method="POST">
      <div class="table-container mb-4">
        <table class="table table-borderless text-center align-middle">
          <thead>
            <tr>
              <th>Imagen</th>
              <th>Producto</th>
              <th>Precio</th>
              <th>Cantidad</th>
              <th>Subtotal</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($carrito as $item): 
              $subtotal = $item['precio'] * $item['cantidad'];
            ?>
            <tr>
              <td><img src="/ChinosCafe/img_productos/<?= htmlspecialchars($item['imagen']) ?>" width="70"></td>
              <td class="fw-semibold"><?= htmlspecialchars($item['nombre']) ?></td>
              <td>$<?= number_format($item['precio'], 2) ?></td>
              <td><?= $item['cantidad'] ?></td>
              <td>$<?= number_format($subtotal, 2) ?></td>
              <td><a href="?eliminar=<?= $item['id_producto'] ?>" class="btn btn-danger btn-sm shadow-sm">🗑️</a></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="row mt-4">
        <div class="col-md-6"></div>
        <div class="col-md-6">
          <div class="card-resumen">
            <p><strong>Subtotal:</strong> $<?= number_format($total, 2) ?></p>
            <p><strong>ITBMS (7 %):</strong> $<?= number_format($total * ITBMS, 2) ?></p>
            <hr>
            <p class="fs-5"><strong>Total con ITBMS:</strong> $<?= number_format($total_con_itbms, 2) ?></p>
          </div>

          <div class="text-end mt-4">
            <a href="productos.php" class="btn btn-secondary me-2 px-4 py-2">⬅️ Seguir comprando</a>
            <button type="submit" name="vaciar" class="btn btn-danger px-4 py-2">Vaciar carrito</button>
            <a href="finalizar_compra.php" class="btn btn-finalizar px-4 py-2 ms-2">Finalizar compra ☕</a>
          </div>
        </div>
      </div>
    </form>
  <?php endif; ?>
</div>

<footer class="text-center py-4">
  <p class="mb-0">&copy; <?= date('Y') ?> <strong>Chinos Café</strong> — Todos los derechos reservados ☕</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
