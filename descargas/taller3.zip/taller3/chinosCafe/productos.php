<?php
include(__DIR__ . '/conexion.php');
session_start();

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

define('ITBMS', 0.07);
$mensaje = "";

// 🛒 Agregar producto al carrito
if (isset($_POST['agregar_carrito'])) {
    $id_producto = intval($_POST['id_producto']);
    $cantidad = intval($_POST['cantidad']);
    $query = $conn->query("SELECT * FROM inventario WHERE id_producto = $id_producto");
    $producto = $query->fetch_assoc();

    if ($producto && $producto['stock'] >= $cantidad) {
        $item = [
            'id_producto' => $producto['id_producto'],
            'nombre' => $producto['nombre'],
            'precio' => $producto['precio'],
            'cantidad' => $cantidad,
            'imagen' => $producto['imagen']
        ];

        $encontrado = false;
        foreach ($_SESSION['carrito'] as &$prod) {
            if ($prod['id_producto'] == $id_producto) {
                $prod['cantidad'] += $cantidad;
                $encontrado = true;
                break;
            }
        }
        if (!$encontrado) $_SESSION['carrito'][] = $item;
        $mensaje = "🛒 Producto agregado al carrito.";
    } else {
        $mensaje = "❌ No hay suficiente stock para agregar ese producto.";
    }
}

// 🔍 Filtrado por categoría
$categoriaSeleccionada = $_GET['categoria'] ?? 'todos';

// 🔄 Obtener categorías únicas de la BD
$categorias = [];
$resCat = $conn->query("SELECT DISTINCT categoria FROM inventario WHERE categoria IS NOT NULL AND categoria != ''");
while ($rowCat = $resCat->fetch_assoc()) {
    $categorias[] = $rowCat['categoria'];
}

// 📄 Paginación
$productosPorPagina = 8;
$paginaActual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($paginaActual - 1) * $productosPorPagina;

$filtroSQL = ($categoriaSeleccionada !== 'todos')
    ? "WHERE i.categoria = '" . $conn->real_escape_string($categoriaSeleccionada) . "'"
    : "";

$totalProductos = $conn->query("SELECT COUNT(*) AS total FROM inventario i $filtroSQL")->fetch_assoc()['total'];
$totalPaginas = ceil($totalProductos / $productosPorPagina);

$sql = "SELECT i.*, p.nombre AS proveedor 
        FROM inventario i
        LEFT JOIN proveedores p ON i.id_proveedor = p.id_proveedor
        $filtroSQL
        ORDER BY i.id_producto ASC
        LIMIT $productosPorPagina OFFSET $offset";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Productos | Chinos Café</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
       <style>
    body {
      background: #2a1f18;
      color: #f8f8f8;
      font-family: 'Poppins', sans-serif;
    }

    h1 {
      text-align: center;
      margin: 40px 0 20px;
      color: #f5c07a;
      font-weight: 700;
    }

    h1::after {
      content: "";
      display: block;
      width: 80px;
      height: 3px;
      background: #f5c07a;
      margin: 12px auto 0;
      border-radius: 3px;
    }

    /* === SECCIONES (Categorías) === */
    .categorias-container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 25px;
      padding: 10px 0;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .categoria-btn {
      margin: 3px;
      border-radius: 30px;
      font-weight: 500;
      background: #5c4033;
      color: #fff;
      padding: 8px 20px;
      font-size: 0.9rem;
      border: none;
      transition: all 0.3s ease;
      box-shadow: 0 2px 6px rgba(0,0,0,0.4);
    }

    .categoria-btn.active,
    .categoria-btn:hover {
      background: #f5c07a;
      color: #2a1f18;
      transform: translateY(-2px);
      box-shadow: 0 3px 10px rgba(0,0,0,0.5);
    }

    .card-producto {
      background: #3b2416;
      border: none;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 6px 20px rgba(0,0,0,0.6);
      transition: transform 0.3s ease;
    }

    .card-producto:hover {
      transform: translateY(-5px);
    }

    .card-producto img {
      width: 100%;
      height: 220px;
      object-fit: cover;
    }

    .card-body h5 {
      color: #f5c07a;
      font-weight: 600;
    }

    /* ✅ Descripción del producto visible */
    .card-body p.text-muted {
      color: #f0e1d2 !important;  /* tono crema claro */
      font-size: 0.9rem;
      line-height: 1.4;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6); /* mejora la legibilidad */
      margin-bottom: 8px;
    }

    .text-muted {
      color: #e0d6cf !important;
    }

    /* === BOTONES === */
    .btn-cafe {
      background-color: #f5c07a !important;
      color: #2a1f18 !important;
      border: none !important;
      font-weight: 600;
      transition: 0.3s;
      box-shadow: 0 2px 6px rgba(0,0,0,0.4);
    }

    .btn-cafe:hover {
      background-color: #ffcf87 !important;
      color: #1a120c !important;
      transform: scale(1.02);
      box-shadow: 0 4px 10px rgba(0,0,0,0.5);
    }

    form .btn-cafe {
      display: block;
      width: 100%;
      font-size: 0.95rem;
      letter-spacing: 0.3px;
      text-transform: uppercase;
      border-radius: 10px;
    }

    .btn-secondary {
      background-color: #7b675a !important;
      color: #eaeaea !important;
      font-weight: 600;
      border: none !important;
    }

    a.btn-cafe {
      background-color: #f5c07a !important;
      color: #2a1f18 !important;
      font-weight: 600;
      border-radius: 25px;
      padding: 8px 18px;
      text-decoration: none;
    }

    a.btn-cafe:hover {
      background-color: #ffcf87 !important;
      color: #1a120c !important;
    }

    .pagination .page-link {
      background: #5c4033;
      color: #fff;
      border: none;
    }

    .pagination .page-link:hover,
    .pagination .active .page-link {
      background: #f5c07a;
      color: #2a1f18;
    }

    footer {
      background: #1a120c;
      color: #f8f8f8;
      font-size: 0.9rem;
      padding: 15px 0;
      margin-top: 40px;
    }
  </style>



</head>
<body>

<?php include(__DIR__ . '/includes/header.php'); ?>

<div class="container">
  <h1>☕ Nuestros Productos</h1>

  <?php if (!empty($mensaje)): ?>
    <div class="alert alert-info text-center"><?= $mensaje ?></div>
  <?php endif; ?>

  <div class="categorias-container">
  <a href="?categoria=todos" class="categoria-btn <?= $categoriaSeleccionada === 'todos' ? 'active' : '' ?>">Todos</a>
  <?php foreach ($categorias as $cat): ?>
    <a href="?categoria=<?= urlencode($cat) ?>" class="categoria-btn <?= $categoriaSeleccionada === $cat ? 'active' : '' ?>">
      <?= htmlspecialchars(ucfirst($cat)) ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="text-end mb-4">
  <a href="ver_carrito.php" class="btn btn-cafe">🛍️ Ver Carrito (<?= count($_SESSION['carrito']) ?>)</a>
</div>


  <div class="row g-4">
    <?php while ($producto = $result->fetch_assoc()): 
        $precio_con_itbms = $producto['precio'] + ($producto['precio'] * ITBMS);
        $imagen = '/ChinosCafe/img_productos/' . htmlspecialchars($producto['imagen']);
        $disponible = $producto['stock'] > 0;
    ?>
      <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="card-producto text-center">
          <img src="<?= $imagen ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>">
          <div class="card-body">
            <h5><?= htmlspecialchars($producto['nombre']) ?></h5>
            <p class="text-muted small mb-1"><?= htmlspecialchars($producto['descripcion']) ?></p>
            <p class="mb-1"><strong>Proveedor:</strong> <?= htmlspecialchars($producto['proveedor'] ?? 'No asignado') ?></p>
            <p class="mb-1"><strong>Precio:</strong> $<?= number_format($precio_con_itbms, 2) ?></p>
            <p class="mb-2"><strong>Stock:</strong> <?= $producto['stock'] ?></p>

            <?php if ($disponible): ?>
              <form method="POST">
                <input type="hidden" name="id_producto" value="<?= $producto['id_producto'] ?>">
                <div class="mb-2">
                  <input type="number" name="cantidad" min="1" max="<?= $producto['stock'] ?>" value="1" class="form-control text-center">
                </div>
                <button type="submit" name="agregar_carrito" class="btn btn-cafe w-100">Agregar al Carrito</button>
              </form>
            <?php else: ?>
              <button class="btn btn-secondary w-100" disabled>Sin Stock</button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>

  <!-- 🔄 Paginación -->
  <?php if ($totalPaginas > 1): ?>
    <nav class="mt-5">
      <ul class="pagination justify-content-center">
        <li class="page-item <?= $paginaActual <= 1 ? 'disabled' : '' ?>">
          <a class="page-link" href="?categoria=<?= urlencode($categoriaSeleccionada) ?>&pagina=<?= $paginaActual - 1 ?>">«</a>
        </li>
        <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
          <li class="page-item <?= $paginaActual == $i ? 'active' : '' ?>">
            <a class="page-link" href="?categoria=<?= urlencode($categoriaSeleccionada) ?>&pagina=<?= $i ?>"><?= $i ?></a>
          </li>
        <?php endfor; ?>
        <li class="page-item <?= $paginaActual >= $totalPaginas ? 'disabled' : '' ?>">
          <a class="page-link" href="?categoria=<?= urlencode($categoriaSeleccionada) ?>&pagina=<?= $paginaActual + 1 ?>">»</a>
        </li>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<footer class="text-center py-4 mt-5" style="background:#1a120c;">
  <p class="mb-0 text-light">&copy; <?= date('Y') ?> Chinos Café. Todos los derechos reservados.</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
