<?php
// Session segura (evita el notice si ya está iniciada)
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

include(__DIR__ . '/conexion.php');

/* ========= Config ========= */
$carpeta_imagenes = __DIR__ . '/img_productos/';
if (!is_dir($carpeta_imagenes)) mkdir($carpeta_imagenes, 0777, true);

// Configuración de límites
$MAX_PRECIO = 1000.00;
$MAX_STOCK = 999;
$MAX_NOMBRE = 80;
$MAX_DESCRIPCION = 500;

/* ========= Helper: subir imagen ========= */
function subir_imagen($campo, $destino) {
  if (!isset($_FILES[$campo]) || $_FILES[$campo]['error'] !== 0) return '';
  $tmp  = $_FILES[$campo]['tmp_name'];
  $orig = basename($_FILES[$campo]['name']);
  $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
  $ok   = ['jpg','jpeg','png','gif','webp'];
  if (!in_array($ext, $ok)) return '';
  $nombre = time() . '_' . preg_replace("/[^a-zA-Z0-9._-]/", "_", $orig);
  return move_uploaded_file($tmp, $destino.$nombre) ? $nombre : '';
}

/* ========= Helper: validar datos ========= */
function validar_producto($nombre, $precio, $stock, $descripcion, $MAX_NOMBRE, $MAX_DESCRIPCION, $MAX_PRECIO, $MAX_STOCK) {
  $errores = [];
  
  // Validar nombre
  if (empty($nombre) || strlen(trim($nombre)) === 0) {
    $errores[] = "El nombre del producto es requerido";
  } elseif (strlen($nombre) > $MAX_NOMBRE) {
    $errores[] = "El nombre no puede exceder los $MAX_NOMBRE caracteres";
  } elseif (!preg_match('/^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-_.,!?()]+$/', $nombre)) {
    $errores[] = "El nombre contiene caracteres no permitidos";
  }
  
  // Validar precio
  if ($precio <= 0) {
    $errores[] = "El precio debe ser mayor a 0";
  } elseif ($precio > $MAX_PRECIO) {
    $errores[] = "El precio no puede exceder $" . number_format($MAX_PRECIO, 2);
  }
  
  // Validar stock
  if ($stock < 0) {
    $errores[] = "El stock no puede ser negativo";
  } elseif ($stock > $MAX_STOCK) {
    $errores[] = "El stock no puede exceder $MAX_STOCK unidades";
  }
  
  // Validar descripción
  if (strlen($descripcion) > $MAX_DESCRIPCION) {
    $errores[] = "La descripción no puede exceder los $MAX_DESCRIPCION caracteres";
  }
  
  return $errores;
}

/* ========= Acciones (PRG) ========= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $accion = $_POST['accion'] ?? '';

  if ($accion === 'agregar') {
    $nombre = trim($_POST['nombre'] ?? '');
    $precio = (float)($_POST['precio'] ?? 0);
    $stock  = (int)($_POST['stock'] ?? 0);
    $desc   = trim($_POST['descripcion'] ?? '');
    $id_proveedor = (int)($_POST['id_proveedor'] ?? 0);
    $categoria = trim($_POST['categoria'] ?? 'General');
    
    // Validaciones
    $errores = validar_producto($nombre, $precio, $stock, $desc, $MAX_NOMBRE, $MAX_DESCRIPCION, $MAX_PRECIO, $MAX_STOCK);
    
    // Validar proveedor
    if ($id_proveedor <= 0) {
      $errores[] = "Debe seleccionar un proveedor válido";
    }
    
    // Validar imagen (solo para agregar)
    if (!isset($_FILES['imagen']) || $_FILES['imagen']['error'] !== 0) {
      $errores[] = "La imagen es requerida";
    }
    
    if (empty($errores)) {
      $img = subir_imagen('imagen', $carpeta_imagenes);
      if ($img) {
        $stmt = $conn->prepare("INSERT INTO inventario (nombre, precio, stock, imagen, descripcion, id_proveedor, categoria) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sdissis", $nombre, $precio, $stock, $img, $desc, $id_proveedor, $categoria);

        $_SESSION['flash'] = $stmt->execute()
          ? ['tipo'=>'success','msg'=>'✅ Producto agregado correctamente.']
          : ['tipo'=>'error','msg'=>'❌ Error al agregar: '.$conn->error];
        $stmt->close();
      } else {
        $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ Error al subir la imagen. Asegúrate de que sea JPG, PNG, GIF o WEBP.'];
      }
    } else {
      $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ ' . implode('<br>', $errores)];
    }

    if (!headers_sent()) { header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    echo '<script>location.href = location.href;</script>'; exit;
  }

  if ($accion === 'editar') {
    $id     = (int)$_POST['id_producto'];
    $nombre = trim($_POST['nombre'] ?? '');
    $precio = (float)($_POST['precio'] ?? 0);
    $stock  = (int)($_POST['stock'] ?? 0);
    $desc   = trim($_POST['descripcion'] ?? '');
    $actual = $_POST['imagen_actual'] ?? '';
    $id_proveedor = (int)($_POST['id_proveedor'] ?? 0);
    $categoria = trim($_POST['categoria'] ?? 'General');
    
    // Validaciones (sin imagen requerida para editar)
    $errores = validar_producto($nombre, $precio, $stock, $desc, $MAX_NOMBRE, $MAX_DESCRIPCION, $MAX_PRECIO, $MAX_STOCK);
    
    // Validar proveedor
    if ($id_proveedor <= 0) {
      $errores[] = "Debe seleccionar un proveedor válido";
    }
    
    if (empty($errores)) {
      $nueva = '';
      if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === 0) {
        if ($actual && file_exists($carpeta_imagenes.$actual)) @unlink($carpeta_imagenes.$actual);
        $nueva = subir_imagen('imagen', $carpeta_imagenes);
        if (!$nueva) {
          $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ Error al subir la nueva imagen. Asegúrate de que sea JPG, PNG, GIF o WEBP.'];
          if (!headers_sent()) { header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
          echo '<script>location.href = location.href;</script>'; exit;
        }
      }
      $final = $nueva ?: $actual;

      $stmt = $conn->prepare("UPDATE inventario SET nombre=?, precio=?, stock=?, imagen=?, descripcion=?, id_proveedor=?, categoria=? WHERE id_producto=?");
      $stmt->bind_param("sdissisi", $nombre, $precio, $stock, $final, $desc, $id_proveedor, $categoria, $id);
      $_SESSION['flash'] = $stmt->execute()
        ? ['tipo'=>'success','msg'=>'✏️ Producto actualizado correctamente.']
        : ['tipo'=>'error','msg'=>'❌ Error al actualizar: '.$conn->error];
      $stmt->close();
    } else {
      $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ ' . implode('<br>', $errores)];
    }

    if (!headers_sent()) { header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    echo '<script>location.href = location.href;</script>'; exit;
  }

  if ($accion === 'eliminar') {
    $id = (int)$_POST['id'];

    $res = $conn->prepare("SELECT imagen FROM inventario WHERE id_producto=?");
    $res->bind_param("i",$id);
    $res->execute();
    $res->bind_result($img);
    $res->fetch();
    $res->close();

    if (!empty($img) && file_exists($carpeta_imagenes.$img)) @unlink($carpeta_imagenes.$img);

    $del = $conn->prepare("DELETE FROM inventario WHERE id_producto=?");
    $del->bind_param("i",$id);
    $_SESSION['flash'] = $del->execute()
      ? ['tipo'=>'success','msg'=>'🗑️ Producto eliminado correctamente.']
      : ['tipo'=>'error','msg'=>'❌ Error al eliminar: '.$conn->error];
    $del->close();

    if (!headers_sent()) { header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    echo '<script>location.href = location.href;</script>'; exit;
  }
}

/* ========= Flash (GET) ========= */
$flash = $_SESSION['flash'] ?? null;
if ($flash) unset($_SESSION['flash']);
?>

<link rel="stylesheet" href="/ChinosCafe/css/productos_paneladmin.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<div class="acciones-superiores">
  <a href="admin_panel.php" class="btn-volver">⬅️ Volver al Dashboard</a>
</div>

<h2>🛍️ Gestión de Productos</h2>

<!-- AGREGAR -->
<form method="POST" action="" enctype="multipart/form-data" class="form-producto" id="form-agregar">
  <input type="hidden" name="accion" value="agregar">
  <div class="form-grid">
    <div>
      <label>Nombre del producto:</label>
      <input type="text" name="nombre" required maxlength="<?= $MAX_NOMBRE ?>" 
             placeholder="Máximo <?= $MAX_NOMBRE ?> caracteres"
             pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-_.,!?()]+"
             title="Solo letras, números, espacios y los siguientes caracteres: -_.,!?()">
      <small class="contador">Máximo <?= $MAX_NOMBRE ?> caracteres</small>
    </div>
    <div>
      <label>Precio (USD):</label>
      <input type="number" name="precio" step="0.01" min="0.01" max="<?= $MAX_PRECIO ?>" required 
             placeholder="Máximo $<?= number_format($MAX_PRECIO, 2) ?>">
      <small class="contador">Máximo $<?= number_format($MAX_PRECIO, 2) ?></small>
    </div>
    <div>
      <label>Stock:</label>
      <input type="number" name="stock" min="0" max="<?= $MAX_STOCK ?>" required 
             placeholder="Máximo <?= $MAX_STOCK ?> unidades">
      <small class="contador">Máximo <?= $MAX_STOCK ?> unidades</small>
    </div>
    <div>
      <label>Proveedor:</label>
      <select name="id_proveedor" required>
        <option value="">-- Selecciona un proveedor --</option>
        <?php
          $proveedores = $conn->query("SELECT id_proveedor, nombre FROM proveedores WHERE activo = 1 ORDER BY nombre ASC");
          while ($p = $proveedores->fetch_assoc()):
        ?>
          <option value="<?= $p['id_proveedor'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div>
      <label>Categoría:</label>
      <select name="categoria" required>
        <option value="">-- Selecciona una categoría --</option>
        <option value="General">General</option>
        <option value="Cafés">Cafés</option>
        <option value="Pasteles">Pasteles</option>
        <option value="Bebidas">Bebidas</option>
        <option value="Sandwiches">Sandwiches</option>
        <option value="Postres">Postres</option>
      </select>
    </div>
    <div>
      <label>Imagen:</label>
      <input type="file" name="imagen" id="imagenInput" accept="image/*" required>
      <small class="contador">Formatos: JPG, PNG, GIF, WEBP</small>
      <div id="preview" class="preview-img"></div>
    </div>
    <div class="descripcion">
      <label>Descripción:</label>
      <textarea name="descripcion" rows="3" maxlength="<?= $MAX_DESCRIPCION ?>" 
                placeholder="Máximo <?= $MAX_DESCRIPCION ?> caracteres"></textarea>
      <small class="contador">Máximo <?= $MAX_DESCRIPCION ?> caracteres</small>
    </div>
  </div>
  <button type="submit" class="btn-guardar">➕ Agregar Producto</button>
</form>

<hr>
<h3>📋 Lista de Productos</h3>

<?php 
$productos = $conn->query("
  SELECT i.*, p.nombre as nombre_proveedor 
  FROM inventario i 
  LEFT JOIN proveedores p ON i.id_proveedor = p.id_proveedor 
  ORDER BY i.id_producto DESC
");
?>
<div class="tabla-productos-container">
  <table class="tabla-productos">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Stock</th>
        <th>Proveedor</th>
        <th>Categoría</th>
        <th>Imagen</th>
        <th>Descripción</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($productos && $productos->num_rows > 0): ?>
        <?php while ($row = $productos->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['id_producto'] ?></td>
          <td><?= htmlspecialchars($row['nombre']) ?></td>
          <td>$<?= number_format((float)$row['precio'], 2) ?></td>
          <td><?= (int)$row['stock'] ?></td>
          <td><?= htmlspecialchars($row['nombre_proveedor'] ?? 'Sin proveedor') ?></td>
          <td><?= htmlspecialchars($row['categoria'] ?? 'General') ?></td>
          <td>
            <?php if (!empty($row['imagen'])): ?>
              <img src="/ChinosCafe/img_productos/<?= htmlspecialchars($row['imagen'], ENT_QUOTES) ?>" class="img-tabla" alt="producto">
            <?php else: ?>
              <span>—</span>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($row['descripcion']) ?></td>
          <td>
            <button type="button" class="btn-editar"
              onclick="abrirModalEditar(
                <?= (int)$row['id_producto'] ?>,
                '<?= htmlspecialchars($row['nombre'], ENT_QUOTES) ?>',
                <?= (float)$row['precio'] ?>,
                <?= (int)$row['stock'] ?>,
                '<?= htmlspecialchars($row['descripcion'], ENT_QUOTES) ?>',
                '<?= htmlspecialchars($row['imagen'], ENT_QUOTES) ?>',
                <?= (int)$row['id_proveedor'] ?>,
                '<?= htmlspecialchars($row['categoria'] ?? 'General', ENT_QUOTES) ?>'
              )">✏️</button>

            <form method="POST" action="" style="display:inline;">
              <input type="hidden" name="accion" value="eliminar">
              <input type="hidden" name="id" value="<?= (int)$row['id_producto'] ?>">
              <button type="submit" class="btn-eliminar" onclick="return confirm('¿Eliminar este producto?')">🗑️</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="9">No hay productos registrados.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- MODAL EDITAR -->
<div id="modalEditar" class="modal" style="display:none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h3>✏️ Editar Producto</h3>
    <form method="POST" action="" enctype="multipart/form-data" id="form-editar">
      <input type="hidden" name="accion" value="editar">
      <input type="hidden" name="id_producto" id="edit_id">
      <input type="hidden" name="imagen_actual" id="edit_imagen_actual">
      <div class="form-grid">
        <div>
          <label>Nombre:</label>
          <input type="text" name="nombre" id="edit_nombre" required maxlength="<?= $MAX_NOMBRE ?>"
                 pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-_.,!?()]+"
                 title="Solo letras, números, espacios y los siguientes caracteres: -_.,!?()">
          <small class="contador">Máximo <?= $MAX_NOMBRE ?> caracteres</small>
        </div>
        <div>
          <label>Precio (USD):</label>
          <input type="number" name="precio" id="edit_precio" step="0.01" min="0.01" max="<?= $MAX_PRECIO ?>" required>
          <small class="contador">Máximo $<?= number_format($MAX_PRECIO, 2) ?></small>
        </div>
        <div>
          <label>Stock:</label>
          <input type="number" name="stock" id="edit_stock" min="0" max="<?= $MAX_STOCK ?>" required>
          <small class="contador">Máximo <?= $MAX_STOCK ?> unidades</small>
        </div>
        <div>
          <label>Proveedor:</label>
          <select name="id_proveedor" id="edit_proveedor" required>
            <option value="">-- Selecciona un proveedor --</option>
            <?php
              $proveedores = $conn->query("SELECT id_proveedor, nombre FROM proveedores WHERE activo = 1 ORDER BY nombre ASC");
              while ($p = $proveedores->fetch_assoc()):
            ?>
              <option value="<?= $p['id_proveedor'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div>
          <label>Categoría:</label>
          <select name="categoria" id="edit_categoria" required>
            <option value="">-- Selecciona una categoría --</option>
            <option value="General">General</option>
            <option value="Cafés">Cafés</option>
            <option value="Pasteles">Pasteles</option>
            <option value="Bebidas">Bebidas</option>
            <option value="Sandwiches">Sandwiches</option>
            <option value="Postres">Postres</option>
          </select>
        </div>
        <div>
          <label>Nueva Imagen:</label>
          <input type="file" name="imagen" id="edit_imagen" accept="image/*">
          <small class="contador">Formatos: JPG, PNG, GIF, WEBP</small>
          <div id="previewEdit" class="preview-img"></div>
        </div>
        <div class="descripcion">
          <label>Descripción:</label>
          <textarea name="descripcion" id="edit_descripcion" rows="3" maxlength="<?= $MAX_DESCRIPCION ?>"></textarea>
          <small class="contador">Máximo <?= $MAX_DESCRIPCION ?> caracteres</small>
        </div>
      </div>
      <button type="submit" class="btn-guardar">💾 Guardar Cambios</button>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="/ChinosCafe/scripts/main.js"></script>
<script>
// Preview imagen en "Agregar"
document.getElementById('imagenInput')?.addEventListener('change', function() {
  const file = this.files[0];
  const preview = document.getElementById('preview');
  if (!preview) return;
  if (file) {
    const r = new FileReader();
    r.onload = e => preview.innerHTML = `<img src="${e.target.result}" class="img-tabla" alt="preview">`;
    r.readAsDataURL(file);
  } else {
    preview.innerHTML = '';
  }
});

// Modal Editar
const modal = document.getElementById('modalEditar');
const close = modal.querySelector('.close');
close.onclick = () => modal.style.display = 'none';
window.onclick = e => { if (e.target === modal) modal.style.display = 'none'; };

function abrirModalEditar(id, nombre, precio, stock, descripcion, imagen, id_proveedor, categoria) {
  document.getElementById('edit_id').value = id;
  document.getElementById('edit_nombre').value = nombre;
  document.getElementById('edit_precio').value = precio;
  document.getElementById('edit_stock').value = stock;
  document.getElementById('edit_descripcion').value = descripcion;
  document.getElementById('edit_imagen_actual').value = imagen || '';
  document.getElementById('edit_proveedor').value = id_proveedor || '';
  document.getElementById('edit_categoria').value = categoria || 'General';
  
  const prev = document.getElementById('previewEdit');
  prev.innerHTML = imagen ? `<img src="/ChinosCafe/img_productos/${imagen}" class="img-tabla" alt="actual">` : '';
  modal.style.display = 'block';
}

// Preview al cambiar imagen en "Editar"
document.getElementById('edit_imagen')?.addEventListener('change', function() {
  const file = this.files[0];
  const prev = document.getElementById('previewEdit');
  if (!prev) return;
  if (file) {
    const r = new FileReader();
    r.onload = e => prev.innerHTML = `<img src="${e.target.result}" class="img-tabla" alt="preview">`;
    r.readAsDataURL(file);
  } else {
    prev.innerHTML = '';
  }
});

// Validación en tiempo real para contadores
document.addEventListener('DOMContentLoaded', function() {
  // Contador para nombre
  const nombreInput = document.querySelector('input[name="nombre"]');
  const editNombreInput = document.getElementById('edit_nombre');
  
  function actualizarContador(input, max) {
    const contador = input.parentElement.querySelector('.contador');
    if (contador) {
      const actual = input.value.length;
      contador.textContent = `${actual}/${max} caracteres`;
      if (actual > max * 0.8) {
        contador.style.color = '#ff6b6b';
      } else {
        contador.style.color = '#666';
      }
    }
  }
  
  if (nombreInput) {
    nombreInput.addEventListener('input', function() {
      actualizarContador(this, <?= $MAX_NOMBRE ?>);
    });
    actualizarContador(nombreInput, <?= $MAX_NOMBRE ?>);
  }
  
  if (editNombreInput) {
    editNombreInput.addEventListener('input', function() {
      actualizarContador(this, <?= $MAX_NOMBRE ?>);
    });
  }
  
  // Contador para descripción
  const descInput = document.querySelector('textarea[name="descripcion"]');
  const editDescInput = document.getElementById('edit_descripcion');
  
  if (descInput) {
    descInput.addEventListener('input', function() {
      actualizarContador(this, <?= $MAX_DESCRIPCION ?>);
    });
    actualizarContador(descInput, <?= $MAX_DESCRIPCION ?>);
  }
  
  if (editDescInput) {
    editDescInput.addEventListener('input', function() {
      actualizarContador(this, <?= $MAX_DESCRIPCION ?>);
    });
  }
});
</script>

<?php if ($flash): ?>
<script>
Swal.fire({
  toast: true,
  position: 'top-end',
  icon: '<?= $flash['tipo'] ?>',
  title: '<?= $flash['msg'] ?>',
  showConfirmButton: false,
  timer: 2200,
  background: '#3b2f2f',
  color: '#f8efe2'
}); // Sin redirección: ya hicimos PRG y permaneces en la misma URL
</script>
<?php endif; ?>