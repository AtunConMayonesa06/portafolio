<?php
/**
 * 🔁 Sincronizador automático MySQL entre Ubuntu → Windows
 * Autor: Carlos Miranda - Chinos Café
 * PHP 8+
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('America/Panama');

// ===============================
// ⚙️ CONFIGURACIÓN
// ===============================
$origen = [
    'host' => '127.0.0.1',  // Ubuntu local
    'port' => 3307,
    'user' => 'root',
    'pass' => '', // tu clave
    'db'   => 'chinos_cafe_db'
];

$destino = [
    'host' => '192.168.0.8', // IP real del Windows
    'port' => 3307,
    'user' => 'root',
    'pass' => 'mysql',
    'db'   => 'chinos_cafe_db'
];

// ===============================
// 🔄 BUCLE DE SINCRONIZACIÓN CADA 6 SEGUNDOS
// ===============================
while (true) {

    echo "\n==============================\n";
    echo "⏰ " . date('Y-m-d H:i:s') . " — Iniciando sincronización...\n";

    // Conectar a ambas bases
    $src = @new mysqli($origen['host'], $origen['user'], $origen['pass'], $origen['db'], $origen['port']);
    $dst = @new mysqli($destino['host'], $destino['user'], $destino['pass'], $destino['db'], $destino['port']);

    if ($src->connect_error) {
        echo "❌ Error conexión origen: {$src->connect_error}\n";
        sleep(6);
        continue;
    }
    if ($dst->connect_error) {
        echo "❌ Error conexión destino: {$dst->connect_error}\n";
        $src->close();
        sleep(6);
        continue;
    }

    // Obtener todas las tablas
    $res = $src->query("SHOW TABLES");
    if (!$res) {
        echo "❌ Error al listar tablas: {$src->error}\n";
        $src->close();
        $dst->close();
        sleep(6);
        continue;
    }

    while ($row = $res->fetch_array()) {
        $tabla = $row[0];
        echo "\n📦 Sincronizando tabla: $tabla...\n";

        // Obtener datos del origen
        $resDatos = $src->query("SELECT * FROM `$tabla`");
        if (!$resDatos) {
            echo "⚠️ No se pudo leer $tabla: {$src->error}\n";
            continue;
        }

        // Vaciar tabla destino antes de replicar
        $dst->query("SET FOREIGN_KEY_CHECKS=0");
        $dst->query("TRUNCATE TABLE `$tabla`");

        // Preparar inserción
        $numCols = $resDatos->field_count;
        $placeholders = implode(',', array_fill(0, $numCols, '?'));
        $campos = [];

        while ($field = $resDatos->fetch_field()) {
            $campos[] = "`{$field->name}`";
        }

        $insertSQL = "INSERT INTO `$tabla` (" . implode(',', $campos) . ") VALUES ($placeholders)";
        $stmt = $dst->prepare($insertSQL);

        if (!$stmt) {
            echo "⚠️ Error preparando inserción en $tabla: {$dst->error}\n";
            continue;
        }

        while ($fila = $resDatos->fetch_row()) {
            $tipos = str_repeat('s', $numCols);
            $stmt->bind_param($tipos, ...$fila);
            $stmt->execute();
        }

        $stmt->close();
        echo "✅ $tabla replicada correctamente.\n";
    }

    $dst->query("SET FOREIGN_KEY_CHECKS=1");

    echo "🟢 Sincronización finalizada a las " . date('H:i:s') . "\n";
    echo "==============================\n";

    // Cerrar conexiones
    $src->close();
    $dst->close();

    // Esperar 6 segundos antes de la próxima sincronización
    sleep(6);
}
?>
