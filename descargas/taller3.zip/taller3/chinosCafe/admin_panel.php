<?php
include('conexion.php');
include('includes/header.php');

// 🔐 Solo admins pueden entrar
if (!isset($_SESSION['id_usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: index.php");
    exit();
}

/* ===============================
📊 CONSULTAS PARA DASHBOARD
=============================== */

// 🛒 Productos más vendidos (TOP 5)
$topProductos = $conn->query("
  SELECT i.nombre, SUM(v.cantidad) AS total_vendidos
  FROM ventas v
  JOIN inventario i ON v.id_producto = i.id_producto
  GROUP BY v.id_producto
  ORDER BY total_vendidos DESC
  LIMIT 5
");

// 👑 Clientes destacados (TOP 5)
$topClientes = $conn->query("
  SELECT c.nombre, COUNT(v.id_venta) AS total_compras
  FROM ventas v
  JOIN clientes c ON v.id_usuario = c.id_usuario
  GROUP BY v.id_usuario
  ORDER BY total_compras DESC
  LIMIT 5
");

// 📅 Resumen diario
$resumen = $conn->query("
  SELECT 
    SUM(total) AS ventas_hoy,
    COUNT(DISTINCT id_usuario) AS clientes_hoy,
    SUM(cantidad) AS productos_hoy
  FROM ventas
  WHERE DATE(fecha) = CURDATE()
")->fetch_assoc();

$ventasHoy = $resumen['ventas_hoy'] ?: 0;
$clientesHoy = $resumen['clientes_hoy'] ?: 0;
$productosHoy = $resumen['productos_hoy'] ?: 0;
?>

<link rel="stylesheet" href="/ChinosCafe/css/panel_admin.css">

<div class="admin-container">
  <aside class="sidebar">
    <h2 class="logo">☕ Chinos Café</h2>
    <ul class="menu">
      <li class="active" data-section="dashboard">📊 Dashboard</li>
      <li data-section="productos">🛍️ Productos</li>
      <li data-section="clientes">👥 Clientes</li>
      <li data-section="ventas">💰 Ventas</li>
      <li data-section="reportes">📈 Reportes</li>
      <li data-section="config">⚙️ Configuración</li>
    </ul>
  </aside>

  <main class="content">
    <!-- ======================= -->
    <!-- 📊 DASHBOARD PRINCIPAL -->
    <!-- ======================= -->
    <section id="dashboard" class="panel-section active">
      <h2>📊 Panel de Control</h2>
      <p>Bienvenido, <strong><?= htmlspecialchars($_SESSION['nombre']); ?></strong>.  
      Aquí puedes visualizar estadísticas reales del sistema de <strong>Chinos Café</strong>.</p>

      <div class="cards">
      <div class="card" data-section="productos">
        <h3>🛍️ Productos</h3>
        <p>Gestiona el inventario en tiempo real y controla existencias.</p>
      </div>
      <div class="card" data-section="clientes">
        <h3>👥 Clientes</h3>
        <p>Supervisa la actividad de tus clientes frecuentes.</p>
      </div>
      <div class="card" data-section="ventas">
        <h3>💰 Ventas</h3>
        <p>Consulta ingresos, totales y rendimiento diario.</p>
      </div>
      <div class="card" data-section="reportes">
        <h3>📈 Reportes</h3>
        <p>Analiza métricas, tendencias y comportamiento del mercado.</p>
      </div>
    </div>


      <!-- ======================= -->
      <!-- 🔸 NUEVAS SECCIONES -->
      <!-- ======================= -->
      <div class="dashboard-widgets">
        <!-- 🛒 Productos más vendidos -->
        <div class="widget ventas-top">
          <h3>🥇 Productos más vendidos</h3>
          <table class="mini-table">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Unidades</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($topProductos && $topProductos->num_rows > 0): ?>
                <?php while($p = $topProductos->fetch_assoc()): ?>
                  <tr>
                    <td><?= htmlspecialchars($p['nombre']); ?></td>
                    <td><?= (int)$p['total_vendidos']; ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="2">Sin ventas registradas.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- 👑 Clientes destacados -->
        <div class="widget clientes-top">
          <h3>👑 Clientes destacados</h3>
          <ul class="top-clientes">
            <?php if ($topClientes && $topClientes->num_rows > 0): ?>
              <?php while($c = $topClientes->fetch_assoc()): ?>
                <li><strong><?= htmlspecialchars($c['nombre']); ?></strong> — <?= (int)$c['total_compras']; ?> compras ☕</li>
              <?php endwhile; ?>
            <?php else: ?>
              <li>No hay clientes con compras registradas.</li>
            <?php endif; ?>
          </ul>
        </div>

        <!-- 📅 Resumen rápido -->
        <div class="widget resumen-diario">
          <h3>📅 Resumen de hoy</h3>
          <div class="resumen-grid">
            <div class="dato">
              <h4>Ventas de hoy</h4>
              <p><strong>$<?= number_format($ventasHoy, 2); ?></strong></p>
            </div>
            <div class="dato">
              <h4>Clientes atendidos</h4>
              <p><strong><?= (int)$clientesHoy; ?></strong></p>
            </div>
            <div class="dato">
              <h4>Productos vendidos</h4>
              <p><strong><?= (int)$productosHoy; ?></strong></p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ======================= -->
    <!-- 🛍️ SECCIÓN PRODUCTOS -->
    <!-- ======================= -->
    <section id="productos" class="panel-section">
      <?php include('productos_adminpanel.php'); ?>
    </section>

    <!-- ======================= -->
    <!-- 👥 SECCIÓN CLIENTES -->
    <!-- ======================= -->
    <section id="clientes" class="panel-section">
      <?php include('clientes_adminpanel.php'); ?>
    </section>

    <!-- ======================= -->
    <!-- 💰 SECCIÓN VENTAS -->
    <!-- ======================= -->
    <section id="ventas" class="panel-section">
      <?php include('ventas_adminpanel.php'); ?>
    </section>

    <!-- ======================= -->
    <!-- 📈 SECCIÓN REPORTES -->
    <!-- ======================= -->
    <section id="reportes" class="panel-section">
      <?php include('reportes_adminpanel.php'); ?>
    </section>

    <!-- ======================= -->
    <!-- ⚙️ CONFIGURACIÓN -->
    <!-- ======================= -->
    <section id="config" class="panel-section">
      <?php include('config_adminpanel.php'); ?>
    </section>
  </main>
</div>

<script>
document.querySelectorAll('.menu li').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.menu li').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.panel-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(btn.dataset.section).classList.add('active');
  });
});
</script>

<script>
// 🔄 Navegación de menú lateral
document.querySelectorAll('.menu li').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.menu li').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.panel-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(btn.dataset.section).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

// 🧭 NUEVO: Hacer las tarjetas clicables
document.querySelectorAll('.card').forEach(card => {
  card.addEventListener('click', () => {
    const target = card.dataset.section;
    if (!target) return;

    // Simular clic en el botón del menú correspondiente
    const menuItem = document.querySelector(`.menu li[data-section="${target}"]`);
    if (menuItem) menuItem.click();

    // Transición suave al contenido
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Cursor tipo mano para indicar que son clicables
  card.style.cursor = 'pointer';
});
</script>


<style>
.dashboard-widgets {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(290px, 1fr));
  gap: 1.5rem;
  margin-top: 2rem;
}

.widget {
  background: var(--blanco);
  border: 1px solid #e6d7c3;
  border-radius: 14px;
  padding: 1.4rem 1.6rem;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
}

.widget:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
}

.widget h3 {
  font-size: 1.1rem;
  color: var(--cafe-oscuro);
  border-bottom: 2px solid var(--cafe-claro);
  padding-bottom: 6px;
  margin-bottom: 1rem;
}

.mini-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}
.mini-table th {
  background: var(--cafe-medio);
  color: var(--blanco);
  padding: 8px;
}
.mini-table td {
  padding: 8px;
  border-bottom: 1px solid #f0e2cf;
}

.top-clientes {
  list-style: none;
  padding: 0;
  margin: 0;
}
.top-clientes li {
  padding: 8px 0;
  border-bottom: 1px solid #f0e2cf;
  color: var(--text-dark);
}
.top-clientes li strong {
  color: var(--cafe-oscuro);
}

.resumen-grid {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 1rem;
  text-align: center;
}
.dato {
  flex: 1;
  min-width: 100px;
  background: #fffaf3;
  border: 1px solid #f0e2cf;
  border-radius: 10px;
  padding: 1rem;
}
.dato h4 {
  font-size: 0.9rem;
  color: var(--cafe-medio);
}
.dato p {
  font-size: 1.1rem;
  color: var(--cafe-oscuro);
  margin-top: 4px;
  font-weight: bold;
}

@media (max-width: 768px) {
  .dashboard-widgets {
    grid-template-columns: 1fr;
  }
}

/* 🧾 Scroll interno para widgets largos */
.widget .mini-table tbody,
.widget .top-clientes {
  max-height: 200px;         /* altura máxima antes de mostrar scroll */
  overflow-y: auto;          /* habilita scroll vertical */
  display: block;            /* permite que el scroll funcione dentro */
  scrollbar-width: thin;     /* scroll más delgado (Firefox) */
  scrollbar-color: #b58b55 #f5e8d3; /* colores del scroll */
}

/* Ajustar columnas de tabla al usar display:block */
.mini-table thead,
.mini-table tbody tr {
  display: table;
  width: 100%;
  table-layout: fixed;
}

/* Opcional: mejorar apariencia del scroll en Webkit (Chrome/Edge) */
.widget .mini-table tbody::-webkit-scrollbar,
.widget .top-clientes::-webkit-scrollbar {
  width: 6px;
}
.widget .mini-table tbody::-webkit-scrollbar-thumb,
.widget .top-clientes::-webkit-scrollbar-thumb {
  background-color: #c9a46c;
  border-radius: 3px;
}

</style>

<?php include('includes/footer.php'); ?>
