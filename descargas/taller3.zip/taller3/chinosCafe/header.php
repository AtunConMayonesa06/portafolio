<?php
// -----------------------------------------------------------------------------
// ⚙️ Cabeceras de seguridad (se ejecutan ANTES de cualquier salida HTML)
// -----------------------------------------------------------------------------
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer-when-downgrade');
    header("Content-Security-Policy: default-src 'self' https: data: 'unsafe-inline'; img-src 'self' data: https:; script-src 'self' https: 'unsafe-inline'; style-src 'self' https: 'unsafe-inline';");
}

// -----------------------------------------------------------------------------
// 🧠 Iniciar sesión si no existe aún
// -----------------------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Activar buffer de salida para evitar errores "headers already sent"
ob_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chinos Café | Sistema POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/ChinosCafe/css/estilos.css" rel="stylesheet">

    <style>
        /* 🎨 Estilos generales del navbar */
        .navbar.bg-brown {
            background-color: #2b1b13 !important;
        }

        .navbar .nav-link {
            color: #fff !important;
            font-weight: 500;
            transition: color 0.3s ease, transform 0.2s ease;
        }

        .navbar .nav-link:hover {
            color: #d4a373 !important;
            transform: translateY(-1px);
        }

        /* Menú desplegable (3 rayas) */
        .dropdown-menu-dark {
            background-color: #2b1b13;
            border: 1px solid #3e2723;
        }

        .dropdown-item:hover {
            background-color: #3e2723;
            color: #d4a373;
        }

        .menu-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.4rem;
            cursor: pointer;
        }

        body {
            background: linear-gradient(135deg, #4A3426 0%, #2A1A0F 100%) !important;
            color: #E6D5B8;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
    </style>

    <!-- Script principal -->
    <script src="/ChinosCafe/scripts/main.js" defer></script>
</head>

<body class="bg-dark text-light">

<!-- 🔝 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-brown shadow-sm sticky-top">
    <div class="container">
        <!-- ☕ Logo -->
        <a class="navbar-brand fw-bold" href="/ChinosCafe/index.php">
            ☕ Chinos Café
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item">
                    <a class="nav-link" href="/ChinosCafe/productos.php">🛍️ Productos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/ChinosCafe/nosotros.php">👥 Nosotros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/ChinosCafe/sucursales.php">📍 Sucursales</a>
                </li>

                <?php if(isset($_SESSION['id_usuario'])): ?>
                    <!-- Menú de usuario logueado -->
                    <li class="nav-item dropdown ms-2">
                        <button class="menu-btn dropdown-toggle" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                            ☰
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark" aria-labelledby="userMenu">
                            <li><a class="dropdown-item" href="/ChinosCafe/perfil.php">👤 Perfil</a></li>

                            <?php if($_SESSION['rol'] == 'admin'): ?>
                                <li><a class="dropdown-item" href="/ChinosCafe/admin_panel.php">⚙️ Panel Admin</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="/ChinosCafe/ver_carrito.php">🛒 Carrito</a></li>
                            <?php endif; ?>

                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="/ChinosCafe/auth/logout.php">🚪 Cerrar sesión</a></li>
                        </ul>
                    </li>

                <?php else: ?>
                    <!-- Visitantes -->
                    <li class="nav-item ms-2">
                        <a class="nav-link" href="/ChinosCafe/auth/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ChinosCafe/auth/register.php">Registro</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- 📦 Contenedor principal -->
<div class="container my-4">
