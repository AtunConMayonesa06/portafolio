<?php include('conexion.php'); ?>
<?php include('includes/header.php'); ?>

<!-- 🏠 Hero principal -->
<section class="text-center py-5 bg-hero text-white rounded-3 shadow mb-5">
  <div class="container">
    <h1 class="display-4 fw-bold">Bienvenido a Chinos Café</h1>
    <p class="lead mb-4">
      Disfruta del mejor café artesanal, hecho con pasión y sabor panameño ☕
    </p>
    <?php if(!isset($_SESSION['id_usuario'])): ?>
      <a href="auth/login.php" class="btn btn-light btn-lg mt-3">Iniciar sesión</a>
      <a href="auth/register.php" class="btn btn-outline-light btn-lg mt-3">Registrarse</a>
    <?php else: ?>
    <?php endif; ?>
  </div>
</section>

<!-- 🛍️ Sección de productos destacados -->
<div class="container mb-5">
  <h2 class="text-center mb-4 text-cafe-dorado">Nuestros Productos Destacados</h2>

  <div class="row justify-content-center g-4">
    <div class="col-md-4">
      <div class="card h-100 text-center">
        <img src="img/cafe1.png" class="card-img-top" alt="Café espresso">
        <div class="card-body">
          <h5 class="card-title">Café Espresso</h5>
          <p class="card-text">Sabor intenso y aroma profundo, ideal para amantes del café fuerte.</p>
          <a href="productos.php" class="btn btn-outline-light">Ver más</a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100 text-center">
        <img src="img/capuccino-italiano.png" class="card-img-top" alt="Cappuccino Italiano">
        <div class="card-body">
          <h5 class="card-title">Cappuccino Italiano</h5>
          <p class="card-text">Espresso con leche vaporizada y espuma cremosa.</p>
          <a href="productos.php" class="btn btn-outline-light">Ver más</a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card h-100 text-center">
        <img src="img/Cheesecake de Fresa.png" class="card-img-top" alt="Cheesecake de Fresa">
        <div class="card-body">
          <h5 class="card-title">Cheesecake de Fresa</h5>
          <p class="card-text">Tarta de queso cremosa con salsa de fresa.</p>
          <a href="productos.php" class="btn btn-outline-light">Ver más</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 🧾 Sección "Sobre Nosotros" -->
<section class="py-5 bg-dark rounded-3 shadow-lg mb-5">
  <div class="container text-center">
    <h2 class="text-cafe-dorado mb-4">Chinos Café</h2>
    <p class="lead mx-auto" style="max-width: 700px;">
      En <strong>Chinos Café</strong> nos apasiona crear experiencias únicas.  
      Cada taza está elaborada con granos seleccionados y tostados con dedicación,  
      ofreciendo calidad y sabor en cada sorbo.  
      ¡Ven a visitarnos o disfruta nuestros productos desde casa!
    </p>
  </div>
</section>

<?php include('includes/footer.php'); ?>

<style>
.card-img-top {
  width: 100%;
  height: 250px;              /* 🔧 Tamaño fijo uniforme */
  object-fit: cover;          /* 🔥 Ajusta la imagen sin deformarla */
  border-radius: 8px 8px 0 0; /* opcional: bordes superiores redondeados */
}
</style>
