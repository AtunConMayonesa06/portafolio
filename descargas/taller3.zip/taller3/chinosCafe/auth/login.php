<?php
include('../conexion.php');
include('../includes/header.php');

// ✅ Si ya está logueado, redirige
if (isset($_SESSION['id_usuario'])) {
    header("Location: ../index.php");
    exit();
}

// 🧾 Si envía el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Buscar al usuario por correo
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // 🛑 Verificar si está bloqueado
        if ((int)$user['bloqueado'] === 1) {
            header("Location: login.php?msg=bloqueado");
            exit();
        }

        // ✅ Verificar contraseña
        if (password_verify($password, $user['password_hash'])) {
            // Guardar sesión
            $_SESSION['id_usuario'] = $user['id_usuario'];
            $_SESSION['rol'] = $user['rol'];
            $_SESSION['nombre'] = $user['nombre'];

            // Redirigir según rol
            if ($user['rol'] === 'admin') {
                header("Location: ../index.php");
            } else {
                header("Location: ../index.php");
            }
            exit();
        } else {
            // Contraseña incorrecta
            header("Location: login.php?msg=wrongpass");
            exit();
        }
    } else {
        // Usuario no encontrado
        header("Location: login.php?msg=nouser");
        exit();
    }
}
?>

<h2 class="text-center mb-4">🔑 Iniciar Sesión</h2>

<div class="row justify-content-center">
  <div class="col-md-6">
    <?php
    // Mensajes bonitos tras PRG
    if (isset($_GET['msg'])) {
        if ($_GET['msg'] === 'wrongpass') {
            echo "<div class='alert alert-danger text-center mt-3 mensaje-bonito'>❌ Contraseña incorrecta</div>";
        } elseif ($_GET['msg'] === 'nouser') {
            echo "<div class='alert alert-warning text-center mt-3 mensaje-bonito'>⚠️ Usuario no encontrado</div>";
        } elseif ($_GET['msg'] === 'bloqueado') {
            echo "<div class='alert alert-danger text-center mt-3 mensaje-bonito'>🚫 Tu cuenta está bloqueada. Contacta con el administrador.</div>";
        }
    }
    ?>

    <form method="POST" action="login.php" id="formLogin">
      <div class="mb-3">
        <label>Correo electrónico:</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Contraseña:</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" name="login" class="btn btn-light w-100">Entrar</button>
    </form>
  </div>
</div>

<?php include('../includes/footer.php'); ?>
