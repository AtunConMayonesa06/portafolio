<?php
session_start();

// Eliminar todas las variables de sesión
$_SESSION = [];

// Destruir la sesión completamente
session_destroy();

// Redirigir al inicio
header("Location: /ChinosCafe/index.php");
exit();
?>
