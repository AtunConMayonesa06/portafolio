<?php include('../conexion.php'); ?>
<?php include('../includes/header.php'); ?>

<h2 class="text-center mb-4">📝 Registro de Cliente</h2>

<div class="row justify-content-center">
  <div class="col-md-6">
    <form method="POST" action="register.php">
      <div class="mb-3">
        <label>Nombre:</label>
        <input type="text" name="nombre" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Apellido:</label>
        <input type="text" name="apellido" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Correo electrónico:</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Contraseña:</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" name="registrar" class="btn btn-light w-100">Registrar</button>
    </form>
  </div>
</div>

<?php
if (isset($_POST['registrar'])) {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Validación de email duplicado
    $verificar = $conn->query("SELECT * FROM clientes WHERE email='$email'");
    if ($verificar->num_rows > 0) {
        echo "<div class='alert alert-warning mt-3 text-center'>⚠️ Este correo ya está registrado.</div>";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO clientes (nombre, apellido, email, password_hash, rol, id_sucursal) 
                VALUES ('$nombre', '$apellido', '$email', '$hash', 'cliente', 1)";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registro exitoso ✅'); window.location='login.php';</script>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Error al registrar: " . $conn->error . "</div>";
        }
    }
}
?>

<?php include('../includes/footer.php'); ?>
