<?php
// ver_historial.php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

include(__DIR__ . '/conexion.php');

$id_usuario = (int)$_GET['id_usuario'] ?? 0;

if ($id_usuario <= 0) {
    die('Error: ID de usuario no válido');
}

// Verificar si el usuario existe
$usuario = $conn->query("SELECT nombre, apellido, email FROM clientes WHERE id_usuario = $id_usuario");
if (!$usuario || $usuario->num_rows === 0) {
    die('Error: Cliente no encontrado');
}

$cliente_info = $usuario->fetch_assoc();

// Obtener historial de compras desde la tabla ventas
function obtenerHistorialCompras($conn, $id_usuario) {
    $historial = [];
    
    $ventas = $conn->query("
        SELECT 
            v.id_venta,
            v.fecha,
            v.cantidad,
            v.total,
            v.metodo_pago,
            v.estado,
            p.nombre as producto_nombre,
            p.precio as precio_unitario
        FROM ventas v 
        LEFT JOIN inventario p ON v.id_producto = p.id_producto 
        WHERE v.id_usuario = $id_usuario 
        ORDER BY v.fecha DESC
    ");
    
    if ($ventas && $ventas->num_rows > 0) {
        while ($venta = $ventas->fetch_assoc()) {
            $historial[] = $venta;
        }
    }
    
    return $historial;
}

$historial_compras = obtenerHistorialCompras($conn, $id_usuario);

$total_compras = count($historial_compras);
$total_gastado = 0;
$productos_comprados = 0;

foreach ($historial_compras as $compra) {
    $total_gastado += $compra['total'];
    $productos_comprados += $compra['cantidad'];
}

$metodos_pago = [];
foreach ($historial_compras as $compra) {
    $metodo = $compra['metodo_pago'] ?? 'No especificado';
    if (!isset($metodos_pago[$metodo])) {
        $metodos_pago[$metodo] = 0;
    }
    $metodos_pago[$metodo]++;
}
$metodo_favorito = !empty($metodos_pago) ? array_keys($metodos_pago, max($metodos_pago))[0] : 'No hay compras';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Compras</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            background: #3b2f2f;
            color: #f8f4f0;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            background: #4b3a32;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        }
        .header {
            border-bottom: 2px solid #d7b899;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .btn-volver {
            background: #8b5e3c;
            color: #fff;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-bottom: 10px;
            transition: background 0.3s;
        }
        .btn-volver:hover {
            background: #a06a46;
        }
        h2, h3, h4 {
            color: #f8f4f0;
        }
        .info-cliente {
            background: #5c4438;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .estadisticas {
            background: #6b4f3b;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }
        .estadistica-item {
            text-align: center;
            padding: 15px;
            background: #7c5e48;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .estadistica-valor {
            font-size: 30px;
            font-weight: bold;
            color: #ffe7c4;
            margin-bottom: 5px;
        }
        .estadistica-label {
            font-size: 14px;
            color: #f2e1cf;
            font-weight: bold;
        }
        .tabla-historial {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
        }
        .tabla-historial th, .tabla-historial td {
            border: 1px solid #6e5241;
            padding: 12px;
            text-align: left;
        }
        .tabla-historial th {
            background-color: #2b1e18;
            color: #ffe7c4;
            font-weight: bold;
        }
        .tabla-historial tr:nth-child(even) { background-color: #5a4234; }
        .tabla-historial tr:nth-child(odd) { background-color: #4b3628; }
        .tabla-historial tr:hover { background-color: #6a4b38; }
        .estado-completado {
            background-color: #4e8b57;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            font-weight: bold;
        }
        .estado-pendiente {
            background-color: #d1a45a;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            font-weight: bold;
        }
        .estado-cancelado {
            background-color: #b24a4a;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            font-weight: bold;
        }
        .sin-compras {
            text-align: center;
            padding: 60px;
            background: #5c4438;
            border-radius: 10px;
            color: #f2e1cf;
        }
        .metodo-pago {
            background-color: #c7a27c;
            color: #3b2f2f;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 13px;
            font-weight: bold;
        }
        .resumen-ventas {
            background: #8b6a4d;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .resumen-ventas h4 {
            margin-top: 0;
            color: #fff2d9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <a href="admin_panel.php" class="btn-volver">⬅️ Volver a Dashboard</a>
            <h2>🧾 Historial de Compras</h2>
        </div>

        <div class="info-cliente">
            <h3>👤 Cliente: <?= htmlspecialchars($cliente_info['nombre'] . ' ' . $cliente_info['apellido']) ?></h3>
            <p><strong>📧 Email:</strong> <?= htmlspecialchars($cliente_info['email']) ?></p>
            <p><strong>🆔 ID:</strong> <?= $id_usuario ?></p>
        </div>

        <?php if (!empty($historial_compras)): ?>
            <div class="estadisticas">
                <div class="estadistica-item">
                    <div class="estadistica-valor"><?= $total_compras ?></div>
                    <div class="estadistica-label">TOTAL DE COMPRAS</div>
                </div>
                <div class="estadistica-item">
                    <div class="estadistica-valor">$<?= number_format($total_gastado, 2) ?></div>
                    <div class="estadistica-label">TOTAL GASTADO</div>
                </div>
                <div class="estadistica-item">
                    <div class="estadistica-valor"><?= $productos_comprados ?></div>
                    <div class="estadistica-label">PRODUCTOS COMPRADOS</div>
                </div>
                <div class="estadistica-item">
                    <div class="estadistica-valor"><?= $metodo_favorito ?></div>
                    <div class="estadistica-label">MÉTODO DE PAGO FRECUENTE</div>
                </div>
            </div>

            <div class="resumen-ventas">
                <h4>📈 Resumen de Actividad</h4>
                <p>Este cliente ha realizado <strong><?= $total_compras ?> compras</strong> por un total de <strong>$<?= number_format($total_gastado, 2) ?></strong>, 
                adquiriendo <strong><?= $productos_comprados ?> productos</strong> en total.</p>
            </div>

            <table class="tabla-historial">
                <thead>
                    <tr>
                        <th>ID Venta</th>
                        <th>Fecha</th>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio Unit.</th>
                        <th>Total</th>
                        <th>Método Pago</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($historial_compras as $compra): ?>
                    <tr>
                        <td><strong>#<?= $compra['id_venta'] ?></strong></td>
                        <td><?= date("d/m/Y H:i", strtotime($compra['fecha'])) ?></td>
                        <td><?= htmlspecialchars($compra['producto_nombre'] ?? 'Producto no disponible') ?></td>
                        <td><?= $compra['cantidad'] ?></td>
                        <td>$<?= number_format($compra['precio_unitario'] ?? ($compra['total'] / $compra['cantidad']), 2) ?></td>
                        <td><strong>$<?= number_format($compra['total'], 2) ?></strong></td>
                        <td>
                            <span class="metodo-pago"><?= htmlspecialchars($compra['metodo_pago'] ?? 'No especificado') ?></span>
                        </td>
                        <td>
                            <?php 
                            $estado = $compra['estado'] ?? 'completado';
                            $clase_estado = 'estado-completado';
                            if (stripos($estado, 'pendiente') !== false) $clase_estado = 'estado-pendiente';
                            if (stripos($estado, 'cancelado') !== false) $clase_estado = 'estado-cancelado';
                            if (stripos($estado, 'procesando') !== false) $clase_estado = 'estado-pendiente';
                            ?>
                            <span class="<?= $clase_estado ?>"><?= ucfirst($estado) ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top: 20px; padding: 15px; background: #5a4234; border-radius: 5px; text-align: center;">
                <p><strong>Resumen final:</strong> <?= $total_compras ?> compras registradas • Total: $<?= number_format($total_gastado, 2) ?></p>
            </div>

        <?php else: ?>
            <div class="sin-compras">
                <h4>🛒 No hay compras registradas</h4>
                <p>Este cliente aún no ha realizado ninguna compra en el sistema.</p>
                <p><small>Las compras aparecerán aquí cuando el cliente realice pedidos a través de la tienda.</small></p>
            </div>
        <?php endif; ?>
    </div>
    <script src="/ChinosCafe/scripts/main.js"></script>
</body>
</html>
