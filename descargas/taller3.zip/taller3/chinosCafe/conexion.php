<?php
// ============================================
// ⚙️ CONFIGURACIÓN GENERAL
// ============================================
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('America/Panama');

// ============================================
// 🔗 CONEXIÓN LOCAL (Ubuntu / principal)
// ============================================
$local = [
    'host' => 'localhost',
    'port' => 3307,
    'user' => 'root',
    'pass' => '', // o tu clave si configuraste una
    'db'   => 'chinos_cafe_db'
];

$conn = new mysqli($local['host'], $local['user'], $local['pass'], $local['db'], $local['port']);
if ($conn->connect_error) {
    die("❌ Error de conexión local: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// ============================================
// 🔁 CONEXIÓN REMOTA (Windows)
// ============================================
$remote = [
    'host' => '192.168.0.8', // IP de tu PC con Windows
    'port' => 3307,
    'user' => 'root',
    'pass' => 'mysql',
    'db'   => 'chinos_cafe_db'
];

$conn_remote = @new mysqli($remote['host'], $remote['user'], $remote['pass'], $remote['db'], $remote['port']);
if ($conn_remote->connect_error) {
    // Solo registra el error, no detiene la ejecución
    error_log("⚠️ No se pudo conectar al servidor remoto: " . $conn_remote->connect_error);
} else {
    $conn_remote->set_charset('utf8mb4');
}
?>
