<?php
session_start();
include(__DIR__ . '/conexion.php');
define('ITBMS', 0.07);

// Cargar Dompdf desde carpeta local /dompdf
require_once __DIR__ . '/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

// Si el carrito está vacío y no venimos de una compra confirmada, redirigir
if (empty($_SESSION['carrito']) && !isset($_SESSION['ultima_factura'])) {
    header("Location: ver_carrito.php");
    exit;
}

$carrito = $_SESSION['carrito'] ?? [];
$id_usuario = $_SESSION['id_usuario'] ?? 1; // temporal mientras no haya login
$fecha = date('Y-m-d H:i:s');

// Calcular totales con carrito actual (vista previa)
$total = 0;
foreach ($carrito as $item) {
    $total += $item['precio'] * $item['cantidad'];
}
$total_itbms = $total * ITBMS;
$total_final  = $total + $total_itbms;

// ================================
// 🧾 GUARDAR COMPRA EN LA BASE DE DATOS
// ================================
if (isset($_POST['confirmar']) && !empty($carrito)) {
    $lineas = [];
    $ids_venta = [];

    foreach ($carrito as $item) {
        // Seguridad: evitar stock negativo
        $idProd   = (int)$item['id_producto'];
        $cantidad = (int)$item['cantidad'];

        // Verificar stock actual
        $rs = $conn->query("SELECT stock, precio, nombre FROM inventario WHERE id_producto = {$idProd} LIMIT 1");
        if (!$rs || $rs->num_rows === 0) continue; // producto borrado
        $prod = $rs->fetch_assoc();
        if ((int)$prod['stock'] < $cantidad) {
            // Stock insuficiente → regresar al carrito
            $_SESSION['flash'] = "Stock insuficiente para {$prod['nombre']}. Disponible: {$prod['stock']}.";
            header("Location: ver_carrito.php");
            exit;
        }

        // Insertar venta (guarda subtotal por línea)
        $subtotal = (float)$item['precio'] * $cantidad;
        $stmt = $conn->prepare("INSERT INTO ventas (id_usuario, id_producto, cantidad, total, fecha, metodo_pago, estado)
                                VALUES (?, ?, ?, ?, ?, 'Efectivo', 'Pagado')");
        $stmt->bind_param("iiids", $id_usuario, $idProd, $cantidad, $subtotal, $fecha);
        $stmt->execute();
        $ids_venta[] = $stmt->insert_id;

        // Actualizar stock
        $conn->query("UPDATE inventario SET stock = stock - {$cantidad} WHERE id_producto = {$idProd}");

        // Guardar línea para la factura
        $lineas[] = [
            'nombre'   => $item['nombre'],
            'precio'   => (float)$item['precio'],
            'cantidad' => $cantidad,
            'subtotal' => $subtotal,
            'imagen'   => $item['imagen'] ?? ''
        ];
    }

    // Totales finales de la compra (a partir de $lineas)
    $sub = 0;
    foreach ($lineas as $l) { $sub += $l['subtotal']; }
    $imp = $sub * ITBMS;
    $tot = $sub + $imp;

    // Guardar snapshot para la factura/PDF
    $_SESSION['ultima_factura'] = [
        'fecha'      => $fecha,
        'id_usuario' => $id_usuario,
        'lineas'     => $lineas,
        'subtotal'   => $sub,
        'itbms'      => $imp,
        'total'      => $tot,
        'ventas_ids' => $ids_venta,
    ];

    // Limpiar carrito y redirigir
    $_SESSION['carrito'] = [];
    header("Location: finalizar_compra.php?factura=1");
    exit;
}

// ================================
// 📄 GENERAR FACTURA PDF (desde ultima_factura)
// ================================
if (isset($_GET['generar'])) {
    $fact = $_SESSION['ultima_factura'] ?? null;

    // Fallback: si no hay ultima_factura pero sí carrito (caso raro)
    if (!$fact && !empty($carrito)) {
        $lineas = [];
        $subtotalTmp = 0;
        foreach ($carrito as $it) {
            $st = $it['precio'] * $it['cantidad'];
            $subtotalTmp += $st;
            $lineas[] = [
                'nombre'   => $it['nombre'],
                'precio'   => (float)$it['precio'],
                'cantidad' => (int)$it['cantidad'],
                'subtotal' => $st,
                'imagen'   => $it['imagen'] ?? ''
            ];
        }
        $fact = [
            'fecha'    => date('Y-m-d H:i:s'),
            'lineas'   => $lineas,
            'subtotal' => $subtotalTmp,
            'itbms'    => $subtotalTmp * ITBMS,
            'total'    => $subtotalTmp * (1 + ITBMS),
        ];
    }

    if (!$fact) {
        header("Location: ver_carrito.php");
        exit;
    }

    // HTML de la factura
    ob_start();
    ?>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; color:#222; }
        h1 { color:#8b5e34; margin-bottom:0; }
        .muted { color:#666; font-size:12px; }
        table { width:100%; border-collapse:collapse; margin-top:15px; }
        th, td { border:1px solid #ddd; padding:8px; font-size:13px; }
        th { background:#f3e7da; text-align:left; }
        .totales { margin-top:10px; width:100%; }
        .totales td { padding:6px; }
        .right { text-align:right; }
        
      </style>
    </head>
    <body>
      <h1>Chinos Café — Factura</h1>
      <div class="muted">Fecha: <?= date('d/m/Y H:i', strtotime($fact['fecha'])) ?></div>

      <table>
        <thead>
          <tr>
            <th>Producto</th>
            <th class="right">Precio</th>
            <th class="right">Cantidad</th>
            <th class="right">Subtotal</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($fact['lineas'] as $l): ?>
          <tr>
            <td><?= htmlspecialchars($l['nombre']) ?></td>
            <td class="right">$<?= number_format($l['precio'], 2) ?></td>
            <td class="right"><?= (int)$l['cantidad'] ?></td>
            <td class="right">$<?= number_format($l['subtotal'], 2) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>

      <table class="totales">
        <tr>
          <td class="right"><strong>Subtotal:</strong></td>
          <td class="right" style="width:120px;">$<?= number_format($fact['subtotal'], 2) ?></td>
        </tr>
        <tr>
          <td class="right"><strong>ITBMS (7 %):</strong></td>
          <td class="right">$<?= number_format($fact['itbms'], 2) ?></td>
        </tr>
        <tr>
          <td class="right"><strong>Total:</strong></td>
          <td class="right"><strong>$<?= number_format($fact['total'], 2) ?></strong></td>
        </tr>
      </table>

      <p class="muted">Gracias por su compra ☕</p>
    </body>
    </html>
    <?php
    $html = ob_get_clean();

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream("Factura_ChinosCafe.pdf", ["Attachment" => true]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Factura | Chinos Café</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#2b211a; color:#fdf6ec; font-family:'Poppins',sans-serif; }
    h1,h2 { color:#d9a35f; font-weight:700; }
    .factura { background:#3a2c23; padding:30px; border-radius:12px; color:#fff; }
    .btn-cafe { background-color:#d9a35f; color:#1e1e1e; border:none; font-weight:600; }
    .btn-cafe:hover { background-color:#b68544; color:#fff; }
    .table-dark th { background-color:#4a372c !important; color:#fdf6ec; }
    .table-dark td { color:#fdf6ec; }
    .alert-info { background:#d9a35f; color:#1e1e1e; border:none; font-weight:500; }
    footer { background:#1b130f; color:#fdf6ec; }
  </style>
</head>
<body>
<?php include(__DIR__ . '/includes/header.php'); ?>

<div class="container my-5">
  <?php if (isset($_SESSION['flash'])): ?>
    <div class="alert alert-warning text-center"><?= htmlspecialchars($_SESSION['flash']); unset($_SESSION['flash']); ?></div>
  <?php endif; ?>

  <?php if (isset($_GET['factura']) && isset($_SESSION['ultima_factura'])): ?>
    <div class="factura text-center shadow-lg">
      <h1>☕ Compra realizada con éxito</h1>
      <p class="mt-3">Tu pedido ha sido registrado correctamente en nuestro sistema.</p>
      <a href="?generar=1" class="btn btn-cafe mt-3">📄 Descargar factura PDF</a>
      <a href="productos.php" class="btn btn-secondary mt-3">Volver a comprar</a>
    </div>
  <?php else: ?>
    <div class="factura shadow-lg">
      <h1 class="mb-4 text-center">🧾 Factura de Compra</h1>

      <?php if (!empty($carrito)): ?>
        <table class="table table-dark text-center">
          <thead>
            <tr>
              <th>Producto</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($carrito as $item): 
              $st = $item['precio'] * $item['cantidad'];
            ?>
            <tr>
              <td><?= htmlspecialchars($item['nombre']) ?></td>
              <td>$<?= number_format($item['precio'], 2) ?></td>
              <td><?= (int)$item['cantidad'] ?></td>
              <td>$<?= number_format($st, 2) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div class="text-end mt-4">
          <p><strong>Subtotal:</strong> $<?= number_format($total, 2) ?></p>
          <p><strong>ITBMS (7 %):</strong> $<?= number_format($total_itbms, 2) ?></p>
          <h4><strong>Total a pagar:</strong> $<?= number_format($total_final, 2) ?></h4>
        </div>

        <form method="POST" class="text-center mt-4">
          <button type="submit" name="confirmar" class="btn btn-cafe btn-lg">💳 Confirmar compra</button>
        </form>
      <?php else: ?>
        <div class="alert alert-info text-center">No hay artículos para facturar.</div>
        <div class="text-center">
          <a href="productos.php" class="btn btn-cafe">Volver a productos</a>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<footer class="text-center py-4 mt-5">
  <p class="mb-0">&copy; <?= date('Y') ?> Chinos Café. Todos los derechos reservados.</p>
</footer>
</body>
</html>
