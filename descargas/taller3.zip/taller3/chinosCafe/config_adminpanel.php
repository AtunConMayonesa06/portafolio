<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

include(__DIR__ . '/conexion.php');

/* ========= Validar sesión admin ========= */
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
  exit("<p style='color:red; text-align:center;'>Acceso denegado</p>");
}

/* ========= Crear tabla si no existe ========= */
$conn->query("
CREATE TABLE IF NOT EXISTS configuracion (
  id_config INT PRIMARY KEY AUTO_INCREMENT,
  nombre_empresa VARCHAR(100),
  telefono VARCHAR(20),
  email_contacto VARCHAR(100),
  direccion VARCHAR(150),
  horario VARCHAR(100),
  lema VARCHAR(150),
  facebook VARCHAR(150),
  instagram VARCHAR(150),
  actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
");

/* ========= Guardar configuración ========= */
$guardado = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = trim($_POST['nombre_empresa']);
  $telefono = trim($_POST['telefono']);
  $email = trim($_POST['email_contacto']);
  $direccion = trim($_POST['direccion']);
  $horario = trim($_POST['horario']);
  $lema = trim($_POST['lema']);
  $facebook = trim($_POST['facebook']);
  $instagram = trim($_POST['instagram']);

  $stmt = $conn->prepare("
    REPLACE INTO configuracion 
    (id_config, nombre_empresa, telefono, email_contacto, direccion, horario, lema, facebook, instagram)
    VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)
  ");
  $stmt->bind_param("ssssssss", $nombre, $telefono, $email, $direccion, $horario, $lema, $facebook, $instagram);
  $stmt->execute();
  $stmt->close();
  $guardado = true;
}

/* ========= Obtener configuración actual ========= */
$conf = $conn->query("SELECT * FROM configuracion WHERE id_config = 1")->fetch_assoc() ?? [
  'nombre_empresa' => 'Chinos Café',
  'telefono' => '+507 6000-0000',
  'email_contacto' => 'contacto@chinoscafe.com',
  'direccion' => 'Calle Principal, Ciudad de Panamá',
  'horario' => 'Lunes a Domingo: 7:00am - 9:00pm',
  'lema' => 'El sabor que despierta tus mañanas ☕',
  'facebook' => 'https://facebook.com/chinoscafe',
  'instagram' => 'https://instagram.com/chinoscafe'
];
?>

<!-- 🎨 Estilos encapsulados -->
<style>
#config-panel {
  font-family: "Poppins", sans-serif;
  background-color: #1e1b18;
  color: #f8efe2;
  border-radius: 10px;
  padding: 25px;
}
#config-panel h2 {
  text-align: center;
  color: #ffcf91;
}
#config-panel form label {
  font-weight: 600;
  color: #ffdd91;
  display: block;
  margin-bottom: 5px;
}
#config-panel input,
#config-panel textarea {
  width: 100%;
  padding: 8px;
  border-radius: 6px;
  border: 1px solid #4a3a2f;
  background: #2b2520;
  color: #f8efe2;
  margin-bottom: 10px;
}
#config-panel .btn-guardar {
  background: #6b4f4f;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  color: #fff7e6;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s;
}
#config-panel .btn-guardar:hover {
  background: #855c4d;
}
#config-panel .info-actual ul {
  list-style: none;
  padding: 0;
  margin-top: 15px;
}
#config-panel .info-actual li {
  margin-bottom: 6px;
}
</style>

<div id="config-panel">
  <div class="acciones-superiores">
    <a href="admin_panel.php" class="btn-volver">⬅️ Volver al Dashboard</a>
  </div>

  <h2>⚙️ Configuración de Contacto</h2>

  <form method="POST" id="formConfig">
    <label>🏢 Nombre del Negocio:</label>
    <input type="text" name="nombre_empresa" value="<?= htmlspecialchars($conf['nombre_empresa']) ?>" required>

    <label>📞 Teléfono:</label>
    <input type="text" name="telefono" value="<?= htmlspecialchars($conf['telefono']) ?>">

    <label>📧 Correo de Contacto:</label>
    <input type="email" name="email_contacto" value="<?= htmlspecialchars($conf['email_contacto']) ?>" required>

    <label>📍 Dirección:</label>
    <input type="text" name="direccion" value="<?= htmlspecialchars($conf['direccion']) ?>">

    <label>🕒 Horario:</label>
    <input type="text" name="horario" value="<?= htmlspecialchars($conf['horario']) ?>">

    <label>💬 Lema o Eslogan:</label>
    <textarea name="lema" rows="2"><?= htmlspecialchars($conf['lema']) ?></textarea>

    <label>🌐 Facebook:</label>
    <input type="text" name="facebook" value="<?= htmlspecialchars($conf['facebook']) ?>">

    <label>📸 Instagram:</label>
    <input type="text" name="instagram" value="<?= htmlspecialchars($conf['instagram']) ?>">

    <button type="submit" class="btn-guardar">💾 Guardar Información</button>
  </form>

  <hr style="border-color:#4d3b2f; margin:20px 0;">

  <div class="info-actual">
    <h3 style="color:#ffcf91;">📄 Información Actual</h3>
    <ul>
      <li><strong>🏢 Empresa:</strong> <?= htmlspecialchars($conf['nombre_empresa']) ?></li>
      <li><strong>📞 Teléfono:</strong> <?= htmlspecialchars($conf['telefono']) ?></li>
      <li><strong>📧 Correo:</strong> <?= htmlspecialchars($conf['email_contacto']) ?></li>
      <li><strong>📍 Dirección:</strong> <?= htmlspecialchars($conf['direccion']) ?></li>
      <li><strong>🕒 Horario:</strong> <?= htmlspecialchars($conf['horario']) ?></li>
      <li><strong>💬 Lema:</strong> <?= htmlspecialchars($conf['lema']) ?></li>
      <li><strong>🌐 Facebook:</strong> <a href="<?= htmlspecialchars($conf['facebook']) ?>" target="_blank" style="color:#ffdca8;">Ver perfil</a></li>
      <li><strong>📸 Instagram:</strong> <a href="<?= htmlspecialchars($conf['instagram']) ?>" target="_blank" style="color:#ffdca8;">Ver perfil</a></li>
    </ul>
  </div>
</div>

<!-- 🚀 Alerta sin recargar el panel -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if ($guardado): ?>
<script>
Swal.fire({
  toast: true,
  position: 'top-end',
  icon: 'success',
  title: '✅ Información actualizada correctamente',
  showConfirmButton: false,
  timer: 2000,
  background: '#3b2f2f',
  color: '#f8efe2'
});
</script>
<?php endif; ?>
