<?php
include(__DIR__ . '/conexion.php');

// 🔍 Consultar datos de la tabla 'configuracion'
$config = $conn->query("SELECT * FROM configuracion LIMIT 1")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nosotros | Chinos Café</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #1e1e1e;
      color: #f5f5f5;
      font-family: 'Poppins', sans-serif;
      line-height: 1.7;
    }
    .hero {
      background: url('/ChinosCafe/img/<?php echo $config['imagen_portada'] ?? "portada_default.jpg"; ?>') center/cover no-repeat;
      height: 60vh;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      text-shadow: 0 2px 10px rgba(0,0,0,0.6);
    }
    .hero::after {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(0,0,0,0.45);
    }
    .hero h1 {
      position: relative;
      font-size: 3rem;
      font-weight: 700;
      z-index: 2;
    }
    .section {
      padding: 5rem 0;
    }
    .section:nth-child(even) {
      background-color: #2b1b13;
    }
    .section h2 {
      color: #d4a373;
      font-weight: 600;
      margin-bottom: 1.5rem;
    }
    .section p {
      font-size: 1.1rem;
    }
    .img-large {
      width: 100%;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.4);
      transition: transform 0.3s ease;
    }
    .img-large:hover {
      transform: scale(1.02);
    }
    .divider {
      width: 80px;
      height: 4px;
      background: #d4a373;
      border-radius: 3px;
      margin: 1rem 0 2rem;
    }
  </style>
</head>
<body>

<!-- 🔝 Navbar principal -->
<?php include(__DIR__ . '/includes/header.php'); ?>

<!-- 🌅 Portada -->
<section class="hero text-center">
  <h1>Sobre Nosotros</h1>
</section>

<!-- ☕ Información principal -->
<section class="section text-center">
  <div class="container">
    <h2><?php echo $config['nombre_empresa'] ?? "Chinos Café"; ?></h2>
    <div class="divider mx-auto"></div>
    <p class="lead mb-4">
      <?php echo nl2br($config['descripcion'] ?? "Disfruta del mejor café artesanal panameño, preparado con pasión, tradición y dedicación."); ?>
    </p>
    <img src="/ChinosCafe/img/<?php echo $config['imagen_historia'] ?? 'cafe_local.jpg'; ?>" alt="Historia" class="img-large mt-4">
  </div>
</section>

<!-- 📜 Nuestra Historia -->
<section class="section">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <img src="/ChinosCafe/img/<?php echo $config['imagen_historia'] ?? 'barista.jpg'; ?>" alt="Historia" class="img-large">
      </div>
      <div class="col-lg-6">
        <h2>📖 Nuestra Historia</h2>
        <p>
          <?php echo nl2br($config['historia'] ?? "Desde nuestros inicios, en Chinos Café nos hemos dedicado a ofrecer experiencias únicas en torno al café. Inspirados por la cultura cafetera panameña, creamos un espacio donde cada taza cuenta una historia y cada cliente se convierte en parte de la familia."); ?>
        </p>
      </div>
    </div>
  </div>
</section>

<!-- 💡 Misión -->
<section class="section text-center">
  <div class="container">
    <h2>💡 Nuestra Misión</h2>
    <div class="divider mx-auto"></div>
    <p>
      <?php echo nl2br($config['mision'] ?? "Brindar una experiencia auténtica a través del sabor, aroma y calidad de nuestros productos, apoyando a productores locales y promoviendo el amor por el café artesanal."); ?>
    </p>
  </div>
</section>

<!-- 🌟 Visión -->
<section class="section text-center">
  <div class="container">
    <h2>🌟 Nuestra Visión</h2>
    <div class="divider mx-auto"></div>
    <p>
      <?php echo nl2br($config['vision'] ?? "Convertirnos en la cadena de café artesanal más reconocida de Panamá, expandiendo nuestra pasión por el café a cada rincón del país y más allá."); ?>
    </p>
  </div>
</section>

<!-- 🖼️ Imagen de cierre -->
<section class="section text-center">
  <div class="container">
    <img src="/ChinosCafe/img/<?php echo $config['imagen_vision'] ?? 'granos_cafe.jpg'; ?>" alt="Visión" class="img-large">
    <p class="mt-4 text-muted fst-italic">"El aroma del café nos une, la pasión nos impulsa."</p>
  </div>
</section>

<!-- 🔻 Footer -->
<footer class="text-center py-4" style="background:#2b1b13;">
  <p class="mb-0 text-light">
    &copy; <?php echo date('Y'); ?> <?php echo $config['nombre_empresa'] ?? "Chinos Café"; ?>. Todos los derechos reservados.
  </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
