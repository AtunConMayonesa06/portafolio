<?php
require_once(__DIR__ . '/dompdf/autoload.inc.php');
include(__DIR__ . '/conexion.php');

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);

// ===== Datos =====
$totalHoy   = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE DATE(fecha) = CURDATE()")->fetch_assoc()['total'] ?? 0;
$totalMes   = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE MONTH(fecha) = MONTH(CURDATE())")->fetch_assoc()['total'] ?? 0;
$totalAnio  = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE YEAR(fecha) = YEAR(CURDATE())")->fetch_assoc()['total'] ?? 0;
$clientes   = $conn->query("SELECT COUNT(*) AS total FROM clientes")->fetch_assoc()['total'] ?? 0;

// ===== HTML =====
$html = "
<html>
<head>
<meta charset='UTF-8'>
<style>
body {
  font-family: DejaVu Sans, sans-serif;
  background: #fdf8f3;
  color: #3b2f2f;
  margin: 30px;
}
h1 {
  text-align: center;
  color: #5a4034;
  margin-bottom: 5px;
}
.subtitle {
  text-align: center;
  color: #7b5e4b;
  font-size: 14px;
  margin-bottom: 20px;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  border-radius: 8px;
  overflow: hidden;
}
th, td {
  border: 1px solid #c8b8a8;
  padding: 10px;
  text-align: center;
}
th {
  background-color: #d7a46c;
  color: #fff;
}
td {
  background-color: #fffaf3;
}
tfoot td {
  font-weight: bold;
  background-color: #f1e0c6;
}
.footer {
  text-align: center;
  color: #7b5e4b;
  font-size: 12px;
  margin-top: 40px;
  border-top: 1px solid #c8b8a8;
  padding-top: 10px;
}
</style>
</head>
<body>
<h1>☕ Reporte General - Chinos Café</h1>
<p class='subtitle'>Generado automáticamente el " . date('d/m/Y H:i:s') . "</p>

<table>
  <tr><th>Indicador</th><th>Valor</th></tr>
  <tr><td>Ventas del Día</td><td>$" . number_format($totalHoy, 2) . "</td></tr>
  <tr><td>Ventas del Mes</td><td>$" . number_format($totalMes, 2) . "</td></tr>
  <tr><td>Ventas del Año</td><td>$" . number_format($totalAnio, 2) . "</td></tr>
  <tr><td>Total de Clientes</td><td>" . $clientes . "</td></tr>
  <tfoot><tr><td colspan='2'>Sistema Administrativo Chinos Café</td></tr></tfoot>
</table>

<div class='footer'>
  <p>© " . date('Y') . " Chinos Café — Todos los derechos reservados.</p>
</div>
</body>
</html>";

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("Reporte_ChinosCafe.pdf", ["Attachment" => false]);
exit;
?>
