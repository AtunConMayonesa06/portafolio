<?php
include(__DIR__ . '/conexion.php');
?>

<!-- Estilos y librerías -->
<link rel="stylesheet" href="/ChinosCafe/css/ventasAdminpanel.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<h2>📊 Estadísticas de Ventas</h2>

<?php
// ================== DATOS GLOBALES ==================
$totalHoy  = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE DATE(fecha) = CURDATE()")->fetch_assoc()['total'] ?? 0;
$totalMes  = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE MONTH(fecha) = MONTH(CURDATE())")->fetch_assoc()['total'] ?? 0;
$totalAnio = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE YEAR(fecha) = YEAR(CURDATE())")->fetch_assoc()['total'] ?? 0;

// Producto más vendido
$productoTop = $conn->query("
  SELECT i.nombre, SUM(v.cantidad) AS total_vendido
  FROM ventas v
  JOIN inventario i ON v.id_producto = i.id_producto
  GROUP BY i.id_producto
  ORDER BY total_vendido DESC LIMIT 1
")->fetch_assoc();

// Cliente estrella
$clienteTop = $conn->query("
  SELECT c.id_usuario, c.nombre, COUNT(v.id_venta) AS compras
  FROM ventas v
  JOIN clientes c ON v.id_usuario = c.id_usuario
  GROUP BY c.id_usuario
  ORDER BY compras DESC LIMIT 1
")->fetch_assoc();
?>

<!-- Tarjetas resumen -->
<div class="stats-cards">
  <div class="stat-card">💰 <strong>Ventas Hoy:</strong> $<?= number_format($totalHoy, 2) ?></div>
  <div class="stat-card">📅 <strong>Este Mes:</strong> $<?= number_format($totalMes, 2) ?></div>
  <div class="stat-card">📆 <strong>Este Año:</strong> $<?= number_format($totalAnio, 2) ?></div>
  <div class="stat-card">☕ <strong>Top Producto:</strong> <?= htmlspecialchars($productoTop['nombre'] ?? '—') ?></div>
  <div class="stat-card">
    👑 <strong>Cliente Estrella:</strong> 
    <?php if (isset($clienteTop['id_usuario'])): ?>
      <a href="ver_historial.php?id_usuario=<?= $clienteTop['id_usuario'] ?>" class="cliente-link" title="Ver historial de compras">
        <?= htmlspecialchars($clienteTop['nombre'] ?? '—') ?>
      </a>
    <?php else: ?>
      —
    <?php endif; ?>
  </div>
</div>

<hr>

<!-- FILTRO -->
<form method="GET" class="form-filtros" id="filtroForm">
  <div class="form-grid">
    <div>
      <label>Desde:</label>
      <input type="date" name="desde" value="<?= $_GET['desde'] ?? '' ?>">
    </div>
    <div>
      <label>Hasta:</label>
      <input type="date" name="hasta" value="<?= $_GET['hasta'] ?? '' ?>">
    </div>
  </div>

  <div class="acciones-filtros">
    <button type="submit" class="btn-guardar">🔍 Filtrar</button>
    <button type="button" class="btn-limpiar" onclick="limpiarFiltros()">🔄 Limpiar</button>
  </div>
</form>

<script>
// Función para cargar datos con filtros
function cargarDatosConFiltros(desde = '', hasta = '') {
  const params = new URLSearchParams();
  if (desde) params.append('desde', desde);
  if (hasta) params.append('hasta', hasta);
  
  // Mostrar loading
  document.querySelector('#ventas').innerHTML = '<div class="loading">Cargando...</div>';
  
  // Construir URL correctamente - ESTA ES LA CORRECCIÓN PRINCIPAL
  let url = 'ventas_adminpanel.php';
  if (desde || hasta) {
    url += '?' + params.toString();
  }
  
  fetch(url)
    .then(r => {
      if (!r.ok) throw new Error('Error en la respuesta del servidor');
      return r.text();
    })
    .then(html => {
      document.querySelector('#ventas').innerHTML = html;
      // Re-inicializar el gráfico después de cargar
      inicializarGrafico();
    })
    .catch(err => {
      console.error('Error al filtrar:', err);
      document.querySelector('#ventas').innerHTML = '<div class="error">Error al cargar los datos. Intenta nuevamente.</div>';
    });
}

// Manejar envío del formulario
document.getElementById('filtroForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const desde = this.desde.value;
  const hasta = this.hasta.value;
  cargarDatosConFiltros(desde, hasta);
});

// Limpiar filtros
function limpiarFiltros() {
  document.getElementById('filtroForm').reset();
  cargarDatosConFiltros();
}
</script>

<?php
// ================== DATOS FILTRADOS ==================
$where = "";
if (!empty($_GET['desde']) && !empty($_GET['hasta'])) {
    $desde = $conn->real_escape_string($_GET['desde']);
    $hasta = $conn->real_escape_string($_GET['hasta']);
    $where = "WHERE DATE(v.fecha) BETWEEN '$desde' AND '$hasta'";
}

$ventas = $conn->query("
  SELECT v.fecha, c.id_usuario, c.nombre AS cliente, i.nombre AS producto, v.cantidad, v.total
  FROM ventas v
  JOIN clientes c ON v.id_usuario = c.id_usuario
  JOIN inventario i ON v.id_producto = i.id_producto
  $where
  ORDER BY v.fecha DESC
");
?>

<h3>🧾 Historial de Ventas</h3>

<div class="tabla-ventas-container" style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 8px;">
  <table class="tabla-ventas">
    <thead style="position: sticky; top: 0; background: #8b5e3c; color: white; z-index: 10;">
      <tr>
        <th>Fecha</th>
        <th>Cliente</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $totalFiltrado = 0;
      $hayVentas = false;
      while($v = $ventas->fetch_assoc()): 
        $hayVentas = true;
        $totalFiltrado += $v['total'];
      ?>
        <tr>
          <td><?= date("Y-m-d", strtotime($v['fecha'])) ?></td>
          <td>
            <a href="ver_historial.php?id_usuario=<?= $v['id_usuario'] ?>" class="cliente-link" title="Ver historial del cliente">
              <?= htmlspecialchars($v['cliente']) ?>
            </a>
          </td>
          <td><?= htmlspecialchars($v['producto']) ?></td>
          <td><?= (int)$v['cantidad'] ?></td>
          <td>$<?= number_format($v['total'], 2) ?></td>
        </tr>
      <?php endwhile; ?>
      
      <?php if (!$hayVentas): ?>
        <tr>
          <td colspan="5" style="text-align: center; padding: 20px; color: #666;">
            No se encontraron ventas en el período seleccionado.
          </td>
        </tr>
      <?php endif; ?>
      
      <?php if ($where && $hayVentas): ?>
        <tr style="background-color: #f8f9fa; font-weight: bold;">
          <td colspan="4" style="text-align: right;">Total del período:</td>
          <td>$<?= number_format($totalFiltrado, 2) ?></td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<hr>

<!-- GRÁFICO CON CONTENEDOR SCROLLABLE -->
<div style="overflow-x: auto; padding: 10px 0;">
  <div style="min-width: 800px; height: 400px;">
    <canvas id="graficoVentas"></canvas>
  </div>
</div>

<?php
// ================== DATOS PARA GRÁFICO ==================
$labels = [];
$valores = [];

// Aplicar filtros al gráfico también
$whereGrafico = "";
if (!empty($_GET['desde']) && !empty($_GET['hasta'])) {
    $desde = $conn->real_escape_string($_GET['desde']);
    $hasta = $conn->real_escape_string($_GET['hasta']);
    $whereGrafico = "WHERE DATE(fecha) BETWEEN '$desde' AND '$hasta'";
}

$res = $conn->query("
  SELECT DATE(fecha) AS dia, SUM(total) AS total_dia
  FROM ventas
  $whereGrafico
  GROUP BY DATE(fecha)
  ORDER BY dia ASC
");

while($row = $res->fetch_assoc()) {
  $labels[] = date("d/m", strtotime($row['dia'])); // Formato más corto
  $valores[] = $row['total_dia'];
}
?>

<script>
function inicializarGrafico() {
  const ctx = document.getElementById('graficoVentas');
  
  // Destruir gráfico anterior si existe
  if (window.ventasChart) {
    window.ventasChart.destroy();
  }
  
  window.ventasChart = new Chart(ctx, {
    type: 'line', // Cambiado a línea para mejor visualización
    data: {
      labels: <?= json_encode($labels) ?>,
      datasets: [{
        label: 'Ventas Diarias ($)',
        data: <?= json_encode($valores) ?>,
        backgroundColor: '#d2a679aa',
        borderColor: '#8b5e3c',
        borderWidth: 3,
        pointBackgroundColor: '#8b5e3c',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
        fill: true,
        tension: 0.4 // Suaviza la línea
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { 
          display: true,
          position: 'top',
          labels: { color: '#3b2f2f', font: { size: 14 } }
        },
        title: { 
          display: true, 
          text: '📈 Evolución de Ventas Diarias', 
          color: '#3b2f2f',
          font: { size: 16 }
        },
        tooltip: {
          backgroundColor: 'rgba(139, 94, 60, 0.9)',
          titleColor: '#ffffff',
          bodyColor: '#ffffff',
          callbacks: {
            label: function(context) {
              return `Ventas: $${context.parsed.y.toFixed(2)}`;
            }
          }
        }
      },
      scales: {
        x: { 
          ticks: { color: '#3b2f2f', maxRotation: 45 },
          grid: { color: '#e0e0e0' }
        },
        y: { 
          ticks: { color: '#3b2f2f', callback: function(value) { return '$' + value; } },
          grid: { color: '#e0e0e0' },
          beginAtZero: true
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      },
      animation: {
        duration: 1000,
        easing: 'easeInOutQuart'
      }
    }
  });
}

// Inicializar gráfico al cargar la página
document.addEventListener('DOMContentLoaded', function() {
  inicializarGrafico();
});
</script>

<style>
.loading {
  text-align: center;
  padding: 20px;
  font-size: 18px;
  color: #8b5e3c;
}

.error {
  text-align: center;
  padding: 20px;
  font-size: 16px;
  color: #dc3545;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 5px;
  margin: 10px 0;
}

.tabla-ventas-container::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.tabla-ventas-container::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

.tabla-ventas-container::-webkit-scrollbar-thumb {
  background: #8b5e3c;
  border-radius: 4px;
}

.tabla-ventas-container::-webkit-scrollbar-thumb:hover {
  background: #6d4a2f;
}

.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
  margin: 20px 0;
}

.stat-card {
  background: linear-gradient(135deg, #8b5e3c, #d2a679);
  color: white;
  padding: 15px;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

/* Estilos para los enlaces de clientes */
.cliente-link {
  color: white;
  text-decoration: none;
  font-weight: bold;
  padding: 2px 6px;
  border-radius: 4px;
  transition: all 0.3s ease;
  background-color: rgba(255, 255, 255, 0.2);
}

.cliente-link:hover {
  background-color: rgba(255, 255, 255, 0.3);
  text-decoration: underline;
  transform: translateY(-1px);
}

/* Para los enlaces en la tabla */
.tabla-ventas .cliente-link {
  color: #8b5e3c;
  background-color: transparent;
  padding: 4px 8px;
  border: 1px solid #8b5e3c;
}

.tabla-ventas .cliente-link:hover {
  background-color: #8b5e3c;
  color: white;
}
</style>