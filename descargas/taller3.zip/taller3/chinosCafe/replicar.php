<?php
/**
 * Sincronizador MySQL entre Ubuntu → Windows
 * Carlos Miranda - Chinos Café
 * PHP 8+
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('America/Panama');

// Configuración conexión origen (Ubuntu)
$origen = [
    'host' => '127.0.0.1',  // o IP local Ubuntu
    'port' => 3307,
    'user' => 'root',
    'pass' => '', // tu clave
    'db'   => 'chinos_cafe_db'
];

// Configuración conexión destino (Windows)
$destino = [
    'host' => '192.168.0.8', // ⚠️ cambia por la IP real del Windows
    'port' => 3307,
    'user' => 'root',
    'pass' => 'mysql', // tu clave
    'db'   => 'chinos_cafe_db'
];

// Conectar a ambas bases
$src = new mysqli($origen['host'], $origen['user'], $origen['pass'], $origen['db'], $origen['port']);
$dst = new mysqli($destino['host'], $destino['user'], $destino['pass'], $destino['db'], $destino['port']);

if ($src->connect_error) die("❌ Error conexión origen: " . $src->connect_error);
if ($dst->connect_error) die("❌ Error conexión destino: " . $dst->connect_error);

echo "✅ Conexiones establecidas.\n";

// Obtener todas las tablas
$res = $src->query("SHOW TABLES");
if (!$res) die("❌ Error al listar tablas: " . $src->error);

while ($row = $res->fetch_array()) {
    $tabla = $row[0];
    echo "\n📦 Sincronizando tabla: $tabla\n";

    // Obtener estructura y datos del origen
    $resDatos = $src->query("SELECT * FROM `$tabla`");
    if (!$resDatos) {
        echo "⚠️ No se pudo leer $tabla: {$src->error}\n";
        continue;
    }

    // Vaciar la tabla destino antes de replicar
    $dst->query("SET FOREIGN_KEY_CHECKS=0");
    $dst->query("TRUNCATE TABLE `$tabla`");

    // Preparar inserciones
    $numCols = $resDatos->field_count;
    $placeholders = implode(',', array_fill(0, $numCols, '?'));

    $campos = [];
    while ($field = $resDatos->fetch_field()) {
        $campos[] = "`{$field->name}`";
    }

    $insertSQL = "INSERT INTO `$tabla` (" . implode(',', $campos) . ") VALUES ($placeholders)";
    $stmt = $dst->prepare($insertSQL);

    while ($fila = $resDatos->fetch_row()) {
        $tipos = str_repeat('s', $numCols);
        $stmt->bind_param($tipos, ...$fila);
        $stmt->execute();
    }

    $stmt->close();
    echo "✅ $tabla replicada con éxito.\n";
}

$dst->query("SET FOREIGN_KEY_CHECKS=1");

echo "\n🟢 Sincronización completada correctamente a las " . date('H:i:s') . "\n";

$src->close();
$dst->close();
?>
