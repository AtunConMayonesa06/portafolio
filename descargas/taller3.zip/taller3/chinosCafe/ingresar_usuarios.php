<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

include(__DIR__ . '/conexion.php');

// Inicializar variables
$errores = [];
$success = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar'])) {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $rol = $_POST['rol'] ?? 'cliente';

    // Validaciones básicas
    if (empty($nombre)) $errores[] = "El nombre es requerido";
    if (empty($apellido)) $errores[] = "El apellido es requerido";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Email válido requerido";
    }
    if (empty($password) || strlen($password) < 6) {
        $errores[] = "Contraseña de al menos 6 caracteres requerida";
    }
    if ($password !== $confirm_password) {
        $errores[] = "Las contraseñas no coinciden";
    }

    // Verificar si el email ya existe
    if (empty($errores)) {
        $check_sql = "SELECT id_usuario FROM clientes WHERE email = ?";
        $check = $conn->prepare($check_sql);
        
        if ($check) {
            $check->bind_param("s", $email);
            $check->execute();
            $check->store_result();
            
            if ($check->num_rows > 0) {
                $errores[] = "El email ya está registrado";
            }
            $check->close();
        }
    }

    // Si no hay errores, proceder con el registro
    if (empty($errores)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $id_sucursal = 1;

        $sql = "INSERT INTO clientes (nombre, apellido, email, password_hash, rol, id_sucursal)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("sssssi", $nombre, $apellido, $email, $password_hash, $rol, $id_sucursal);
            
            if ($stmt->execute()) {
                $nuevo_id = $stmt->insert_id;
                $success = "✅ Usuario creado correctamente - ID: $nuevo_id";
                
                // Limpiar el formulario
                $nombre = $apellido = $email = $rol = '';
                
                // Mostrar éxito y redirigir con JavaScript
                echo "<script>
                    alert('Usuario creado exitosamente - ID: $nuevo_id');
                    setTimeout(function() {
                        window.location.href = 'admin_panel.php';
                    }, 1000);
                </script>";
                
            } else {
                $errores[] = "Error al crear usuario: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $errores[] = "Error en la consulta: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agregar Usuario | Chinos Café</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
:root {
    --cafe-oscuro: #2d1b0e;
    --cafe-medio: #4a3426;
    --cafe-claro: #8b5a2b;
    --cafe-dorado: #d4a574;
    --beige: #f5e6d3;
    --texto-claro: #f8f4e9;
}

body {
    background: linear-gradient(135deg, var(--cafe-oscuro) 0%, var(--cafe-medio) 100%);
    color: var(--texto-claro);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 800px;
}

.btn-volver {
    background: linear-gradient(135deg, var(--cafe-claro) 0%, var(--cafe-dorado) 100%);
    color: var(--cafe-oscuro);
    padding: 12px 25px;
    border: none;
    border-radius: 25px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-volver:hover {
    transform: translateY(-2px);
    color: var(--cafe-oscuro);
}

.form-container {
    background: linear-gradient(135deg, var(--cafe-medio) 0%, rgba(74, 52, 38, 0.95) 100%);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    border: 1px solid var(--cafe-claro);
    margin-top: 20px;
}

.form-container h2 {
    text-align: center;
    color: var(--cafe-dorado);
    margin-bottom: 30px;
    font-size: 2.2rem;
    font-weight: 700;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    color: var(--cafe-dorado);
    font-weight: 600;
    margin-bottom: 8px;
}

.form-control {
    background: rgba(45, 27, 14, 0.85);
    border: 2px solid var(--cafe-claro);
    border-radius: 12px;
    color: var(--texto-claro);
    padding: 12px 15px;
    transition: all 0.3s ease;
}

.form-control:focus {
    background: rgba(45, 27, 14, 0.9);
    border-color: var(--cafe-dorado);
    box-shadow: 0 0 0 3px rgba(212, 165, 116, 0.2);
    color: var(--texto-claro);
}

.btn-crear {
    background: linear-gradient(135deg, var(--cafe-dorado) 0%, #e6b873 100%);
    color: var(--cafe-oscuro);
    padding: 15px 30px;
    border: none;
    border-radius: 12px;
    font-weight: 700;
    width: 100%;
    transition: all 0.3s ease;
    margin-top: 10px;
}

.btn-crear:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #e6b873 0%, var(--cafe-dorado) 100%);
}

.alert-custom {
    border-radius: 12px;
    border: none;
    margin-bottom: 20px;
}

.password-match {
    color: #28a745;
    font-size: 0.875em;
    margin-top: 5px;
}

.password-mismatch {
    color: #dc3545;
    font-size: 0.875em;
    margin-top: 5px;
}
</style>
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <a href="admin_panel.php" class="btn-volver">
                <span>⬅️</span> Volver al Dashboard
            </a>
            <h1 class="h3 mb-0 text-white">Agregar Nuevo Usuario</h1>
        </div>

        <!-- Mostrar mensajes de error -->
        <?php if (!empty($errores)): ?>
            <div class="alert alert-danger alert-custom">
                <strong>❌ Errores:</strong>
                <ul class="mb-0">
                    <?php foreach ($errores as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" action="" id="registroForm">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" 
                                   value="<?= htmlspecialchars($nombre ?? '') ?>" 
                                   required maxlength="50" placeholder="Ingresa el nombre">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="apellido">Apellido:</label>
                            <input type="text" class="form-control" id="apellido" name="apellido" 
                                   value="<?= htmlspecialchars($apellido ?? '') ?>" 
                                   required maxlength="50" placeholder="Ingresa el apellido">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?= htmlspecialchars($email ?? '') ?>" 
                           required maxlength="100" placeholder="usuario@ejemplo.com">
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="password">Contraseña:</label>
                            <input type="password" class="form-control" id="password" name="password" 
                                   required minlength="6" placeholder="Mínimo 6 caracteres">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="confirm_password">Confirmar Contraseña:</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                   required minlength="6" placeholder="Repite la contraseña">
                            <div id="password-match" class="password-match"></div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="rol">Rol:</label>
                    <select class="form-control" id="rol" name="rol" required>
                        <option value="cliente" <?= ($rol ?? '') === 'cliente' ? 'selected' : '' ?>>👥 Cliente</option>
                        <option value="gerente" <?= ($rol ?? '') === 'gerente' ? 'selected' : '' ?>>👔 Gerente</option>
                        <option value="empleado" <?= ($rol ?? '') === 'empleado' ? 'selected' : '' ?>>💼 Empleado</option>
                        <option value="cajero" <?= ($rol ?? '') === 'cajero' ? 'selected' : '' ?>>💰 Cajero</option>
                        <option value="repostero" <?= ($rol ?? '') === 'repostero' ? 'selected' : '' ?>>🍰 Repostero</option>
                    </select>
                </div>

                <button type="submit" name="registrar" class="btn-crear">
                    💾 Crear Usuario
                </button>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('registroForm');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordMatchDiv = document.getElementById('password-match');

        // Validación de coincidencia de contraseñas en tiempo real
        function checkPasswordMatch() {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (confirmPassword === '') {
                passwordMatchDiv.textContent = '';
                passwordMatchDiv.className = 'password-match';
            } else if (password === confirmPassword) {
                passwordMatchDiv.textContent = '✅ Las contraseñas coinciden';
                passwordMatchDiv.className = 'password-match';
            } else {
                passwordMatchDiv.textContent = '❌ Las contraseñas no coinciden';
                passwordMatchDiv.className = 'password-mismatch';
            }
        }

        // Event listeners
        passwordInput.addEventListener('input', checkPasswordMatch);
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);

        // Validación final antes de enviar
        form.addEventListener('submit', function(e) {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (password !== confirmPassword) {
                e.preventDefault();
                passwordMatchDiv.textContent = '❌ Las contraseñas no coinciden';
                passwordMatchDiv.className = 'password-mismatch';
                confirmPasswordInput.focus();
                alert('Por favor, asegúrate de que las contraseñas coincidan');
            }
        });
    });
    </script>
</body>
</html>