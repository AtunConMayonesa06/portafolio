// main.js - Protecciones cliente (ChinosCafe)
// Evita: click derecho, combinaciones de teclas comunes para "ver código/inspeccionar/guardar", copiar/pegar/seleccionar (excepto inputs)

(function () {
  'use strict';

  // --- Helpers ---
  function isInputElement(el) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    return tag === 'input' || tag === 'textarea' || el.isContentEditable;
  }

  // --- Bloquear menú contextual (clic derecho) ---
  document.addEventListener('contextmenu', function (e) {
    // permitir en inputs
    if (isInputElement(e.target)) return;
    e.preventDefault();
  }, { passive: false });

  // --- Bloquear selección de texto fuera de inputs ---
  // Aplica estilo para evitar selección en body pero habilitar en inputs/textareas
  try {
    const css = document.createElement('style');
    css.type = 'text/css';
    css.appendChild(document.createTextNode(
      'body { -webkit-user-select: none !important; -moz-user-select: none !important; -ms-user-select: none !important; user-select: none !important; }' +
      'input, textarea, [contenteditable="true"] { -webkit-user-select: text !important; -moz-user-select: text !important; -ms-user-select: text !important; user-select: text !important; }'
    ));
    document.head.appendChild(css);
  } catch (err) {
    // no hacer nada si falla
  }

  // --- Bloquear copiar/cortar/pegar fuera de inputs ---
  ['copy', 'cut', 'paste'].forEach(function (evt) {
    document.addEventListener(evt, function (e) {
      if (!isInputElement(e.target)) {
        e.preventDefault();
      }
    }, { passive: false });
  });

  // --- Bloquear arrastrar de imágenes/elementos ---
  document.addEventListener('dragstart', function (e) {
    if (!isInputElement(e.target)) e.preventDefault();
  }, { passive: false });

  // --- Bloquear combinaciones de teclas ---
  document.addEventListener('keydown', function (e) {
    // teclas de función que suelen abrir devtools
    if (e.key === 'F12') {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }

    // Ctrl/Meta combinaciones
    const ctrl = e.ctrlKey || e.metaKey;
    const shift = e.shiftKey;

    // Lista de combos a bloquear:
    // Ctrl+U (ver fuente), Ctrl+S (guardar), Ctrl+Shift+I (devtools), Ctrl+Shift+J, Ctrl+Shift+C, Ctrl+P (imprimir), Ctrl+Shift+K, Ctrl+U
    if (ctrl && !shift && (e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S' || e.key === 'p' || e.key === 'P')) {
      if (!isInputElement(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
    }

    if (ctrl && shift && (e.key.toLowerCase() === 'i' || e.key.toLowerCase() === 'j' || e.key.toLowerCase() === 'c' || e.key.toLowerCase() === 'k')) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }

    // Bloquear F1-F12 en general (opcional salvo F5)
    const fKeyMatch = /^F[1-9]$|^F1[0-2]$/;
    if (fKeyMatch.test(e.key) && e.key !== 'F5') {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  }, { passive: false, capture: true });

  // --- Evitar selección mediante doble clic ---
  document.addEventListener('dblclick', function (e) {
    if (!isInputElement(e.target)) {
      e.preventDefault();
    }
  }, { passive: false });

  // --- Protección adicional: interceptar requests que busquen archivos sensibles (solo UX) ---
  // Nota: esto no evita peticiones externas, solo evita que el usuario navegue en links del DOM.
  document.addEventListener('click', function (e) {
    const a = e.target.closest && e.target.closest('a');
    if (a && a.getAttribute('href')) {
      const href = a.getAttribute('href').toLowerCase();
      if (href.endsWith('.sql') || href.endsWith('.env') || href.endsWith('.ini')) {
        e.preventDefault();
      }
    }
  }, { passive: true });

})();
