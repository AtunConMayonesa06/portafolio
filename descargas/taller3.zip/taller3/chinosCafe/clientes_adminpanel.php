<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

include(__DIR__ . '/conexion.php');

/* ========= Bloquear / Desbloquear ========= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
  $id = (int)$_POST['id_usuario'];
  $accion = $_POST['accion'];

  if ($accion === 'bloquear') {
    $stmt = $conn->prepare("UPDATE clientes SET bloqueado = 1 WHERE id_usuario = ?");
    if ($stmt) {
      $stmt->bind_param("i", $id);
      if ($stmt->execute()) {
        $_SESSION['flash'] = ['tipo'=>'success','msg'=>'🚫 Cliente bloqueado correctamente.'];
      } else {
        $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ Error al bloquear cliente.'];
      }
      $stmt->close();
    }
  }

  if ($accion === 'desbloquear') {
    $stmt = $conn->prepare("UPDATE clientes SET bloqueado = 0 WHERE id_usuario = ?");
    if ($stmt) {
      $stmt->bind_param("i", $id);
      if ($stmt->execute()) {
        $_SESSION['flash'] = ['tipo'=>'success','msg'=>'✅ Cliente desbloqueado correctamente.'];
      } else {
        $_SESSION['flash'] = ['tipo'=>'error','msg'=>'❌ Error al desbloquear cliente.'];
      }
      $stmt->close();
    }
  }

  exit;
}

/* ========= Flash (avisos) ========= */
$flash = $_SESSION['flash'] ?? null;
if ($flash) unset($_SESSION['flash']);

/* ========= Obtener todos los usuarios (excepto admin) ========= */
$usuarios = $conn->query("SELECT * FROM clientes WHERE rol != 'admin' ORDER BY created_at DESC");

if (!$usuarios) {
  echo "<p style='color:red'>Error en consulta: " . $conn->error . "</p>";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="/ChinosCafe/css/productos_paneladmin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        .acciones-superiores {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn-agregar-usuario {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-agregar-usuario:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
        .acciones-container {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .btn-accion {
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.3s ease;
        }
        .btn-bloquear {
            background-color: #dc3545;
            color: white;
        }
        .btn-bloquear:hover {
            background-color: #c82333;
        }
        .btn-desbloquear {
            background-color: #28a745;
            color: white;
        }
        .btn-desbloquear:hover {
            background-color: #218838;
        }
        .btn-historial {
            background-color: #17a2b8;
            color: white;
        }
        .btn-historial:hover {
            background-color: #138496;
        }
        .estado-bloqueado {
            color: #dc3545;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 3px;
            background-color: #f8d7da;
        }
        .estado-activo {
            color: #28a745;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 3px;
            background-color: #d4edda;
        }
        .badge-rol {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .rol-cliente { background-color: #e3f2fd; color: #1565c0; }
        .rol-gerente { background-color: #fff3e0; color: #ef6c00; }
        .rol-empleado { background-color: #e8f5e8; color: #2e7d32; }
        .rol-cajero { background-color: #f3e5f5; color: #7b1fa2; }
        .rol-repostero { background-color: #fff8e1; color: #ff8f00; }
        .tabla-productos td {
            vertical-align: middle;
        }

        /* 🧾 Scroll interno para la tabla de usuarios */
        .tabla-productos-container {
          max-height: 450px;          /* altura máxima antes de mostrar scroll */
          overflow-y: auto;           /* activa el scroll vertical */
          margin-top: 10px;
          border: 1px solid #e6d7c3;
          border-radius: 10px;
          background-color: #fffaf3;
          scrollbar-width: thin;      /* scroll delgado (para Firefox) */
          scrollbar-color: #b58b55 #f5e8d3;
        }

        /* Estilo del scrollbar (para Chrome, Edge, etc.) */
        .tabla-productos-container::-webkit-scrollbar {
          width: 8px;
        }
        .tabla-productos-container::-webkit-scrollbar-thumb {
          background-color: #b58b55;
          border-radius: 5px;
        }
        .tabla-productos-container::-webkit-scrollbar-track {
          background-color: #f5e8d3;
        }

    </style>
</head>
<body>

<div class="acciones-superiores">
  <a href="admin_panel.php" class="btn-volver">⬅️ Volver al Dashboard</a>
  <a href="ingresar_usuarios.php" class="btn-agregar-usuario">
    👥 Agregar Usuario
  </a>
</div>

<h2>👥 Gestión de Usuarios</h2>

<div class="tabla-productos-container">
  <table class="tabla-productos">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Email</th>
        <th>Rol</th>
        <th>Fecha Registro</th>
        <th>Estado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($usuarios && $usuarios->num_rows > 0): ?>
        <?php while ($u = $usuarios->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$u['id_usuario'] ?></td>
          <td><?= htmlspecialchars($u['nombre']) ?></td>
          <td><?= htmlspecialchars($u['apellido']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td>
            <span class="badge-rol rol-<?= $u['rol'] ?>">
              <?= htmlspecialchars($u['rol']) ?>
            </span>
          </td>
          <td><?= date("d/m/Y H:i", strtotime($u['created_at'])) ?></td>
          <td>
            <?php if ($u['bloqueado']): ?>
              <span class="estado-bloqueado">🚫 Bloqueado</span>
            <?php else: ?>
              <span class="estado-activo">✅ Activo</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="acciones-container">
              <?php if ($u['bloqueado']): ?>
                <button type="button" class="btn-accion btn-desbloquear" onclick="cambiarEstado(<?= $u['id_usuario'] ?>, 'desbloquear')" title="Desbloquear usuario">
                  🔓
                </button>
              <?php else: ?>
                <button type="button" class="btn-accion btn-bloquear" onclick="cambiarEstado(<?= $u['id_usuario'] ?>, 'bloquear')" title="Bloquear usuario">
                  🚫
                </button>
              <?php endif; ?>

              <?php if ($u['rol'] === 'cliente'): ?>
                <a href="ver_historial.php?id_usuario=<?= $u['id_usuario'] ?>" class="btn-accion btn-historial" title="Ver historial de compras">
                  📊
                </a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="8">No hay usuarios registrados.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function cambiarEstado(id, accion) {
    const confirmMsg = accion === 'bloquear' 
        ? '¿Estás seguro de bloquear este usuario?'
        : '¿Estás seguro de desbloquear este usuario?';
    
    if (!confirm(confirmMsg)) return;
    
    const formData = new FormData();
    formData.append('id_usuario', id);
    formData.append('accion', accion);
    
    fetch('<?= basename($_SERVER['PHP_SELF']) ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            // Recargar la página para ver los cambios
            location.reload();
        } else {
            alert('Error al procesar la solicitud');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error de conexión');
    });
}
</script>

<?php if ($flash): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: '<?= $flash['tipo'] ?>',
        title: '<?= $flash['msg'] ?>',
        showConfirmButton: false,
        timer: 3000,
        background: '#3b2f2f',
        color: '#f8efe2'
    });
});
</script>
<?php endif; ?>

</body>
</html>