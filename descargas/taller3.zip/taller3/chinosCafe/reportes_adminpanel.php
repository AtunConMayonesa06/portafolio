<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

include(__DIR__ . '/conexion.php');

/* ========= Validar sesión admin ========= */
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
  header("Location: ../index.php");
  exit;
}

/* ========= Consultas estadísticas ========= */

// 1️⃣ Totales globales de ventas
$totalHoy = 0;
$totalMes = 0;
$totalAnio = 0;

if ($conn->query("SHOW TABLES LIKE 'ventas'")->num_rows > 0) {
  $totalHoy = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE DATE(fecha) = CURDATE()")->fetch_assoc()['total'] ?? 0;
  $totalMes = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE MONTH(fecha) = MONTH(CURDATE())")->fetch_assoc()['total'] ?? 0;
  $totalAnio = $conn->query("SELECT SUM(total) AS total FROM ventas WHERE YEAR(fecha) = YEAR(CURDATE())")->fetch_assoc()['total'] ?? 0;
}

// 2️⃣ Producto más vendido
$productoTop = null;
if ($conn->query("SHOW TABLES LIKE 'detalle_venta'")->num_rows > 0) {
  $productoTop = $conn->query("
    SELECT p.nombre, SUM(v.cantidad) AS total_vendido
    FROM detalle_venta v
    INNER JOIN inventario p ON p.id_producto = v.id_producto
    GROUP BY p.id_producto
    ORDER BY total_vendido DESC
    LIMIT 1
  ")->fetch_assoc();
}

// 3️⃣ Nuevos clientes registrados este mes
$clientesNuevos = 0;
if ($conn->query("SHOW TABLES LIKE 'clientes'")->num_rows > 0) {
  $clientesNuevos = $conn->query("
    SELECT COUNT(*) AS total
    FROM clientes
    WHERE MONTH(created_at) = MONTH(CURDATE())
  ")->fetch_assoc()['total'] ?? 0;
}

// 4️⃣ Ventas por día (últimos 7 días)
$labels = [];
$valores = [];
if ($conn->query("SHOW TABLES LIKE 'ventas'")->num_rows > 0) {
  $ventasDias = $conn->query("
    SELECT DATE(fecha) AS dia, SUM(total) AS total
    FROM ventas
    WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY dia
    ORDER BY dia ASC
  ");
  while ($r = $ventasDias->fetch_assoc()) {
    $labels[] = $r['dia'];
    $valores[] = $r['total'];
  }
}
?>

<link rel="stylesheet" href="/ChinosCafe/css/productos_paneladmin.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
/* 🎨 Estilos locales solo para #reportes-panel (no afecta otros módulos) */
#reportes-panel {
  background-color: #1e1b18;
  color: #f8efe2;
  font-family: "Poppins", sans-serif;
  padding: 15px 25px;
  border-radius: 10px;
}

#reportes-panel h2,
#reportes-panel h3 {
  color: #ffcf91;
  text-align: center;
  letter-spacing: 0.5px;
  margin-top: 15px;
}

#reportes-panel .resumen {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
  margin: 25px 0;
}

#reportes-panel .card {
  background: linear-gradient(135deg, #3b2f2f, #5a4034);
  border: 1px solid #4a3328;
  border-radius: 15px;
  padding: 18px;
  text-align: center;
  color: #f8efe2;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
#reportes-panel .card:hover {
  transform: translateY(-4px);
  box-shadow: 0 5px 14px rgba(255, 223, 186, 0.25);
}
#reportes-panel .card h4 {
  margin-bottom: 8px;
  color: #ffdd91;
}
#reportes-panel .card p {
  font-size: 1.3em;
  color: #fff7e6;
}

#reportes-panel .destacado {
  text-align: center;
  background-color: #32251f;
  padding: 20px;
  border-radius: 15px;
  margin: 25px auto;
  color: #f8efe2;
  box-shadow: 0 2px 10px rgba(0,0,0,0.3);
  width: 90%;
  max-width: 800px;
}
#reportes-panel .destacado strong {
  color: #ffdca8;
}

#reportes-panel canvas {
  background-color: #2b2520;
  border-radius: 12px;
  padding: 15px;
  width: 100%;
  max-width: 900px;
  margin: 0 auto;
  display: block;
  box-shadow: 0 2px 10px rgba(0,0,0,0.4);
}
#reportes-panel hr {
  border: 0;
  border-top: 1px solid #4d3b2f;
  margin: 30px auto;
  width: 90%;
}
#reportes-panel p {
  color: #f8efe2;
}

/* 🔘 Botón PDF */
#reportes-panel .btn-pdf {
  display: inline-block;
  margin: 20px auto;
  padding: 10px 20px;
  border-radius: 8px;
  background-color: #a87446;
  color: #fff9f0;
  text-decoration: none;
  font-weight: bold;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3);
  transition: background 0.2s ease, transform 0.2s ease;
}
#reportes-panel .btn-pdf:hover {
  background-color: #c98b54;
  transform: scale(1.05);
}
</style>

<div id="reportes-panel">

  <div class="acciones-superiores">
    <a href="admin_panel.php" class="btn-volver">⬅️ Volver al Dashboard</a>
  </div>

  <h2>📊 Reportes y Estadísticas</h2>

  <div class="resumen">
    <div class="card">
      <h4>💵 Ventas Hoy</h4>
      <p>$<?= number_format($totalHoy ?? 0, 2) ?></p>
    </div>

    <div class="card">
      <h4>📆 Ventas del Mes</h4>
      <p>$<?= number_format($totalMes ?? 0, 2) ?></p>
    </div>

    <div class="card">
      <h4>📅 Ventas del Año</h4>
      <p>$<?= number_format($totalAnio ?? 0, 2) ?></p>
    </div>

    <div class="card">
      <h4>🧍 Nuevos Clientes</h4>
      <p><?= $clientesNuevos ?></p>
    </div>
  </div>

  <?php if ($productoTop): ?>
  <div class="destacado">
    <h3>🏆 Producto Más Vendido</h3>
    <p><strong><?= htmlspecialchars($productoTop['nombre']) ?></strong> — <?= (int)$productoTop['total_vendido'] ?> unidades</p>
  </div>
  <?php else: ?>
  <div class="destacado">
    <h3>🏆 Producto Más Vendido</h3>
    <p>No hay registros de ventas todavía.</p>
  </div>
  <?php endif; ?>

  <hr>

  <h3>📈 Ventas Últimos 7 Días</h3>
  <?php if (!empty($labels)): ?>
    <canvas id="graficoVentas" height="120"></canvas>
  <?php else: ?>
    <p style="color:#b8a48b; text-align:center;">No hay ventas registradas en los últimos 7 días.</p>
  <?php endif; ?>

  <div style="text-align:center;">
    <a href="generar_reporte_pdf.php" class="btn-pdf" target="_blank">📄 Generar Reporte PDF</a>
  </div>

</div>

<script>
<?php if (!empty($labels)): ?>
const ctx = document.getElementById('graficoVentas');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($labels) ?>,
    datasets: [{
      label: 'Ventas ($)',
      data: <?= json_encode($valores) ?>,
      borderWidth: 2,
      borderColor: '#ffcf91',
      backgroundColor: '#d7a46caa',
      hoverBackgroundColor: '#f3b97d'
    }]
  },
  options: {
    plugins: {
      legend: { labels: { color: '#f8efe2' } },
    },
    scales: {
      x: {
        ticks: { color: '#f8efe2' },
        grid: { color: '#3d2f25' }
      },
      y: {
        ticks: { color: '#f8efe2' },
        grid: { color: '#3d2f25' },
        beginAtZero: true
      }
    }
  }
});
<?php endif; ?>
</script>
