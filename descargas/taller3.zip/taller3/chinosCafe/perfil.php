<?php
include('conexion.php');
include('includes/header.php');

// 🔐 Verificar sesión activa
if (!isset($_SESSION['id_usuario'])) {
    header("Location: /ChinosCafe/auth/login.php");
    exit();
}

$id = $_SESSION['id_usuario'];

// 🔍 Obtener datos actuales
$sql = "SELECT nombre, apellido, email, password_hash FROM clientes WHERE id_usuario = $id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// 🧾 PRG para evitar reenvío
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $hayCambios = ($nombre !== $user['nombre']) || ($apellido !== $user['apellido']) || ($email !== $user['email']) || !empty($password);

    if (!$hayCambios) {
        header("Location: perfil.php?msg=nochange");
        exit();
    }

    $checkEmail = $conn->query("SELECT id_usuario FROM clientes WHERE email='$email' AND id_usuario != $id");
    if ($checkEmail->num_rows > 0) {
        header("Location: perfil.php?msg=duplicado");
        exit();
    }

    if (!empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $update = "UPDATE clientes SET nombre='$nombre', apellido='$apellido', email='$email', password_hash='$hash' WHERE id_usuario=$id";
    } else {
        $update = "UPDATE clientes SET nombre='$nombre', apellido='$apellido', email='$email' WHERE id_usuario=$id";
    }

    if ($conn->query($update) === TRUE) {
        $_SESSION['nombre'] = $nombre;
        header("Location: perfil.php?msg=ok");
        exit();
    } else {
        header("Location: perfil.php?msg=error");
        exit();
    }
}
?>

<link rel="stylesheet" href="/ChinosCafe/css/perfil.css">

<div class="perfil-container">
  <div class="perfil-card">
    <h2 class="text-center mb-4 fw-bold">👤 Mi Perfil</h2>

    <?php
    if (isset($_GET['msg'])) {
        switch ($_GET['msg']) {
            case 'ok':
                echo "<div class='alert alert-success text-center mensaje-bonito'>✅ Datos actualizados correctamente.</div>";
                break;
            case 'nochange':
                echo "<div class='alert alert-warning text-center mensaje-bonito'>⚠️ No se hizo ningún cambio.</div>";
                break;
            case 'duplicado':
                echo "<div class='alert alert-warning text-center mensaje-bonito'>⚠️ El correo ya está en uso por otro usuario.</div>";
                break;
            case 'error':
                echo "<div class='alert alert-danger text-center mensaje-bonito'>❌ Error al actualizar los datos.</div>";
                break;
        }
    }
    ?>

    <form method="POST" id="formPerfil" novalidate onsubmit="return validarEnvio();">
      <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control campo" value="<?= htmlspecialchars($user['nombre']); ?>" required autocomplete="off">
      </div>
      <div class="mb-3">
        <label class="form-label">Apellido</label>
        <input type="text" name="apellido" class="form-control campo" value="<?= htmlspecialchars($user['apellido']); ?>" required autocomplete="off">
      </div>
      <div class="mb-3">
        <label class="form-label">Correo electrónico</label>
        <input type="email" name="email" class="form-control campo" value="<?= htmlspecialchars($user['email']); ?>" required autocomplete="off">
      </div>
      <div class="mb-3">
        <label class="form-label">Nueva contraseña (opcional)</label>
        <input type="password" name="password" class="form-control campo" placeholder="••••••••••" autocomplete="new-password">
      </div>

      <button type="submit" name="actualizar" id="btnGuardar" class="btn btn-light w-100 fw-bold btn-disabled" disabled>Guardar Cambios</button>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('formPerfil');
  const campos = form.querySelectorAll('.campo');
  const btn = document.getElementById('btnGuardar');

  // Guardar valores iniciales
  const original = {};
  campos.forEach(c => original[c.name] = c.value.trim());

  // Desactivar clics de forma total
  btn.addEventListener('click', e => {
    if (btn.disabled) {
      e.preventDefault();
      e.stopImmediatePropagation();
      return false;
    }
  });

  // Verificar cambios reales
  function verificar() {
    let cambio = false;
    campos.forEach(c => {
      const val = c.value.trim();
      const orig = original[c.name];
      if (c.name === 'password' && val !== '') cambio = true;
      else if (val !== orig) cambio = true;
    });

    if (cambio) {
      btn.disabled = false;
      btn.classList.remove('btn-disabled');
    } else {
      btn.disabled = true;
      btn.classList.add('btn-disabled');
    }
  }

  campos.forEach(c => c.addEventListener('input', verificar));
  verificar();
});

// Protección adicional al enviar
function validarEnvio() {
  const btn = document.getElementById('btnGuardar');
  if (btn.disabled) {
    alert('⚠️ No se hizo ningún cambio.');
    return false;
  }
  return true;
}
</script>

<?php include('includes/footer.php'); ?>
