<?php
// footer.php
?>
</div> <!-- Cierre del container principal -->

<footer class="text-center text-muted py-3 bg-white shadow-sm mt-5">
    <small>© 2025 Chinos Café | Sistema desarrollado en PHP y MySQL</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/ChinosCafe/scripts/main.js"></script>
</body>
</html>
