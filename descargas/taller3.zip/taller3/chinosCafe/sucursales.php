<?php
include(__DIR__ . '/conexion.php');

// 🔍 Consultar todas las sucursales activas
$query = "SELECT * FROM sucursales WHERE activo = 1 ORDER BY id_sucursal ASC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sucursales | Chinos Café</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #1e1e1e;
      color: #f5f5f5;
      font-family: 'Poppins', sans-serif;
    }

    .hero {
      background: url('/ChinosCafe/img/sucursales.png') center/cover no-repeat;
      height: 55vh;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      text-shadow: 0 2px 8px rgba(0,0,0,0.7);
    }
    .hero::after {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(0,0,0,0.5);
    }
    .hero h1 {
      position: relative;
      font-size: 3rem;
      font-weight: 700;
      z-index: 2;
    }

    .section {
      padding: 4rem 0;
    }

    .card-sucursal {
      background-color: #2b1b13;
      border: none;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 6px 20px rgba(0,0,0,0.4);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card-sucursal:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.6);
    }
    .card-sucursal img {
      width: 100%;
      height: 260px;
      object-fit: cover;
    }
    .card-body {
      padding: 1.5rem;
    }
    .card-body h3 {
      color: #d4a373;
      font-weight: 600;
    }
    .divider {
      width: 60px;
      height: 4px;
      background: #d4a373;
      border-radius: 3px;
      margin: 1rem 0;
    }
    iframe {
      border-radius: 12px;
      width: 100%;
      height: 250px;
      border: none;
      margin-top: 10px;
    }
  </style>
</head>
<body>

<!-- 🔝 Navbar -->
<?php include(__DIR__ . '/includes/header.php'); ?>

<!-- 🏞️ Portada -->
<section class="hero text-center">
  <h1>Nuestras Sucursales</h1>
</section>

<!-- 🏢 Lista de sucursales -->
<section class="section">
  <div class="container">
    <div class="row g-5">
      <?php while($sucursal = $result->fetch_assoc()): ?>
        <div class="col-lg-4 col-md-6">
          <div class="card-sucursal">
            <img src="/ChinosCafe/img/sucursales/<?php echo strtolower(str_replace(' ', '_', $sucursal['nombre'])); ?>.png" alt="<?php echo $sucursal['nombre']; ?>">
            <div class="card-body">
              <h3><?php echo htmlspecialchars($sucursal['nombre']); ?></h3>
              <div class="divider"></div>
              <p class="mb-2"><strong>📍 Dirección:</strong> <?php echo htmlspecialchars($sucursal['direccion']); ?></p>
              <p class="mb-2"><strong>📞 Teléfono:</strong> <?php echo htmlspecialchars($sucursal['telefono']); ?></p>
              <p class="mb-2"><strong>🕒 Horario:</strong> <?php echo htmlspecialchars($sucursal['horario']); ?></p>
              <p class="mb-3"><?php echo nl2br(htmlspecialchars($sucursal['descripcion'])); ?></p>
              <?php if (!empty($sucursal['mapa_url'])): ?>
                <iframe src="<?php echo $sucursal['mapa_url']; ?>" allowfullscreen="" loading="lazy"></iframe>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<!-- ✨ Imagen decorativa de cierre -->
<section class="text-center py-5" style="background:#2b1b13;">
  <div class="container">
    <img src="/ChinosCafe/img/cafe_team.jpg" alt="Equipo Chinos Café" class="img-fluid rounded shadow-lg mb-3" style="max-height:400px;">
    <h2 class="text-light mt-3">☕ ¡Te esperamos en cualquiera de nuestras sucursales!</h2>
    <p class="text-muted fst-italic">Ven, disfruta, y sé parte de nuestra familia cafetera.</p>
  </div>
</section>

<!-- 🔻 Footer -->
<footer class="text-center py-4" style="background:#1a120c;">
  <p class="mb-0 text-light">
    &copy; <?php echo date('Y'); ?> Chinos Café. Todos los derechos reservados.
  </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
