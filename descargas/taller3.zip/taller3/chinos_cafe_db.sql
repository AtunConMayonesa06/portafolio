-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: chinos_cafe_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('cliente','admin','gerente','empleado','cajero','repostero') DEFAULT 'cliente',
  `id_sucursal` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bloqueado` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Carlos','Miranda','admin@chinoscafe.com','$2y$10$FTjtBw5ntlFo.twZuX02yeVEEGqdwgMFNXyp9ZiYmugnyd6VSH5zC','admin',1,'2025-10-27 04:38:52','2025-10-27 05:43:03',0),(2,'Carlos','Miranda','badleon2744@gmail.com','$2y$10$PGN6tUWAjJFd0dAlpSz1AOwsEBeKHRBlx9LcJf3xExvnB6L/gEINO','cliente',1,'2025-10-27 04:54:49','2025-10-27 10:05:27',0),(3,'Eddie','Man','eddieman02@gmail.com','$2y$10$WrlygzBJHPeUc/P6Q1Ts/.cGpZATQvNV5K38tPLtt1RHrf5Vi8/7e','cliente',1,'2025-10-27 05:06:49','2025-10-27 12:19:21',0),(4,'Carlos','Prueba','carlos518@gmail.com','$2y$10$IqotSTcPpKKTCxwxl3//J.Q/SzdArDPMZg4lcBu9dq1EPbWN5dJ1a','cliente',1,'2025-10-27 12:59:17','2025-10-27 12:59:17',0),(5,'Carlos','Prueba','carlos570@gmail.com','$2y$10$xwsyqu.bEFArO9F.ZmbmkePJbjJpyxyLGxCsmCOVFRO.G59u/3zQW','cajero',1,'2025-10-27 12:59:43','2025-10-27 12:59:43',0),(6,'Harold','Morales','harold2904@gmail.com','$2y$10$u7qPw2bacCUaNNON7lgO/ODKjN28JXTA.DodXQ9sqJAl5uFIguON.','gerente',1,'2025-10-27 13:25:46','2025-10-27 13:25:46',0),(7,'Brayan','Quintero','brayanquintero92@gmail.com','$2y$10$EG1lxSQcp.TRI1fWYEXGrO8GIymXns26u6mzdeobHjpjHb6Ii8Cde','cliente',1,'2025-10-27 16:33:26','2025-10-27 16:33:26',0),(8,'Elias','Samudio','elias02@gmail.com','$2y$10$ZIY9EH1cazH81FahgqKNwe/HzHBWv0Cut.u4EERFNf5TgkE7fDYou','cliente',1,'2025-10-27 16:46:35','2025-10-27 18:00:48',0),(9,'Wilfredo','Matute','Matute02@gmail.com','$2y$10$Ae2kmCT.X8eUN66zcqgjoO9s6nDkJGBuZ20FxCwsVMuoG2moT11bi','cliente',1,'2025-10-27 16:48:05','2025-10-27 16:48:05',0),(10,'James','Rico5','JamesRico02@gmail.com','$2y$10$8kCtY2o1CtXLbnN0bFFUaeEL/PL/4SA9VgGR1MneJ.x/AjlwkgKmu','cliente',1,'2025-10-27 16:51:14','2025-10-27 17:18:51',0),(11,'Joselyn','DeGracia','Joselyn2@gmail.com','$2y$10$xYxy0sgCnynHoqhEWgKosOozBosFe5fPQi9OK8q/E.qglVcxr.uEq','cliente',1,'2025-10-27 16:54:29','2025-10-27 16:54:29',0),(12,'jose','mendoza','jose@gmail.com','$2y$10$wRXBTTePoNqemy6U3/0enOHSRwpCDTuAFfGVTXlZJqrN28eVqjUt2','cliente',1,'2025-10-27 17:55:02','2025-10-27 17:55:02',0);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `id_config` int NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email_contacto` varchar(100) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `horario` varchar(100) DEFAULT NULL,
  `lema` varchar(150) DEFAULT NULL,
  `facebook` varchar(150) DEFAULT NULL,
  `instagram` varchar(150) DEFAULT NULL,
  `actualizado` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES (1,'Chinos Cafe','+507 6000-0000','contacto@chinoscafe.com','Calle Principal, Ciudad de Panamá','Lunes a Domingo: 7:00am - 9:00pm','El sabor que despierta tus mañanas ☕','https://facebook.com/chinoscafe','https://instagram.com/chinoscafe','2025-10-27 10:33:58');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `precio` decimal(10,2) NOT NULL,
  `stock` int DEFAULT '0',
  `imagen` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `id_proveedor` int DEFAULT NULL,
  `categoria` varchar(50) DEFAULT 'General',
  PRIMARY KEY (`id_producto`),
  KEY `fk_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES (45,'Café Espresso','Café puro y concentrado, extraído bajo presión',2.00,1,'1761541083_espresso-RrCckvN0LEAFk54KAQQPcXM-1200x840_Diario_Vasco.png','2025-10-27 09:58:03',1,'Cafés'),(46,'Cappuccino Italiano','Espresso con leche vaporizada y espuma cremosa',3.75,6,'1761548086_capuccino-italiano.png','2025-10-27 11:54:46',1,'Cafés'),(47,'Latte Macchiato','Leche vaporizada con un toque de espresso',4.25,8,'1761548213_latte-macchiato.png','2025-10-27 11:56:53',1,'Cafés'),(48,'Tres Leches Clásico','Bizcocho esponjoso bañado en tres leches',4.50,7,'1761548281_torta_tres_leches_8910_orig.jpg','2025-10-27 11:58:01',3,'Pasteles'),(49,'Cheesecake de Fresa','Tarta de queso cremosa con salsa de fresa',5.25,9,'1761548398_7f9ebeaceea909a80306da27f0495c59.png','2025-10-27 11:59:58',2,'Pasteles'),(50,'Brownie de Chocolate','Brownie intenso de chocolate con nueces',3.75,4,'1761548455_brownie-de-chocolate.png','2025-10-27 12:00:55',5,'Pasteles'),(51,'Té Vanilla Chai Latte','Té especiado con leche vaporizada.',4.00,10,'1761548611_vanilla-chai-latte.png','2025-10-27 12:03:31',4,'Bebidas'),(52,'Limonada de Menta','Limonada fresca con hojas de menta.',3.50,10,'1761548695_12803.jpg.webp','2025-10-27 12:04:55',3,'Bebidas'),(53,'Sandwich Club','Pavo, tocino, lechuga y tomate',6.75,10,'1761548760_images.jpg','2025-10-27 12:06:00',2,'Sandwiches'),(54,'Agua Mineral 500ml','Agua purificada sin gas',1.50,10,'1761548842_agua.jpg','2025-10-27 12:07:22',1,'Bebidas'),(55,'Croissant de Mantequilla','Croissant hojaldrado y dorado',2.25,10,'1761548921_images__1_.jpg','2025-10-27 12:08:41',3,'Postres'),(56,'Kachitos Twist Pizza 28 Gramos','Palitos de maíz con sabor a pizza',1.25,9,'1761549092_99ah270981_lpinfkd30kq4effe.webp','2025-10-27 12:11:32',4,'General');
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Café Panamá S.A.','6789-1122','ventas@cafepanama.com','Vía España, Ciudad de Panamá',1),(2,'Granos del Sur','6543-9876','contacto@granosdelsur.com','Los Andes No. 3, San Miguelito',1),(3,'Distribuidora Aroma Fino','6998-5522','aromafino@distribuidora.com','Avenida Central, Chitré',1),(4,'Café Orgánico del Valle','6123-8877','ventas@valleorganico.com','Volcán, Chiriquí',1),(5,'Comercial La Taza','6200-4433','latza@comercial.com','David, Chiriquí',1);
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sucursales`
--

DROP TABLE IF EXISTS `sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sucursales` (
  `id_sucursal` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `horario` varchar(100) DEFAULT NULL,
  `descripcion` text,
  `mapa_url` text,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursales`
--

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;
INSERT INTO `sucursales` VALUES (1,'Sucursal Central','Av. Central #123, Ciudad de Panamá','+507 6789-1234','Lun-Dom: 7:00am - 9:00pm','Nuestra sucursal principal donde comenzó la historia de Chinos Café, con el mejor ambiente artesanal.','https://www.google.com/maps/embed?...',1),(2,'Sucursal San Miguelito','Calle 8, Plaza del Sol, San Miguelito','+507 6123-9876','Lun-Sáb: 8:00am - 8:00pm','Un espacio acogedor con aroma a café y repostería recién hecha.','https://www.google.com/maps/embed?...',1),(3,'Sucursal David','Calle F Sur, frente al parque Cervantes, David, Chiriquí','+507 6987-2345','Lun-Dom: 7:00am - 10:00pm','Nuestra nueva sucursal en el interior del país, con terraza al aire libre y música en vivo los fines de semana.','https://www.google.com/maps/embed?...',1);
/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL DEFAULT '1',
  `total` decimal(10,2) NOT NULL,
  `fecha` datetime DEFAULT CURRENT_TIMESTAMP,
  `metodo_pago` varchar(20) DEFAULT 'efectivo',
  `estado` varchar(20) DEFAULT 'completada',
  PRIMARY KEY (`id_venta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `clientes` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `inventario` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (1,2,45,1,2.00,'2025-10-27 10:33:03','Efectivo','Pagado'),(2,2,45,1,2.00,'2025-10-27 10:35:25','Efectivo','Pagado'),(3,2,45,1,2.00,'2025-10-27 10:37:29','Efectivo','Pagado'),(4,2,45,1,2.00,'2025-10-27 11:07:08','Efectivo','Pagado'),(5,2,49,1,5.25,'2025-10-27 11:07:08','Efectivo','Pagado'),(6,2,48,1,4.50,'2025-10-27 11:07:08','Efectivo','Pagado'),(7,2,50,6,22.50,'2025-10-27 11:07:08','Efectivo','Pagado'),(8,2,48,1,4.50,'2025-10-27 11:09:23','Efectivo','Pagado'),(9,2,56,1,1.25,'2025-10-27 11:10:21','Efectivo','Pagado'),(10,7,45,1,2.00,'2025-10-27 12:34:14','Efectivo','Pagado'),(11,1,45,2,4.00,'2025-10-27 07:47:00','Efectivo','Pagado'),(12,12,46,4,15.00,'2025-10-27 07:56:59','Efectivo','Pagado'),(13,12,47,2,8.50,'2025-10-27 07:56:59','Efectivo','Pagado'),(14,12,48,1,4.50,'2025-10-27 07:56:59','Efectivo','Pagado');
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-28  0:53:16
