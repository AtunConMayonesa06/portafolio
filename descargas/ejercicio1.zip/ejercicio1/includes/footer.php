  <footer>
    <p>© 2025 SUCESOS y MÁS - Todos los derechos reservados.</p>
    <p>📍 Calle 50, Plaza Central, Ciudad de Panamá</p>
  </footer>
</body>
</html>
