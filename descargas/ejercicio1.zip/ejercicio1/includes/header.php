<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>SUCESOS y MÁS</title>
  <script>
    (function() {
      const savedTheme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = `css/style-${savedTheme}.css`;
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", savedTheme);
    })();
  </script>

  <script src="js/theme.js" defer></script>
  <script src="js/protect.js" defer></script>
</head>
<body>
  <header>
    <nav class="navbar">
      <a href="index.php">Inicio</a>
      <a href="clientes.php">Clientes</a>
      <a href="productos.php">Productos</a>
      <a href="servicios.php">Servicios</a>
      <a href="contactos.php">Contactos</a>
    </nav>
  </header>
