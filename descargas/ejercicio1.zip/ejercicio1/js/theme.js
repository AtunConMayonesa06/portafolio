function toggleTheme() {
  const link = document.getElementById("theme-style");
  const current = link.getAttribute("href").includes("dark") ? "dark" : "light";
  const next = current === "light" ? "dark" : "light";
  link.href = `css/style-${next}.css`;
  localStorage.setItem("theme", next);
}

window.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("theme") || "light";
  document.getElementById("theme-style").href = `css/style-${savedTheme}.css`;
});
