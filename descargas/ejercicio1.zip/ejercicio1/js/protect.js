// js/protect.js
// Bloquea clic derecho, selección, atajos comunes (Windows y Mac), y eventos de copia.
// NOTA: esto es por seguridad por UI; usuarios determinados aún pueden evitarlo.

(() => {
  // Evitar menú contextual (clic derecho)
  document.addEventListener("contextmenu", e => e.preventDefault());

  // Evitar selección de texto globalmente, excepto en inputs/textarea
  const disableSelectionCSS = `
    .no-select, .no-select * { -webkit-user-select: none !important; -moz-user-select: none !important; -ms-user-select: none !important; user-select: none !important; }
    input, textarea, select { -webkit-user-select: text !important; -moz-user-select: text !important; -ms-user-select: text !important; user-select: text !important; }
  `;
  const style = document.createElement("style");
  style.id = "protect-style";
  style.appendChild(document.createTextNode(disableSelectionCSS));
  document.head.appendChild(style);

  // Añadir clase no-select al body para aplicar el CSS
  document.addEventListener("DOMContentLoaded", () => {
    document.body.classList.add("no-select");
  });

  // Evitar arrastrar imágenes
  document.addEventListener("dragstart", e => {
    if (e.target && e.target.tagName === "IMG") e.preventDefault();
  });

  // Bloquear eventos de copia / cortar / pegar
  ["copy", "cut", "paste"].forEach(evt =>
    document.addEventListener(evt, e => e.preventDefault())
  );

  // Atajos de teclado (Windows/Linux y Mac)
  document.addEventListener("keydown", e => {
    // Teclas modificadoras
    const ctrl = e.ctrlKey || e.metaKey; // metaKey para Mac (⌘)
    const shift = e.shiftKey;

    // Bloquear inspección / ver código / guardar / buscar
    // F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+S, Ctrl+C, Ctrl+Shift+C
    if (
      e.key === "F12" ||
      (ctrl && shift && (e.key === "I" || e.key === "J" || e.key === "C")) ||
      (ctrl && (e.key === "U" || e.key === "S" || e.key === "C"))
    ) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  });

  // Mensaje opcional al usuario que intenta copiar (no obligatorio)
  // document.addEventListener('copy', ()=> alert('Contenido protegido'));
})();
