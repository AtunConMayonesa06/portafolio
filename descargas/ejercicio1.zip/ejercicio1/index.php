<?php include("includes/header.php"); ?>
<main>
  <!-- Hero principal -->
  <section class="hero">
    <h1>Bienvenido a <span>SUCESOS y MÁS</span></h1>
    <p>Tu fuente confiable de noticias, eventos y servicios profesionales en Panamá.</p>
    <button onclick="toggleTheme()">🌓 Cambiar tema</button>
  </section>

  <!-- Sobre nosotros -->
  <section class="about">
    <h2>💡 Sobre Nosotros</h2>
    <p>
      Somos una empresa dedicada a brindar soluciones tecnológicas, informativas y de comunicación digital
      para pequeñas y medianas empresas. Nuestro objetivo es conectar a las personas con las noticias más relevantes,
      promoviendo el crecimiento y la innovación.
    </p>
  </section>

  <!-- Servicios destacados -->
  <section class="servicios-home">
    <h2>⚙ Servicios Destacados</h2>
    <div class="cards">
      <div class="card">
        <img src="https://via.placeholder.com/300x180?text=Desarrollo+Web" alt="Desarrollo Web">
        <h3>Desarrollo Web</h3>
        <p>Diseños profesionales, modernos y adaptables a cualquier dispositivo. ¡Lleva tu marca al siguiente nivel!</p>
        <a href="servicios.php">Ver más</a>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/300x180?text=Marketing+Digital" alt="Marketing Digital">
        <h3>Marketing Digital</h3>
        <p>Campañas personalizadas que impulsan tu presencia en redes sociales y motores de búsqueda.</p>
        <a href="servicios.php">Ver más</a>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/300x180?text=Gestión+de+Noticias" alt="Noticias">
        <h3>Gestión de Noticias</h3>
        <p>Publica y gestiona tus propios contenidos informativos con nuestra plataforma flexible y segura.</p>
        <a href="servicios.php">Ver más</a>
      </div>
    </div>
  </section>

  <!-- Últimos trabajos y noticias -->
  <section class="noticias">
    <h2>📰 Últimos Trabajos y Noticias</h2>
    <div class="collage">
      <div class="news-item">
        <img src="https://via.placeholder.com/250x160?text=Proyecto+Empresarial" alt="Proyecto Empresarial">
        <h3>Proyecto Empresarial</h3>
        <p>Desarrollamos un portal de noticias para una compañía local, con panel de administración y diseño moderno.</p>
        <a href="#">Leer más</a>
      </div>
      <div class="news-item">
        <img src="https://via.placeholder.com/250x160?text=Campaña+2025" alt="Campaña 2025">
        <h3>Campaña 2025</h3>
        <p>Lanzamos una campaña de comunicación efectiva con resultados de alcance regional y 500K visitas mensuales.</p>
        <a href="#">Leer más</a>
      </div>
      <div class="news-item">
        <img src="https://via.placeholder.com/250x160?text=Web+Corporativa" alt="Web Corporativa">
        <h3>Web Corporativa</h3>
        <p>Diseñamos un sitio corporativo responsive, con optimización SEO y conexión directa con redes sociales.</p>
        <a href="#">Leer más</a>
      </div>
    </div>
  </section>
</main>
<?php include("includes/footer.php"); ?>
