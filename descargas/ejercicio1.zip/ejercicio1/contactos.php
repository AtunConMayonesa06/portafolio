<?php include("includes/header.php"); ?>
<main>
  <h1>📞 Contáctanos</h1>
  <p>Puedes escribirnos a <strong>contacto@sucesosymas.com</strong></p>
  <p>📍 Dirección: Calle 50, Plaza Central, Ciudad de Panamá</p>
</main>
<?php include("includes/footer.php"); ?>
