<?php include("includes/header.php"); ?>
<main>
  <h1>🛍 Nuestros Productos</h1>
  <ul>
    <li>Diseño Web Profesional</li>
    <li>Campañas de Marketing</li>
    <li>Gestión de Redes Sociales</li>
  </ul>
</main>
<?php include("includes/footer.php"); ?>
