<?php include("includes/header.php"); ?>
<main>
  <h1>⚙ Servicios</h1>
  <p>Ofrecemos servicios de desarrollo web, mantenimiento y soporte técnico 24/7.</p>
</main>
<?php include("includes/footer.php"); ?>
