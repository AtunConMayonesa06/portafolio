<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Configuración Técnica</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>2️⃣ Configuración Técnica</h1>
    <p>Se configuraron los archivos <code>my.ini</code> (Windows) y <code>my.cnf</code> (Ubuntu) para establecer la replicación.</p>
    <div class="code-box">
      <h3>Windows (Maestro)</h3>
<pre>
[mysqld]
port=3307
server-id=1
log-bin=mysql-bin
binlog-do-db=investigacion3_db
bind-address=0.0.0.0
</pre>

      <h3>Ubuntu (Esclavo)</h3>
<pre>
[mysqld]
port=3306
server-id=2
replicate-do-db=investigacion3_db
</pre>
    </div>
    <div class="nav-buttons">
      <a href="conceptos.php" class="btn-prev">← Anterior</a>
      <a href="demostracion.php" class="btn-next">Siguiente →</a>
    </div>
  </div>
</body>
<script src="js/protect.js"></script>
</html>
