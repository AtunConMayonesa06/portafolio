<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conclusiones</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>5️⃣ Conclusiones</h1>
    <ul class="content-list">
      <li>La replicación maestro–esclavo entre Windows y Ubuntu se implementó con éxito.</li>
      <li>Se logró una sincronización en tiempo real de la base de datos.</li>
      <li>El sistema PHP ofrece gestión de datos desde una interfaz moderna.</li>
      <li>Este proceso garantiza consistencia de información en entornos distribuidos.</li>
    </ul>
    <div class="nav-buttons">
      <a href="demostracion.php" class="btn-prev">← Anterior</a>
      <a href="index.php" class="btn-next">🏁 Finalizar</a>
    </div>
  </div>
  <script src="js/protect.js"></script>
</body>
</html>
