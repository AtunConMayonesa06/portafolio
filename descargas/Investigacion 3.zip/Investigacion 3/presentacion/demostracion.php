<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Demostración Práctica</title>
  <!-- Se mantiene tu mismo style.css -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>3️⃣ Demostración del Sistema PHP</h1>
    <ul class="content-list">
      <li>Conexión a la base de datos <b>investigacion3_db</b>.</li>
      <li>Inserción, actualización y eliminación de usuarios.</li>
      <li>Diseño moderno con modo oscuro.</li>
      <li>Replicación activa entre Windows y Ubuntu en tiempo real.</li>
    </ul>

    <div class="img-box">
      <img src="img/demo1.png" alt="Interfaz del sistema">
      <p class="img-desc">Vista general del sistema PHP con base de datos replicada.</p>
    </div>

    <!-- 🔹 Navegación actualizada -->
    <div class="nav-buttons">
      <a href="configuracion.php" class="btn-prev">← Anterior</a>
      <a href="replicacion_mongodb.php" class="btn-next">Siguiente →</a>
    </div>
  </div>
</body>
<script src="js/protect.js"></script>
</html>
