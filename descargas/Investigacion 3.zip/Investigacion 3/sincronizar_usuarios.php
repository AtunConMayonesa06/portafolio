<?php
require 'vendor/autoload.php'; // Librería MongoDB (instalada con Composer)

// 🔹 Conexión a MySQL
$mysqli = new mysqli("localhost", "root", "", "investigacion3_db", 3307);
if ($mysqli->connect_errno) {
    die("❌ Error al conectar con MySQL: " . $mysqli->connect_error);
}

// 🔹 Conexión a MongoDB
try {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    $db = $client->selectDatabase("investigacion3_nosql");
    $collection = $db->selectCollection("usuarios");
} catch (Exception $e) {
    die("❌ Error al conectar con MongoDB: " . $e->getMessage());
}

// 🔹 Obtener registros actualizados de MySQL
$result = $mysqli->query("SELECT * FROM usuarios");

if ($result && $result->num_rows > 0) {
    // Limpiar colección anterior para sincronización completa
    $collection->drop();
    $collection = $db->selectCollection("usuarios");

    while ($row = $result->fetch_assoc()) {
        $collection->insertOne($row);
    }

    echo "<p style='color:green;'>✅ MongoDB actualizado: " . $collection->countDocuments() . " registros sincronizados.</p>";
} else {
    echo "<p style='color:orange;'>⚠️ No hay datos en MySQL para sincronizar.</p>";
}

$mysqli->close();
?>
