<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "investigacion3_db";
$port = 3307; // usa 3306 si estás en Ubuntu o si tu XAMPP usa ese puerto

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
