<?php
require 'vendor/autoload.php'; // Para MongoDB
session_start();

// 🔹 Conexión MySQL
$conn = new mysqli("localhost", "root", "", "investigacion3_db", 3307);
if ($conn->connect_error) {
  die("❌ Error de conexión: " . $conn->connect_error);
}

// 🔹 Conexión MongoDB
try {
  $client = new MongoDB\Client("mongodb://localhost:27017");
  $db = $client->selectDatabase("investigacion3_nosql");
  $collection = $db->selectCollection("usuarios");
} catch (Exception $e) {
  die("<div class='alert error'>❌ Error con MongoDB: " . $e->getMessage() . "</div>");
}

// ======================== CRUD ========================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // INSERTAR
  if (isset($_POST['insertar'])) {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];

    if ($conn->query("INSERT INTO usuarios (nombre, correo) VALUES ('$nombre','$correo')")) {
      $_SESSION['mensaje'] = "✅ Usuario registrado y sincronizado correctamente";
    } else {
      $_SESSION['mensaje'] = "❌ Error al insertar: " . $conn->error;
    }
  }

  // ACTUALIZAR
  if (isset($_POST['actualizar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];

    if ($conn->query("UPDATE usuarios SET nombre='$nombre', correo='$correo' WHERE id=$id")) {
      $_SESSION['mensaje'] = "✏️ Usuario actualizado correctamente";
    } else {
      $_SESSION['mensaje'] = "❌ Error al actualizar: " . $conn->error;
    }
  }

  // ELIMINAR
  if (isset($_POST['eliminar'])) {
    $id = $_POST['id'];
    if ($conn->query("DELETE FROM usuarios WHERE id=$id")) {
      $_SESSION['mensaje'] = "🗑️ Usuario eliminado correctamente";
    } else {
      $_SESSION['mensaje'] = "❌ Error al eliminar: " . $conn->error;
    }
  }

  // 🔁 Sincronizar con MongoDB después de cambios
  $result = $conn->query("SELECT * FROM usuarios");
  $collection->drop();
  while ($row = $result->fetch_assoc()) {
    $collection->insertOne($row);
  }

  // 🚀 Redirigir para evitar el reenvío del formulario
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
}

// ======================== CONSULTA ========================
$result = $conn->query("SELECT * FROM usuarios ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Replicación MySQL → MongoDB</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <div class="container">
    <h1>📡 Replicación MySQL → Ubuntu → MongoDB</h1>

    <?php 
    if (isset($_SESSION['mensaje'])) {
      echo "<div class='alert success'>{$_SESSION['mensaje']}</div>";
      unset($_SESSION['mensaje']); // se borra después de mostrarla
    }
    ?>

    <form method="POST" class="form">
      <input type="text" name="nombre" placeholder="Nombre completo" required>
      <input type="email" name="correo" placeholder="Correo electrónico" required>
      <button type="submit" name="insertar">💾 Guardar</button>
    </form>

    <table>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Fecha</th>
        <th>Acciones</th>
      </tr>
      <?php
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo "<tr>
            <form method='POST'>
              <td>{$row['id']}</td>
              <td><input type='text' name='nombre' value='{$row['nombre']}' required></td>
              <td><input type='email' name='correo' value='{$row['correo']}' required></td>
              <td>{$row['fecha_registro']}</td>
              <td>
                <input type='hidden' name='id' value='{$row['id']}'>
                <button name='actualizar' class='btn-accion btn-update'>💾</button>
                <button name='eliminar' class='btn-accion btn-delete' onclick='return confirm(\"¿Eliminar este usuario?\")'>🗑️</button>
              </td>
            </form>
          </tr>";
        }
      } else {
        echo "<tr><td colspan='5'>No hay usuarios registrados.</td></tr>";
      }
      ?>
    </table>
  </div>
  <script src="js/protect.js"></script>
</body>
</html>
